"""
config.py
==========
All configuration for user_management, read once from the environment.
Every other file (database/db.py, create_table.py, seed_data.py, app.py)
imports from here instead of reading os.getenv() itself - one source
of truth. No credentials are hardcoded anywhere else in the project.
"""

import os

try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    pass

DB_CONFIG = {
    "host": os.getenv("PG_HOST", "localhost"),
    "port": int(os.getenv("PG_PORT", "5432")),
    "user": os.getenv("PG_USER", "postgres"),
    "password": os.getenv("PG_PASSWORD", "1234"),
}
DB_NAME = os.getenv("PG_DB_NAME", "telecom_db")

FLASK_PORT = int(os.getenv("FLASK_PORT", "5003"))
FLASK_DEBUG = os.getenv("FLASK_DEBUG", "false").lower() == "true"

# Used to sign the Flask session cookie (login state). Change this to a
# long random string in production — set it via the SECRET_KEY env var.
SECRET_KEY = os.getenv("SECRET_KEY", "dev-secret-change-me")

# Mark the session cookie "Secure" (browser only sends it back over HTTPS).
# Correct for the https tunnel, but it silently BREAKS a plain-http deploy on
# any host that isn't localhost: the browser drops the cookie, the widget's
# credentialed GET /api/cana-token then sees no session and answers 401, and
# the chat shows "Authentication required". Override with
# SESSION_COOKIE_SECURE=false when serving over plain http.
SESSION_COOKIE_SECURE = os.getenv("SESSION_COOKIE_SECURE", "true").lower() == "true"

# Number of reverse proxies in front of this app (the Cloudflare tunnel is 1).
# Without this, Flask reads the proxy's http:// hop instead of the browser's
# https:// origin, so request.host_url builds an http:// login URL on an https
# page. 0 disables the fix for a direct-to-Flask deploy.
TRUSTED_PROXY_HOPS = int(os.getenv("TRUSTED_PROXY_HOPS", "1"))

# Cana App Configuration
CANA_APP_ID = os.getenv("CANA_APP_ID", "")
CANA_APP_SIGNING_KEY = os.getenv("CANA_APP_SIGNING_KEY", "").strip()
CANA_APP_ID = CANA_APP_ID.strip()
# Where the hosted chat lives, and where the widget bundle is loaded from.
# The dashboard snippet uses https://cdn.cana.build/app.js; the same bundle is
# also served by cana.build itself. The page tries them in this order, so if
# the CDN host is unreachable (bad cert / blocked) it silently falls back.
CANA_WEB_BASE = os.getenv("CANA_WEB_BASE", "https://cana.build").strip().rstrip("/")
CANA_CDN_URL = os.getenv("CANA_CDN_URL", "https://cdn.cana.build/app.js").strip()
CANA_MODE = os.getenv("CANA_MODE", "panel").strip()  # "panel" = our own AI Agent button, "fab" = Cana's floating button
CANA_TOKEN_TTL_SEC = int(os.getenv("CANA_TOKEN_TTL_SEC", "900"))
MCP_AUTH_KEY = os.getenv("MCP_AUTH_KEY", "")  # Optional: static auth header for MCP endpoint
