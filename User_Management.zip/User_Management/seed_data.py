"""
seed_data.py
=============
Sample data daalta hai, sahi order me (FK ke hisaab se), sab tables me 100-100 rows:

    1. users              (created_by / updated_by bhi fill hote hain)
    2. towers             (random user_id se linked)
    3. tickets             (random user_id se linked)
    4. entity_audit_log     (random user_id se linked)

Pehle create_table.py chalao (empty schema banane ke liye), fir yeh:

    python seed_data.py
"""

import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import random
import psycopg2
from werkzeug.security import generate_password_hash

try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    pass

from config import DB_CONFIG, DB_NAME

RECORDS_PER_TABLE = 100   # sab tables me 100-100 records

# ============================================================
# SIMPLE SAMPLE DATA POOLS (koi external faker library nahi chahiye)
# ============================================================

FIRST_NAMES = [
    "Rahul", "Priya", "Amit", "Neha", "Karan", "Sneha", "Vikram", "Anita",
    "Rohit", "Pooja", "Arjun", "Kavya", "Sanjay", "Divya", "Manish", "Ritu",
    "Suresh", "Meera", "Ajay", "Shreya",
]
LAST_NAMES = [
    "Sharma", "Verma", "Gupta", "Singh", "Kumar", "Mehta", "Patel", "Reddy",
    "Nair", "Iyer", "Chopra", "Malhotra", "Kapoor", "Joshi", "Rao", "Bhatt",
]
CITIES = ["Delhi", "Noida", "Gurgaon", "Mumbai", "Pune", "Bengaluru", "Chennai", "Hyderabad"]
AREAS = ["Sector 62", "Rohini", "Cyber City", "Andheri", "Whitefield", "Koramangala", "Banjara Hills"]
TECHNOLOGIES = ["2G", "3G", "4G", "5G"]
TOWER_STATUSES = ["Active", "Inactive", "Maintenance"]
USER_STATUSES = ["active", "inactive", "suspended"]
ROLES = ["admin", "user"]

TICKET_SUBJECTS = [
    "Weak network signal", "Unable to access internet", "Billing discrepancy",
    "5G tower maintenance", "SIM activation issue", "Call drop complaint",
    "Data speed too slow", "Network outage report",
]
TICKET_CATEGORIES = ["Network", "Billing", "Internet", "SIM", "General"]
TICKET_PRIORITIES = ["Low", "Medium", "High"]
TICKET_STATUSES = ["Open", "In Progress", "Resolved", "Closed"]

ENTITY_TYPES = ["user", "tower", "ticket"]

# NOTE: audit_action must always describe something that actually happened
# to *that* entity_type. Previously actions and entity_types were picked
# independently at random, producing nonsense rows like
# audit_action="Updated tower status" with entity_type="user".
# Each action below is scoped to the entity_type it belongs to, and
# "Login"/"Logout" are user-account events (not tied to a specific
# tower/ticket record), so they're grouped under "user" too.
ACTIONS_BY_ENTITY_TYPE = {
    "user": [
        "Updated user profile", "Created user account", "Deactivated user account",
        "Login", "Logout",
    ],
    "tower": [
        "Created tower record", "Updated tower status", "Deleted tower record",
    ],
    "ticket": [
        "Created ticket", "Updated ticket status", "Closed ticket",
    ],
}


def seed_users(cursor):
    """
    Users insert karta hai aur created_by / updated_by bhi bharta hai:
      - Row 1 (bootstrap admin) -> created_by = NULL, updated_by = NULL
        (isse pehle koi user hi nahi tha jo isko banata)
      - Baaki sab rows -> created_by = koi bhi PEHLE se maujood user ki id
        (jaise Karan (id=2) ne Rahul (id=14) ko banaya tha, waise hi)
      - updated_by -> 40% rows me creator hi update bhi kar chuka hota hai,
        baaki me abhi tak NULL (kisi ne touch nahi kiya)
    """
    rows = []
    for i in range(RECORDS_PER_TABLE):
        current_id = i + 1  # fresh table hai to SERIAL id 1 se hi shuru hoga
        first = random.choice(FIRST_NAMES)
        last = random.choice(LAST_NAMES)
        email = f"{first.lower()}.{last.lower()}{i}@telecom.com"

        if current_id == 1:
            created_by = None
            updated_by = None
            # NOTE: row 1 is the "bootstrap admin" per the docstring above,
            # but it used to get role=random.choice(ROLES) like everyone
            # else, so it wasn't guaranteed to actually be an admin.
            # Force it to admin so there's always at least one real admin
            # account, and it's the natural creator/updater of everyone else.
            role = "admin"
        else:
            creator_id = random.randint(1, current_id - 1)  # ek purana user isko create karta hai
            created_by = creator_id
            updated_by = creator_id if random.random() < 0.4 else None
            role = random.choice(ROLES)

        # Same demo plaintext for every seed row on purpose (it's throwaway
        # sample data) — generate_password_hash() still salts each call
        # separately, so the stored hashes all come out different anyway.
        password_hash = generate_password_hash("Test@1234")

        rows.append((
            first,
            last,
            f"98{random.randint(10000000, 99999999)}",
            email,
            f"{random.randint(1, 200)}, {random.choice(AREAS)}, {random.choice(CITIES)}",
            password_hash,
            random.choice(USER_STATUSES),
            role,
            created_by,
            updated_by,
        ))

    cursor.executemany("""
        INSERT INTO users (
            first_name, last_name, phone_number, email, address, password, status, role,
            created_by, updated_by
        ) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
    """, rows)
    print(f"{RECORDS_PER_TABLE} rows inserted into 'users' (created_by / updated_by filled).")
    print("  Demo login password for every seeded user: Test@1234")


def get_all_user_ids(cursor) -> list[int]:
    cursor.execute("SELECT id FROM users")
    return [row[0] for row in cursor.fetchall()]


def get_admin_user_ids(cursor) -> list[int]:
    """entity_audit_log.user_id must always be the ADMIN who performed the
    action — not a random user. Only an admin is allowed to change records
    (see routers/user_router.py), so the actor recorded in the audit log
    has to come from this admin-only list, never from get_all_user_ids()."""
    cursor.execute("SELECT id FROM users WHERE role = 'admin'")
    admin_ids = [row[0] for row in cursor.fetchall()]
    if not admin_ids:
        # Shouldn't happen since row 1 is forced to admin in seed_users(),
        # but fail loudly instead of silently seeding wrong actor data.
        raise RuntimeError("No admin users found — cannot seed entity_audit_log actors.")
    return admin_ids


def seed_towers(cursor, user_ids: list[int]):
    rows = []
    for i in range(RECORDS_PER_TABLE):
        city = random.choice(CITIES)
        tech = random.choice(TECHNOLOGIES)
        rows.append((
            f"{city[:3].upper()}-{tech}-{i:03d}",
            city,
            random.choice(AREAS),
            tech,
            random.choice(TOWER_STATUSES),
            random.choice(user_ids),
        ))

    cursor.executemany("""
        INSERT INTO towers (
            tower_code, tower_city, tower_area, technology, tower_status, user_id
        ) VALUES (%s, %s, %s, %s, %s, %s)
    """, rows)
    print(f"{RECORDS_PER_TABLE} rows inserted into 'towers'.")


def seed_tickets(cursor, user_ids: list[int]):
    rows = []
    for i in range(RECORDS_PER_TABLE):
        rows.append((
            random.choice(user_ids),
            random.choice(TICKET_SUBJECTS),
            f"Auto-generated sample description for ticket #{i + 1}",
            random.choice(TICKET_CATEGORIES),
            random.choice(TICKET_PRIORITIES),
            random.choice(TICKET_STATUSES),
        ))

    cursor.executemany("""
        INSERT INTO tickets (
            user_id, ticket_subject, ticket_description,
            ticket_category, ticket_priority, ticket_status
        ) VALUES (%s, %s, %s, %s, %s, %s)
    """, rows)
    print(f"{RECORDS_PER_TABLE} rows inserted into 'tickets'.")


def seed_audit_log(cursor, admin_ids: list[int], all_user_ids: list[int]):
    """admin_ids -> who performed the action (user_id column). Only admins
    can change records, so the actor must come from admin_ids, never from
    all_user_ids. all_user_ids is only used for entity_id when the entity
    being acted on is itself a user (e.g. "Updated user profile" acts on
    some user record — that target user does NOT have to be an admin)."""
    rows = []
    for i in range(RECORDS_PER_TABLE):
        # Pick entity_type FIRST, then pick an action that actually
        # applies to that entity_type — keeps audit_action and
        # entity_type consistent (fixes the mismatched rows seen in
        # pgAdmin, e.g. "Updated tower status" logged against a user).
        entity_type = random.choice(ENTITY_TYPES)
        audit_action = random.choice(ACTIONS_BY_ENTITY_TYPE[entity_type])

        # entity_id: which specific record was acted on. For entity_type
        # "user" that's realistically any user id (the target), so pull
        # from all_user_ids; for tower/ticket it's just a row number in
        # that table's 1..RECORDS_PER_TABLE range (both start fresh at 1).
        entity_id = random.choice(all_user_ids) if entity_type == "user" else random.randint(1, RECORDS_PER_TABLE)

        rows.append((
            random.choice(admin_ids),  # <-- actor is ALWAYS an admin now
            audit_action,
            entity_type,
            entity_id,
            f"Auto-generated audit description: {audit_action} ({entity_type} action #{i + 1})",
        ))

    cursor.executemany("""
        INSERT INTO entity_audit_log (
            user_id, audit_action, entity_type, entity_id, audit_description
        ) VALUES (%s, %s, %s, %s, %s)
    """, rows)
    print(f"{RECORDS_PER_TABLE} rows inserted into 'entity_audit_log'.")


def main():
    conn = psycopg2.connect(dbname=DB_NAME, **DB_CONFIG)
    cursor = conn.cursor()
    print(f"Connected to '{DB_NAME}'.")

    seed_users(cursor)
    conn.commit()

    user_ids = get_all_user_ids(cursor)
    admin_ids = get_admin_user_ids(cursor)  # only admins can change records

    seed_towers(cursor, user_ids)
    seed_tickets(cursor, user_ids)
    seed_audit_log(cursor, admin_ids, user_ids)
    conn.commit()

    # ---------------- SUMMARY ----------------
    print("\n----------------------------------------")
    for table in ["users", "towers", "tickets", "entity_audit_log"]:
        cursor.execute(f"SELECT COUNT(*) FROM {table}")
        count = cursor.fetchone()[0]
        print(f"Table: {table:<18} Records: {count}")
    print("----------------------------------------")

    cursor.close()
    conn.close()
    print("\nSeeding completed successfully!")


if __name__ == "__main__":
    main()