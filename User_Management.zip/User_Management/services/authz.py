"""
services/authz.py
====================
Role-based access control, shared by every router.

The rule the whole app follows:
  - "user" role  -> can only ever see/touch THEIR OWN data (profile,
    own tickets). They never see other customers' records or any
    system/admin-only tables (towers, audit log).
  - "admin" role -> full access to everyone's data and all system
    tables.

Every protected route in this project should be wrapped with either
@login_required (must be signed in, either role) or @admin_required
(must be signed in AND role == "admin"). Ownership checks that can't
be expressed as a simple decorator (e.g. "only this ticket's owner or
an admin") use the is_admin()/current_user_id() helpers below, done
inside the route itself.
"""

from functools import wraps

from flask import session, jsonify, g

import models.user_model as user_model


def _load_current_user():
    """Populate flask.g.current_user once per request from the session
    cookie. Returns None if there's no valid session.

    NOTE: user_model.get_by_id() deliberately strips "id" (it's meant
    for API responses where the id is already known from the URL). We
    still need it internally for ownership checks, so it's re-attached
    here from the session itself — the one place that's always safe to
    trust, since it was set at login from the real DB row.
    """
    if not hasattr(g, "_current_user_loaded"):
        user_id = session.get("user_id")
        user = user_model.get_by_id(user_id) if user_id else None
        if user is not None:
            user = dict(user)
            user["id"] = user_id
        g.current_user = user
        g._current_user_loaded = True
    return g.current_user


def current_user():
    """The logged-in user's own (password-free) row, or None."""
    return _load_current_user()


def current_user_id():
    """The signed-in user's id, taken straight from the session rather
    than the (id-stripped) profile dict. Cheap and always correct as
    long as login_required/admin_required already confirmed the
    session is valid."""
    return session.get("user_id")


def current_role():
    user = current_user()
    return user.get("role") if user else None


def is_admin() -> bool:
    return current_role() == "admin"


def login_required(fn):
    """Reject the request unless there's a valid, still-active session."""
    @wraps(fn)
    def wrapper(*args, **kwargs):
        if not current_user():
            session.clear()
            return jsonify({"success": False, "error": "Authentication required"}), 401
        return fn(*args, **kwargs)
    return wrapper


def admin_required(fn):
    """Reject the request unless the signed-in user is an admin."""
    @wraps(fn)
    def wrapper(*args, **kwargs):
        if not current_user():
            session.clear()
            return jsonify({"success": False, "error": "Authentication required"}), 401
        if not is_admin():
            return jsonify({"success": False, "error": "Admin access required"}), 403
        return fn(*args, **kwargs)
    return wrapper
