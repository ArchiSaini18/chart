"""
services/user_service.py
==========================
Business logic for users — validation and rules that don't belong in
the raw data-access layer (models/user_model.py) or the HTTP layer
(routers/user_router.py).
"""

import re

import models.user_model as user_model

REQUIRED_ON_CREATE = {"first_name", "last_name", "email"}
VALID_STATUSES = {"active", "inactive", "suspended"}
VALID_ROLES = {"admin", "user"}
EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")


class ValidationError(Exception):
    pass


def _validate_common(data: dict):
    if "email" in data and not EMAIL_RE.match(data["email"]):
        raise ValidationError("email is not a valid email address")
    if "status" in data and data["status"] not in VALID_STATUSES:
        raise ValidationError(f"status must be one of {sorted(VALID_STATUSES)}")
    if "role" in data and data["role"] not in VALID_ROLES:
        raise ValidationError(f"role must be one of {sorted(VALID_ROLES)}")


def get_user(user_id: int):
    return user_model.get_by_id(user_id)


def list_users(limit: int = None, status: str = None, role: str = None, include_ids: bool = False):
    return user_model.list_records(limit=limit, status=status, role=role, include_ids=include_ids)


def create_user(data: dict):
    missing = REQUIRED_ON_CREATE - data.keys()
    if missing:
        raise ValidationError(f"Missing required field(s): {', '.join(sorted(missing))}")
    _validate_common(data)
    if user_model.get_by_email(data["email"]):
        raise ValidationError(f"A user with email '{data['email']}' already exists")
    data.setdefault("status", "active")
    data.setdefault("role", "user")
    return user_model.create(data)


def update_user(user_id: int, data: dict):
    if not user_model.get_by_id(user_id):
        raise ValidationError(f"No user with id={user_id}")
    _validate_common(data)
    if "email" in data:
        existing = user_model.get_by_email(data["email"])
        if existing and existing["id"] != user_id:
            raise ValidationError(f"A user with email '{data['email']}' already exists")
    return user_model.update(user_id, data)


def delete_user(user_id: int):
    if not user_model.get_by_id(user_id):
        raise ValidationError(f"No user with id={user_id}")
    return user_model.delete(user_id)
