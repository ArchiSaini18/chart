"""
services/auth_service.py
==========================
Business logic for the login / sign-up page. Kept separate from
services/user_service.py because auth has its own rules (password +
confirm password, hashing, login check) that the admin-panel user
CRUD doesn't need to know about.

Password handling:
  - We NEVER store the raw password. generate_password_hash() (from
    werkzeug, which Flask already depends on, so no new package is
    needed) creates a salted hash before it touches the database.
  - The salt is random per call, so even if two users pick the exact
    same password, their stored hashes come out different.
  - check_password_hash() is the only way to verify a login — there
    is no way to "read back" a password from its hash.
"""

import re

from werkzeug.security import generate_password_hash, check_password_hash

import models.user_model as user_model

EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")
MIN_PASSWORD_LEN = 6

REQUIRED_ON_SIGNUP = ["first_name", "last_name", "email", "password", "confirm_password"]


class AuthError(Exception):
    pass


def _validate_signup(data: dict):
    missing = [f for f in REQUIRED_ON_SIGNUP if not str(data.get(f, "")).strip()]
    if missing:
        raise AuthError(f"Missing required field(s): {', '.join(missing)}")

    if not EMAIL_RE.match(data["email"].strip()):
        raise AuthError("Please enter a valid email address")

    if len(data["password"]) < MIN_PASSWORD_LEN:
        raise AuthError(f"Password must be at least {MIN_PASSWORD_LEN} characters long")

    if data["password"] != data["confirm_password"]:
        raise AuthError("Password and Confirm Password do not match")


def signup_user(data: dict) -> dict:
    """Create a new account. Returns the created user (password-free)."""
    _validate_signup(data)

    if user_model.get_by_email(data["email"].strip()):
        raise AuthError(f"An account with email '{data['email']}' already exists")

    hashed_password = generate_password_hash(data["password"])

    payload = {
        "first_name": data["first_name"].strip(),
        "last_name": data["last_name"].strip(),
        "phone_number": data.get("phone_number", "").strip() or None,
        "email": data["email"].strip(),
        "address": data.get("address", "").strip() or None,
        "password": hashed_password,
        "status": "active",
        "role": "user",
    }
    result = user_model.create(payload)
    # get_by_id() goes through HIDDEN_COLUMNS, so the hash never comes back out.
    # It also strips "id", but the router needs the id to start the login
    # session (auto-login after sign-up), so re-attach it here - the same
    # thing /api/auth/me does.
    user = dict(user_model.get_by_id(result["id"]))
    user["id"] = result["id"]
    return user


def login_user(email: str, password: str) -> dict:
    """Check credentials. Returns the logged-in user (password-free)."""
    email = (email or "").strip()
    password = password or ""

    if not email or not password:
        raise AuthError("Email/Username and password are required")

    user = user_model.get_by_email(email)  # raw row — includes the hash
    if not user or not check_password_hash(user["password"], password):
        raise AuthError("Invalid email/username or password")

    if user.get("status") != "active":
        raise AuthError("This account is not active. Contact an admin.")

    # Strip the hash out before this ever reaches the router/response.
    return {k: v for k, v in user.items() if k != "password"}
