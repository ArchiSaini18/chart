"""
services/entity_audit_service.py
==================================
Business logic for the entity audit log.
"""

import models.entity_audit_model as audit_model
import models.user_model as user_model

REQUIRED_ON_CREATE = {"audit_action", "entity_type"}
VALID_ENTITY_TYPES = {"user", "tower", "ticket"}


class ValidationError(Exception):
    pass


def _validate_common(data: dict):
    if "entity_type" in data and data["entity_type"] not in VALID_ENTITY_TYPES:
        raise ValidationError(f"entity_type must be one of {sorted(VALID_ENTITY_TYPES)}")
    if data.get("user_id") is not None and not user_model.get_by_id(data["user_id"]):
        raise ValidationError(f"No user with id={data['user_id']}")


def get_log(log_id: int):
    return audit_model.get_by_id(log_id)


def list_logs(limit: int = None, entity_type=None, user_id=None, include_ids: bool = False):
    return audit_model.list_records(limit=limit, entity_type=entity_type, user_id=user_id, include_ids=include_ids)


def create_log(data: dict):
    missing = REQUIRED_ON_CREATE - data.keys()
    if missing:
        raise ValidationError(f"Missing required field(s): {', '.join(sorted(missing))}")
    _validate_common(data)
    return audit_model.create(data)


def update_log(log_id: int, data: dict):
    if not audit_model.get_by_id(log_id):
        raise ValidationError(f"No audit log entry with id={log_id}")
    _validate_common(data)
    return audit_model.update(log_id, data)


def delete_log(log_id: int):
    if not audit_model.get_by_id(log_id):
        raise ValidationError(f"No audit log entry with id={log_id}")
    return audit_model.delete(log_id)


# --------------------------------------------------------------
# Convenience wrapper used by the MCP tool layer (lib/mcp_server.py),
# which logs actions using a (action, table, record_id) vocabulary
# instead of this service's (audit_action, entity_type, entity_id)
# column names. Previously this call-site pointed at a function
# (`log_action`) that didn't exist here, so every MCP write-tool
# (create_user/update_user/delete_user/create_ticket) wrote its row
# successfully and then crashed with an AttributeError right after —
# reported to Cana as a failed tool call even though the write went
# through.
# --------------------------------------------------------------
TABLE_TO_ENTITY_TYPE = {"users": "user", "towers": "tower", "tickets": "ticket"}


def log_action(action: str, table: str, record_id: int, user_id: int = None, description: str = None):
    entity_type = TABLE_TO_ENTITY_TYPE.get(table, table)
    return create_log({
        "audit_action": action,
        "entity_type": entity_type,
        "entity_id": record_id,
        "user_id": user_id,
        "audit_description": description or f"{action} on {entity_type} {record_id}",
    })
