"""
services/ticket_service.py
============================
Business logic for support tickets.
"""

import models.ticket_model as ticket_model
import models.user_model as user_model

REQUIRED_ON_CREATE = {"user_id", "ticket_subject"}
VALID_PRIORITIES = {"Low", "Medium", "High"}
VALID_STATUSES = {"Open", "In Progress", "Resolved", "Closed"}


class ValidationError(Exception):
    pass


def _validate_common(data: dict):
    if "ticket_priority" in data and data["ticket_priority"] not in VALID_PRIORITIES:
        raise ValidationError(f"ticket_priority must be one of {sorted(VALID_PRIORITIES)}")
    if "ticket_status" in data and data["ticket_status"] not in VALID_STATUSES:
        raise ValidationError(f"ticket_status must be one of {sorted(VALID_STATUSES)}")
    if data.get("user_id") is not None and not user_model.get_by_id(data["user_id"]):
        raise ValidationError(f"No user with id={data['user_id']}")


def get_ticket(ticket_id: int, raw: bool = False):
    """raw=True also attaches the real user_id (owner) for ownership
    checks done by the router; raw=False (default) is the normal,
    sanitized shape returned to API callers."""
    record = ticket_model.get_by_id(ticket_id)
    if record is None:
        return None
    if raw:
        record = dict(record)
        record["user_id"] = ticket_model.get_owner_user_id(ticket_id)
    return record


def list_tickets(limit: int = None, status=None, priority=None, category=None, user_id=None, include_ids: bool = False):
    return ticket_model.list_records(limit=limit, status=status, priority=priority,
                                      category=category, user_id=user_id, include_ids=include_ids)


def create_ticket(data: dict):
    missing = REQUIRED_ON_CREATE - data.keys()
    if missing:
        raise ValidationError(f"Missing required field(s): {', '.join(sorted(missing))}")
    _validate_common(data)
    data.setdefault("ticket_status", "Open")
    return ticket_model.create(data)


def update_ticket(ticket_id: int, data: dict):
    if not ticket_model.get_by_id(ticket_id):
        raise ValidationError(f"No ticket with id={ticket_id}")
    _validate_common(data)
    return ticket_model.update(ticket_id, data)


def delete_ticket(ticket_id: int):
    if not ticket_model.get_by_id(ticket_id):
        raise ValidationError(f"No ticket with id={ticket_id}")
    return ticket_model.delete(ticket_id)
