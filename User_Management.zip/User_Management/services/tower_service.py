"""
services/tower_service.py
===========================
Business logic for network towers.
"""

import models.tower_model as tower_model
import models.user_model as user_model

REQUIRED_ON_CREATE = {"tower_code", "tower_city"}
VALID_TECHNOLOGIES = {"2G", "3G", "4G", "5G"}
VALID_STATUSES = {"Active", "Inactive", "Maintenance"}


class ValidationError(Exception):
    pass


def _validate_common(data: dict):
    if "technology" in data and data["technology"] not in VALID_TECHNOLOGIES:
        raise ValidationError(f"technology must be one of {sorted(VALID_TECHNOLOGIES)}")
    if "tower_status" in data and data["tower_status"] not in VALID_STATUSES:
        raise ValidationError(f"tower_status must be one of {sorted(VALID_STATUSES)}")
    if data.get("user_id") is not None and not user_model.get_by_id(data["user_id"]):
        raise ValidationError(f"No user with id={data['user_id']}")


def get_tower(tower_id: int):
    return tower_model.get_by_id(tower_id)


def list_towers(limit: int = None, city=None, technology=None, status=None, user_id=None, include_ids: bool = False):
    return tower_model.list_records(limit=limit, city=city, technology=technology,
                                     status=status, user_id=user_id, include_ids=include_ids)


def create_tower(data: dict):
    missing = REQUIRED_ON_CREATE - data.keys()
    if missing:
        raise ValidationError(f"Missing required field(s): {', '.join(sorted(missing))}")
    _validate_common(data)
    data.setdefault("tower_status", "Active")
    return tower_model.create(data)


def update_tower(tower_id: int, data: dict):
    if not tower_model.get_by_id(tower_id):
        raise ValidationError(f"No tower with id={tower_id}")
    _validate_common(data)
    return tower_model.update(tower_id, data)


def delete_tower(tower_id: int):
    if not tower_model.get_by_id(tower_id):
        raise ValidationError(f"No tower with id={tower_id}")
    return tower_model.delete(tower_id)
