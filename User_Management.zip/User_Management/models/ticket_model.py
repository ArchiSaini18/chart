
from database.db import generic_get_by_id, generic_list, generic_insert, generic_update, generic_delete, strip_fields

TABLE = "tickets"
ID_COLUMN = "id"

WRITABLE_COLUMNS = {
    "user_id", "ticket_subject", "ticket_description",
    "ticket_category", "ticket_priority", "ticket_status",
}

# Still fetched/used internally (ordering, ownership checks) but never
# shown to API callers.
HIDDEN_COLUMNS = {"id", "user_id", "created_at"}


def get_by_id(record_id: int):
    return strip_fields(generic_get_by_id(TABLE, ID_COLUMN, record_id), HIDDEN_COLUMNS)


def get_owner_user_id(record_id: int):
    """Unfiltered on purpose — used only for internal ownership checks
    (see routers/ticket_router.py, so a plain user can't read/edit/
    delete someone else's ticket). Never returned straight to an API
    caller."""
    row = generic_get_by_id(TABLE, ID_COLUMN, record_id)
    return row["user_id"] if row else None


def list_records(limit: int = None, status: str = None, priority: str = None,
                  category: str = None, user_id: int = None, include_ids: bool = False):
    clauses, params = [], []
    if status:
        clauses.append("ticket_status = %s")
        params.append(status)
    if priority:
        clauses.append("ticket_priority = %s")
        params.append(priority)
    if category:
        clauses.append("ticket_category = %s")
        params.append(category)
    if user_id:
        clauses.append("user_id = %s")
        params.append(user_id)
    where_sql = f"WHERE {' AND '.join(clauses)}" if clauses else ""
    rows = generic_list(TABLE, limit=limit, where_sql=where_sql, params=tuple(params))
    hidden = HIDDEN_COLUMNS - {"id"} if include_ids else HIDDEN_COLUMNS
    return strip_fields(rows, hidden)


def create(data: dict):
    payload = {k: v for k, v in data.items() if k in WRITABLE_COLUMNS}
    return generic_insert(TABLE, ID_COLUMN, payload)


def update(record_id: int, data: dict):
    payload = {k: v for k, v in data.items() if k in WRITABLE_COLUMNS}
    return generic_update(TABLE, ID_COLUMN, record_id, payload)


def delete(record_id: int):
    return generic_delete(TABLE, ID_COLUMN, record_id)
