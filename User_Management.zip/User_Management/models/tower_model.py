
from database.db import generic_get_by_id, generic_list, generic_insert, generic_update, generic_delete, run_select, strip_fields

TABLE = "towers"
ID_COLUMN = "id"

WRITABLE_COLUMNS = {
    "tower_code", "tower_city", "tower_area", "technology",
    "tower_status", "user_id",
}

# Still fetched/used internally (ordering, ownership checks) but never
# shown to API callers.
HIDDEN_COLUMNS = {"id", "user_id", "created_at"}


def get_by_id(record_id: int):
    return strip_fields(generic_get_by_id(TABLE, ID_COLUMN, record_id), HIDDEN_COLUMNS)


def list_records(limit: int = None, city: str = None, technology: str = None,
                  status: str = None, user_id: int = None, include_ids: bool = False):
    clauses, params = [], []
    if city:
        clauses.append("tower_city = %s")
        params.append(city)
    if technology:
        clauses.append("technology = %s")
        params.append(technology)
    if status:
        clauses.append("tower_status = %s")
        params.append(status)
    if user_id:
        clauses.append("user_id = %s")
        params.append(user_id)
    where_sql = f"WHERE {' AND '.join(clauses)}" if clauses else ""
    rows = generic_list(TABLE, limit=limit, where_sql=where_sql, params=tuple(params))
    hidden = HIDDEN_COLUMNS - {"id"} if include_ids else HIDDEN_COLUMNS
    return strip_fields(rows, hidden)


def create(data: dict):
    payload = {k: v for k, v in data.items() if k in WRITABLE_COLUMNS}
    return generic_insert(TABLE, ID_COLUMN, payload)


def update(record_id: int, data: dict):
    payload = {k: v for k, v in data.items() if k in WRITABLE_COLUMNS}
    return generic_update(TABLE, ID_COLUMN, record_id, payload)


def delete(record_id: int):
    return generic_delete(TABLE, ID_COLUMN, record_id)
