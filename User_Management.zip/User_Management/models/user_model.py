from datetime import datetime

from database.db import generic_get_by_id, generic_list, generic_insert, generic_update, generic_delete, run_select, strip_fields

TABLE = "users"
ID_COLUMN = "id"

# Whitelisted, writable columns — request bodies are filtered against
# this before ever reaching the query.
WRITABLE_COLUMNS = {
    "first_name", "last_name", "phone_number", "email", "address",
    "status", "role", "created_by", "updated_by", "password",
}

# Columns that exist in the table and are still used internally
# (e.g. ordering, existence checks, updated_at bump) but should never
# be shown to API callers. "password" (the hash) must NEVER leave this
# layer through get_by_id/list_records — only get_by_email() below
# returns it raw, and only auth_service.py is allowed to look at it.
HIDDEN_COLUMNS = {"id", "created_by", "updated_by", "created_at", "updated_at", "password"}


def get_by_id(record_id: int):
    return strip_fields(generic_get_by_id(TABLE, ID_COLUMN, record_id), HIDDEN_COLUMNS)


def get_by_email(email: str):
    # Unfiltered on purpose: services/user_service.py uses the raw "id"
    # from this to compare against the record being updated, and
    # services/auth_service.py uses the raw "password" hash to check
    # a login attempt. Never return this dict straight to an API caller.
    rows = run_select(f"SELECT * FROM {TABLE} WHERE email = %s", (email,))
    return rows[0] if rows else None


def list_records(limit: int = None, status: str = None, role: str = None, include_ids: bool = False):
    clauses, params = [], []
    if status:
        clauses.append("status = %s")
        params.append(status)
    if role:
        clauses.append("role = %s")
        params.append(role)
    where_sql = f"WHERE {' AND '.join(clauses)}" if clauses else ""
    rows = generic_list(TABLE, limit=limit, where_sql=where_sql, params=tuple(params))
    hidden = HIDDEN_COLUMNS - {"id"} if include_ids else HIDDEN_COLUMNS
    return strip_fields(rows, hidden)


def create(data: dict):
    payload = {k: v for k, v in data.items() if k in WRITABLE_COLUMNS}
    return generic_insert(TABLE, ID_COLUMN, payload)


def update(record_id: int, data: dict):
    payload = {k: v for k, v in data.items() if k in WRITABLE_COLUMNS}
    payload["updated_at"] = datetime.utcnow()  # always bump updated_at on write
    return generic_update(TABLE, ID_COLUMN, record_id, payload)


def delete(record_id: int):
    return generic_delete(TABLE, ID_COLUMN, record_id)
