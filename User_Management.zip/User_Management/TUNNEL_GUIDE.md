# Cloudflare Tunnel Setup Guide

## ✅ What You Need

Your Flask app is running on **port 5002**. You need to expose it publicly via Cloudflare tunnel to use with Cana.

---

## 🚀 Quick Start

### Option 1: Using Batch File (Easiest on Windows)

1. **Double-click** `RUN_TUNNEL.bat` in this folder
2. A window opens and the tunnel starts
3. **Keep this window open** while using Cana
4. Copy the URL it shows (looks like `https://xxx.trycloudflare.com`)

### Option 2: Using PowerShell

1. Open PowerShell
2. Navigate to this folder:
   ```powershell
   cd "C:\Users\HP\Desktop\Colate\Chatbot application\with3\User_Management\User_Management"
   ```
3. Run:
   ```powershell
   python tunnel_simple.py
   ```
4. **Keep the window open**

### Option 3: Using Command Prompt

1. Open Command Prompt (cmd.exe)
2. Navigate to this folder
3. Run:
   ```cmd
   python tunnel_simple.py
   ```

---

## 📋 After Starting the Tunnel

You'll see output like:
```
==================================================
User Management + Cloudflare Tunnel
==================================================

Starting cloudflared tunnel on port 5002...
(Keep this window open)

... (lots of Cloudflare logs)

Your quick Tunnel has been created! Visit it at:
https://complete-told-phi-character.trycloudflare.com
```

### Copy that URL! You'll need it for Cana.

---

## 🔧 Setting Up in Cana

1. Go to https://cana.build
2. Open your **App**
3. Go to **Connectors** tab
4. Click **"+ Add MCP connector"**
5. Fill in:
   - **Name**: `User Management`
   - **MCP Server URL**: `https://YOUR-TUNNEL-URL/api/mcp`
   - Replace `YOUR-TUNNEL-URL` with the URL from step above
   - Example: `https://complete-told-phi-character.trycloudflare.com/api/mcp`
6. Click **Connect**
7. If it asks about permissions: set **reads** to AUTO_RUN, **writes** to CONFIRM
8. Click **"Connect & Save"**

---

## ⚠️ Important Notes

### The URL Changes Every Time You Restart

- Each time you run the tunnel script, Cloudflare gives you a **NEW URL**
- If you restart the tunnel, **update the URL in cana.build**
- This is normal and expected behavior

### Keep the Tunnel Running

- The tunnel window must stay open while you use Cana
- If you close it, the connection stops
- Just restart it using one of the methods above

### If It Doesn't Work

1. **Check Flask is running:**
   ```cmd
   python app.py
   ```
   You should see: `Running on http://127.0.0.1:5002`

2. **Check cloudflared is installed:**
   ```cmd
   cloudflared --version
   ```
   You should see a version number

3. **Check your network:**
   - Make sure you have internet connection
   - Make sure firewall isn't blocking cloudflared
   - Try disconnecting VPN if you have one

---

## 📝 Files in This Folder

- **`tunnel_simple.py`** - The tunnel script (recommended - most reliable)
- **`tunnel.py`** - Alternative tunnel script with more features
- **`RUN_TUNNEL.bat`** - Windows batch file to start tunnel (double-click this)
- **`start-tunnel.ps1`** - PowerShell version

---

## 🎯 Summary

1. Start tunnel: `python tunnel_simple.py` or double-click `RUN_TUNNEL.bat`
2. Copy the URL it shows
3. Paste URL into cana.build Connectors tab
4. Done! ✅

That's it! Your Flask app is now exposed to Cana via the internet.
