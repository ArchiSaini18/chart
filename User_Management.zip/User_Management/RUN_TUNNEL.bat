@echo off
REM ============================================
REM User Management Tunnel Launcher
REM ============================================
REM 
REM This file starts the cloudflared tunnel.
REM Keep this window open while using Cana.
REM

title User Management Tunnel
cls

echo.
echo ============================================
echo User Management + Cana Tunnel
echo ============================================
echo.
echo Starting tunnel...
echo Keep this window open!
echo.

python tunnel.py

echo.
echo Tunnel stopped.
pause
