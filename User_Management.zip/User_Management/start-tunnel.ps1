# Simple PowerShell script to start the tunnel
# Run this in PowerShell (not Git Bash)

Write-Host ""
Write-Host "=================================="
Write-Host "User Management Tunnel"
Write-Host "==================================`n"

Write-Host "Starting tunnel... (keep this window open)`n" -ForegroundColor Green

# Start the tunnel
python tunnel.py

# If it exits, ask user
Write-Host "`nTunnel stopped. Press any key to close..." -ForegroundColor Yellow
Read-Host
