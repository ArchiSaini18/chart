#!/bin/bash
# Verify that tunnel.py has the stderr=subprocess.STDOUT fix
grep -q "stderr=subprocess.STDOUT" "$(dirname "$0")/tunnel.py"
