#!/usr/bin/env python3
"""
tunnel.py
=========
One command that makes this Flask app reachable from cana.build and prints
every value you need to paste into the Cana dashboard.

    python tunnel.py                    start Flask (if needed) -> tunnel -> verify -> print config
    python tunnel.py --verbose          also show raw cloudflared log lines
    python tunnel.py --protocol quic    use QUIC instead of the default HTTP/2
    python tunnel.py --no-verify        skip the checks made through the public URL

Why a tunnel is not optional: cana.build calls your MCP URL from ITS servers,
and it refuses localhost / private IPs. A https://*.trycloudflare.com URL is
public and HTTPS, so it is accepted; http://localhost:5003 never can be.

This is the Python twin of `npm run tunnel` in cana-apps-demo.
"""

import argparse
import atexit
import json
import os
import re
import secrets
import shutil
import socket
import subprocess
import sys
import threading
import time
import urllib.error
import urllib.request
from collections import deque
from datetime import datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parent
os.chdir(ROOT)  # so .env, app.py and .cana-tunnel.json resolve wherever you launch from

MCP_KEY_HEADER = "x-mcp-key"  # header name to register under "Static credential" in Cana


# --------------------------------------------------------------------------
# Console helpers
# --------------------------------------------------------------------------
def _setup_console():
    # A plain TextIOWrapper (what the old script used) is NOT line-buffered, so
    # messages could sit in a buffer and the script looked "hung". reconfigure()
    # keeps the real stream and just switches on UTF-8 + line buffering.
    for stream in (sys.stdout, sys.stderr):
        try:
            stream.reconfigure(encoding="utf-8", errors="replace", line_buffering=True)
        except Exception:
            pass
    if os.name == "nt":
        os.system("")  # turns on ANSI colour support in the Windows console


_setup_console()
_USE_COLOR = sys.stdout.isatty() and not os.getenv("NO_COLOR")


def _c(code):
    return f"\033[{code}m" if _USE_COLOR else ""


class C:
    reset, bold, dim = _c(0), _c(1), _c(2)
    red, green, yellow, cyan = _c(31), _c(32), _c(33), _c(36)


def ok(msg):
    print(f"{C.green}✓{C.reset} {msg}")


def warn(msg):
    print(f"{C.yellow}⚠{C.reset} {msg}")


def info(msg):
    print(f"{C.bold}{msg}{C.reset}")


def dim(msg):
    print(f"{C.dim}{msg}{C.reset}")


def die(msg, hint=None):
    print(f"\n{C.red}✗ {msg}{C.reset}")
    if hint:
        print(f"  {hint}")
    sys.exit(1)  # atexit handlers below stop anything we started


# --------------------------------------------------------------------------
# Config (.env)
# --------------------------------------------------------------------------
def load_env():
    """Load .env so FLASK_PORT / CANA_* / MCP_AUTH_KEY are visible to this script.
    (The old script never read .env, so the App ID and signing key always
    showed as 'not set' and the port was always the default.)"""
    path = ROOT / ".env"
    if not path.exists():
        return
    try:
        from dotenv import load_dotenv

        load_dotenv(path)
        return
    except ImportError:
        pass
    for raw in path.read_text(encoding="utf-8", errors="replace").splitlines():
        line = raw.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, _, value = line.partition("=")
        os.environ.setdefault(key.strip(), value.strip().strip("\"'"))


# --------------------------------------------------------------------------
# Small HTTP / network helpers (stdlib only)
# --------------------------------------------------------------------------
# Cloudflare sometimes blocks the default "Python-urllib" User-Agent (error 1010),
# so look like a normal client.
_UA = "Mozilla/5.0 (compatible; cana-tunnel-check/1.0)"


def http(url, method="GET", body=None, headers=None, timeout=10):
    """Return (status, text). HTTP error statuses are returned, not raised."""
    hdrs = {"User-Agent": _UA, "Accept": "application/json, text/event-stream"}
    if headers:
        hdrs.update(headers)
    data = None
    if body is not None:
        data = json.dumps(body).encode("utf-8")
        hdrs.setdefault("Content-Type", "application/json")
    req = urllib.request.Request(url, data=data, headers=hdrs, method=method)
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return resp.status, resp.read().decode("utf-8", errors="replace")
    except urllib.error.HTTPError as e:
        return e.code, e.read().decode("utf-8", errors="replace")


def port_open(port):
    try:
        with socket.create_connection(("127.0.0.1", port), timeout=1):
            return True
    except OSError:
        return False


# --------------------------------------------------------------------------
# Process management
# --------------------------------------------------------------------------
_children = []  # (label, Popen)


def _stop(proc):
    if proc.poll() is not None:
        return
    proc.terminate()
    try:
        proc.wait(timeout=5)
    except subprocess.TimeoutExpired:
        proc.kill()


def _cleanup():
    for _label, proc in reversed(_children):
        try:
            _stop(proc)
        except Exception:
            pass


atexit.register(_cleanup)


# --------------------------------------------------------------------------
# cloudflared
# --------------------------------------------------------------------------
def find_cloudflared():
    exe = "cloudflared.exe" if os.name == "nt" else "cloudflared"
    candidates = [ROOT / ".tools" / exe]
    if os.name == "nt":
        for env_var in ("ProgramFiles(x86)", "ProgramFiles"):
            base = os.environ.get(env_var)
            if base:
                candidates.append(Path(base) / "cloudflared" / exe)
    for path in candidates:
        if path.exists():
            return str(path)
    return shutil.which("cloudflared")


def check_cloudflared():
    cf = find_cloudflared()
    if not cf:
        die(
            "cloudflared is not installed (or not on PATH).",
            "Windows:  winget install Cloudflare.cloudflared   (or scoop/choco install cloudflared)\n"
            "  Or download: https://github.com/cloudflare/cloudflared/releases\n"
            "  Or drop cloudflared.exe into a .tools folder next to this script.",
        )
    try:
        out = subprocess.run([cf, "--version"], capture_output=True, text=True, timeout=15)
        version = (out.stdout or out.stderr or "").strip().splitlines()[0]
    except Exception as e:  # noqa: BLE001
        die("Found cloudflared but could not run it.", f"{cf}\n  {e}")
    dim(version)
    return cf


# cloudflared prints "https://api.trycloudflare.com/tunnel" in its own error
# messages -- the old script mistook that for the tunnel URL. Skip host "api".
_URL_RE = re.compile(r"https://([a-z0-9][a-z0-9-]*)\.trycloudflare\.com", re.IGNORECASE)


class Tunnel:
    """Runs one cloudflared quick-tunnel process and extracts its public URL."""

    def __init__(self, cloudflared, port, protocol, verbose):
        self.cloudflared, self.port = cloudflared, port
        self.protocol, self.verbose = protocol, verbose
        self.proc = None
        self.url = None
        self.tail = deque(maxlen=25)
        self._ready = threading.Event()
        self._last_warn = 0.0

    def start(self, timeout=60):
        # 127.0.0.1, not "localhost": on Windows "localhost" resolves to ::1
        # (IPv6) first, but Flask listens on IPv4, so cloudflared got
        # "connection refused" for every request.
        cmd = [
            self.cloudflared, "tunnel",
            "--url", f"http://127.0.0.1:{self.port}",
            "--no-autoupdate",
            "--protocol", self.protocol,
        ]
        self.proc = subprocess.Popen(
            cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,  # cloudflared logs to stderr; merge so nothing is lost
            text=True, encoding="utf-8", errors="replace", bufsize=1,
        )
        _children.append(("cloudflared", self.proc))
        threading.Thread(target=self._pump, daemon=True).start()

        deadline = time.time() + timeout
        while time.time() < deadline:
            if self._ready.wait(0.5):
                return self.url
            if self.proc.poll() is not None:
                break
        return None

    def _pump(self):
        # Runs for the life of the tunnel. It must keep draining the pipe --
        # if nobody reads it, cloudflared eventually blocks on a full buffer.
        for line in self.proc.stdout:
            line = line.rstrip()
            if not line:
                continue
            self.tail.append(line)
            if self.verbose:
                dim(f"  {line}")
            if not self.url:
                for m in _URL_RE.finditer(line):
                    if m.group(1).lower() != "api":
                        self.url = m.group(0).lower()
                        self._ready.set()
                        break
            elif not self.verbose and (" ERR " in line or "Unable to reach the origin" in line):
                # Tunnel is up but something is failing -- say so (at most every 5s).
                if time.time() - self._last_warn > 5:
                    self._last_warn = time.time()
                    print(f"{C.yellow}  cloudflared: {line[-160:]}{C.reset}")

    def alive(self):
        return self.proc is not None and self.proc.poll() is None

    def stop(self):
        if self.proc:
            _stop(self.proc)


def open_tunnel(cloudflared, port, protocol, verbose, attempts=3):
    info("Opening a public tunnel…")
    dim(f"  protocol: {protocol}  (usually 5-15 seconds)")
    for n in range(1, attempts + 1):
        tunnel = Tunnel(cloudflared, port, protocol, verbose)
        url = tunnel.start()
        if url:
            ok(url)
            return tunnel
        tunnel.stop()
        print(f"{C.yellow}  attempt {n}/{attempts} failed{C.reset}")
        for line in list(tunnel.tail)[-6:]:
            dim(f"    {line[-200:]}")
        if n < attempts:
            time.sleep(3)
    die(
        "cloudflared could not open a tunnel.",
        "Most common causes:\n"
        "    - your network/firewall blocks outbound port 7844 (try another network or a phone hotspot)\n"
        "    - a VPN/proxy is interfering\n"
        "    - try the other transport:  python tunnel.py --protocol quic\n"
        "    - see raw logs:             python tunnel.py --verbose",
    )


# --------------------------------------------------------------------------
# Flask
# --------------------------------------------------------------------------
def _tail_file(path, n=15):
    try:
        return "\n".join(Path(path).read_text(encoding="utf-8", errors="replace").splitlines()[-n:])
    except OSError:
        return "(no log)"


def ensure_flask(port):
    """Use the Flask app if it is already listening, otherwise start it."""
    if port_open(port):
        try:
            status, text = http(f"http://127.0.0.1:{port}/api/mcp", timeout=5)
            if status == 200 and "User Management MCP" in text:
                ok(f"Flask is already running on port {port}")
            else:
                warn(f"Port {port} is in use, but it does not look like this app (GET /api/mcp -> {status}).")
        except Exception:  # noqa: BLE001
            warn(f"Something is listening on port {port} but did not answer HTTP.")
        return

    info(f"Starting Flask on port {port}…")
    log_path = ROOT / "flask-tunnel.log"
    log = open(log_path, "w", encoding="utf-8")
    env = dict(os.environ, FLASK_DEBUG="false", PYTHONUNBUFFERED="1", PYTHONIOENCODING="utf-8")
    proc = subprocess.Popen([sys.executable, "app.py"], cwd=ROOT, env=env, stdout=log, stderr=subprocess.STDOUT)
    _children.append(("flask", proc))

    deadline = time.time() + 30
    while time.time() < deadline:
        if port_open(port):
            ok(f"Flask started on port {port}  {C.dim}(log: flask-tunnel.log){C.reset}")
            return
        if proc.poll() is not None:
            die(
                "Flask exited right after starting.",
                f"Last lines of flask-tunnel.log:\n{_tail_file(log_path)}\n\n"
                "  Typical fixes: pip install -r requirements.txt  |  check PG_* values in .env",
            )
        time.sleep(0.3)
    die("Flask did not open its port within 30s.", f"Last lines of flask-tunnel.log:\n{_tail_file(log_path)}")


def check_database(port):
    try:
        status, text = http(f"http://127.0.0.1:{port}/health", timeout=8)
        if status == 200:
            ok("Database reachable")
        else:
            warn("Database is NOT reachable — the tunnel will work, but tool calls will fail until Postgres is up.")
            dim(f"  /health -> {status}: {text.strip()[:160]}")
    except Exception as e:  # noqa: BLE001
        warn(f"Could not query /health: {e}")


# --------------------------------------------------------------------------
# Verification through the PUBLIC url
# --------------------------------------------------------------------------
def public_dns_has(host):
    """Ask Cloudflare's resolver directly. Never touches the local resolver, so
    a too-early lookup can't leave a cached NXDOMAIN on Windows (which would
    keep failing for ~15 minutes even after DNS propagates)."""
    for base in ("https://cloudflare-dns.com/dns-query", "https://1.1.1.1/dns-query"):
        try:
            status, text = http(f"{base}?name={host}&type=A", headers={"Accept": "application/dns-json"}, timeout=6)
            if status == 200:
                data = json.loads(text)
                return data.get("Status") == 0 and bool(data.get("Answer"))
        except Exception:  # noqa: BLE001
            continue
    return None  # could not ask


def local_dns_has(host):
    try:
        socket.getaddrinfo(host, 443)
        return True
    except socket.gaierror:
        return False


def wait_for_dns(host, seconds=90):
    info("Waiting for the new hostname to reach DNS…")
    dim("  (a brand-new trycloudflare hostname takes 5-30s to appear)")
    deadline = time.time() + seconds
    while time.time() < deadline:
        pub = public_dns_has(host)
        if pub is None:  # DoH unreachable -> fall back to the local resolver
            pub = local_dns_has(host)
        if pub:
            break
        time.sleep(3)
    else:
        return False
    for _ in range(10):  # now it's safe to ask the local resolver
        if local_dns_has(host):
            return True
        time.sleep(2)
    warn("Public DNS has the name but this PC's resolver doesn't yet. Cana's servers can reach it;")
    dim("  for local checks run:  ipconfig /flushdns")
    return True


def rpc(url, method, params=None, req_id=1, headers=None):
    body = {"jsonrpc": "2.0", "method": method}
    if req_id is not None:
        body["id"] = req_id
    if params is not None:
        body["params"] = params
    return http(url, "POST", body=body, headers=headers, timeout=20)


def verify_mcp(mcp_url, mcp_key):
    """initialize + tools/list against mcp_url. Returns a list of problems."""
    problems = []
    headers = {MCP_KEY_HEADER: mcp_key} if mcp_key else {}

    # 1. reachable at all? (brand-new tunnels sometimes 502/530 for a few seconds)
    status = None
    for _ in range(12):
        try:
            status, _ = http(mcp_url, timeout=10)
        except Exception as e:  # noqa: BLE001
            status = f"{type(e).__name__}: {e}"
        if status == 200:
            break
        time.sleep(3)
    if status != 200:
        problems.append(f"GET {mcp_url} -> {status}")
        print(f"{C.red}✗{C.reset} MCP endpoint not reachable through the tunnel ({status})")
        return problems
    ok("MCP endpoint reachable through the tunnel")

    # 2. handshake
    st, text = rpc(mcp_url, "initialize", {"protocolVersion": "2024-11-05", "capabilities": {},
                                            "clientInfo": {"name": "tunnel-check", "version": "1"}}, headers=headers)
    if st == 200 and '"result"' in text:
        ok("initialize accepted")
    elif st == 401:
        problems.append("401 on initialize")
        print(f"{C.red}✗{C.reset} initialize rejected (401) — Cana's “Connect” would fail the same way.")
        dim(f"  {text.strip()[:200]}")
        return problems
    else:
        problems.append(f"initialize -> {st}")
        print(f"{C.red}✗{C.reset} initialize -> {st}: {text.strip()[:200]}")
        return problems

    # 3. tool discovery
    st, text = rpc(mcp_url, "tools/list", req_id=2, headers=headers)
    if st == 200:
        try:
            names = [t["name"] for t in json.loads(text)["result"]["tools"]]
            ok(f"tools/list returned {len(names)} tools")
        except Exception:  # noqa: BLE001
            problems.append("tools/list: unexpected body")
            print(f"{C.red}✗{C.reset} tools/list returned an unexpected body: {text[:200]}")
    else:
        problems.append(f"tools/list -> {st}")
        print(f"{C.red}✗{C.reset} tools/list -> {st}: {text.strip()[:200]}")
    return problems


# --------------------------------------------------------------------------
# Output
# --------------------------------------------------------------------------
def print_config(origin, mcp_url, issuer_url, app_id, signing_key, mcp_key):
    rule = f"{C.bold}{'─' * 72}{C.reset}"

    def row(label, value):
        print(f"  {C.dim}{label:<24}{C.reset}{value}")

    print(f"\n{rule}\n{C.bold}  Paste these into cana.build{C.reset}\n{rule}\n")
    row("Public MCP URL", f"{C.cyan}{mcp_url}{C.reset}")
    if mcp_key:
        row("Auth mode", f"Static credential — header {C.cyan}{MCP_KEY_HEADER}{C.reset} = {C.cyan}{mcp_key}{C.reset}")
    else:
        row("Auth mode", f"{C.red}NOT SET{C.reset} — see the warning below")
    row("Allowed origin", f"{C.cyan}{origin}{C.reset} {C.dim}(exact, no trailing slash){C.reset}")
    row("Access mode", f"{C.cyan}Authenticated{C.reset}")
    row("Issuer URL", f"{C.cyan}{issuer_url}{C.reset}")
    row("App ID", app_id or f"{C.yellow}not set in .env{C.reset}")
    if signing_key:
        row("Signing key", f"{C.green}configured{C.reset} (…{signing_key[-4:]})")
    else:
        row("Signing key", f"{C.red}MISSING in .env{C.reset}")

    if not mcp_key:
        suggestion = secrets.token_urlsafe(24)
        print(f"\n  {C.yellow}Action needed:{C.reset} Cana finds your tools by calling /api/mcp itself, before any user")
        print("  is logged in, so it needs a key. Add this line to .env, restart, then use it in Cana:")
        print(f"    {C.cyan}MCP_AUTH_KEY={suggestion}{C.reset}")

    print(f"\n{rule}\n{C.bold}  Do this, in order{C.reset}\n{rule}\n")
    steps = [
        "Open https://cana.build/apps → your App → Connectors → Add MCP connector (name: User Management).",
        f"MCP server URL: {C.cyan}{mcp_url}{C.reset}",
        f"Authentication: Static credential → header {C.cyan}{MCP_KEY_HEADER}{C.reset}, value = MCP_AUTH_KEY from .env.",
        "Click Connect (it discovers the tools). Reads → AUTO_RUN, writes → CONFIRM, then Connect & Save.",
        f"Embed tab → Allowed origins → add {C.cyan}{origin}{C.reset}",
        f"Embed tab → Issuer URL → {C.cyan}{issuer_url}{C.reset}",
        "Embed tab → copy the App ID + signing key into .env (CANA_APP_ID, CANA_APP_SIGNING_KEY), then restart this script.",
        "Set the App to Authenticated and publish it (status LIVE).",
    ]
    for i, step in enumerate(steps, 1):
        print(f"  {C.bold}{i}.{C.reset} {step}")
    print(f"\n  {C.yellow}IMPORTANT:{C.reset} every restart gives a NEW trycloudflare URL — update the Cana dashboard each time.\n")


def save_tunnel_config(origin, mcp_url, issuer_url, has_key):
    data = {
        "publicOrigin": origin,
        "publicMcpUrl": mcp_url,
        "allowedOrigin": origin,
        "issuerUrl": issuer_url,
        "accessMode": "AUTHENTICATED",
        "mcpAuthHeader": MCP_KEY_HEADER if has_key else None,
        "startedAt": datetime.now().isoformat(),
    }
    (ROOT / ".cana-tunnel.json").write_text(json.dumps(data, indent=2), encoding="utf-8")
    dim("Saved to .cana-tunnel.json")


# --------------------------------------------------------------------------
# main
# --------------------------------------------------------------------------
def main():
    parser = argparse.ArgumentParser(description="Expose the Flask app through a Cloudflare quick tunnel for Cana.")
    parser.add_argument("--verbose", action="store_true", help="show raw cloudflared log lines")
    parser.add_argument("--protocol", choices=["http2", "quic", "auto"],
                        default=os.getenv("CLOUDFLARED_PROTOCOL", "http2"),
                        help="tunnel transport (default http2 — QUIC/UDP is often blocked)")
    parser.add_argument("--no-verify", action="store_true", help="skip checks through the public URL")
    args = parser.parse_args()

    load_env()
    port = int(os.getenv("FLASK_PORT", "5003"))
    app_id = os.getenv("CANA_APP_ID", "").strip()
    signing_key = os.getenv("CANA_APP_SIGNING_KEY", "").strip()
    mcp_key = os.getenv("MCP_AUTH_KEY", "").strip()

    print(f"\n{C.bold}User Management + Cana tunnel{C.reset}\n")

    cloudflared = check_cloudflared()
    ensure_flask(port)
    check_database(port)

    tunnel = open_tunnel(cloudflared, port, args.protocol, args.verbose)
    origin = tunnel.url
    mcp_url = f"{origin}/api/mcp"
    issuer_url = f"{origin}/api/cana-token"

    if not args.no_verify:
        print()
        host = origin.split("://", 1)[1]
        if not wait_for_dns(host):
            die(
                f"{host} still does not resolve after 90s.",
                "cloudflared printed a URL but it never reached DNS. This is a transient Cloudflare\n"
                "  quick-tunnel hiccup — just run `python tunnel.py` again.",
            )
        info("Verifying MCP through the public URL…")
        problems = verify_mcp(mcp_url, mcp_key)
        if problems:
            warn("Fix the item(s) above before clicking Connect in Cana. The tunnel itself is running.")

    print_config(origin, mcp_url, issuer_url, app_id, signing_key, mcp_key)
    save_tunnel_config(origin, mcp_url, issuer_url, bool(mcp_key))

    dim("Tunnel is running. Press Ctrl-C to stop.\n")
    try:
        while True:
            if not tunnel.alive():
                die("cloudflared stopped unexpectedly.", "Last output:\n    " + "\n    ".join(list(tunnel.tail)[-5:]))
            for label, proc in _children:
                if label == "flask" and proc.poll() is not None:
                    die("The Flask process we started has stopped.", f"See flask-tunnel.log:\n{_tail_file(ROOT / 'flask-tunnel.log')}")
            time.sleep(1)
    except KeyboardInterrupt:
        print("\nShutting down…")
        sys.exit(0)  # atexit stops cloudflared (and Flask, if we started it)


if __name__ == "__main__":
    main()
