"""
lib/jwt_utils.py
================
HS256 JWT encoding and decoding helpers for Cana token exchange.
"""

import time
import uuid
import jwt
from datetime import datetime, timedelta
from typing import Dict, Any


def encode_jwt(payload: Dict[str, Any], signing_key: str, expires_in_minutes: int = 60) -> str:
    """
    Encode a JWT token with HS256.
    
    Args:
        payload: Dict to encode (should include 'sub' for user_id)
        signing_key: Secret key for HS256 signing
        expires_in_minutes: Token lifetime in minutes
    
    Returns:
        JWT token string
    """
    # Add expiration if not already present
    if "exp" not in payload:
        payload["exp"] = datetime.utcnow() + timedelta(minutes=expires_in_minutes)
    
    # Encode with HS256
    token = jwt.encode(
        payload,
        signing_key,
        algorithm="HS256"
    )
    
    return token


def decode_jwt(token: str, signing_key: str) -> Dict[str, Any]:
    """
    Decode and validate a JWT token with HS256.
    
    Args:
        token: JWT token string
        signing_key: Secret key for HS256 verification
    
    Returns:
        Decoded payload dict
    
    Raises:
        jwt.InvalidTokenError: If token is invalid, expired, or tampered
    """
    try:
        payload = jwt.decode(
            token,
            signing_key,
            algorithms=["HS256"],
            options={"verify_sub": False}  # Allow any sub type (int, str, etc.)
        )
        return payload
    except jwt.ExpiredSignatureError:
        raise ValueError("Token has expired")
    except jwt.InvalidTokenError as e:
        raise ValueError(f"Invalid token: {str(e)}")


def create_cana_token(user_id: int, email: str, first_name: str, last_name: str,
                      role: str, signing_key: str, app_id: str,
                      expires_in_minutes: int = 15,
                      metadata: Dict[str, Any] | None = None) -> str:
    """
    Create a Cana visitor JWT for the embedded chat widget.

    What cana.build verifies (same contract as the working cana-apps-demo):
      - JOSE *header*  kid = the App id      <-- header, NOT a payload claim
      - claim  sub     = your user's id (string)
      - claim  exp     = expiry (Cana clamps it to the App's max token age)
      - claim  jti     = unique per token; Cana's replay protection rejects repeats
      - optional: email, name, metadata (free-form, visible to the agent)

    A token with `kid` only in the payload, or without `jti`, is rejected
    with token_invalid — the widget then shows "Authentication required".
    """
    now = int(time.time())
    # Cana accepts 5–60 min; stay inside that window.
    ttl_seconds = min(max(int(expires_in_minutes * 60), 300), 3600)

    payload = {
        "sub": str(user_id),  # Cana expects a string sub
        "email": email,
        "name": f"{first_name} {last_name}".strip(),
        "metadata": {"role": role, "userId": user_id, **(metadata or {})},
        "iat": now,
        "exp": now + ttl_seconds,
        "jti": str(uuid.uuid4()),
    }

    return jwt.encode(
        payload,
        signing_key,
        algorithm="HS256",
        headers={"kid": app_id, "typ": "JWT"},
    )
