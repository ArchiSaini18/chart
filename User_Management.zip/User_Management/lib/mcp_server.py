"""
lib/mcp_server.py
=================
Transport-agnostic MCP server implementation.
Defines MCP tools and handlers that are called by routers/mcp_router.py over HTTP.

Key architecture:
- McpTool class describes each tool (name, description, schema, handler)
- handleRpc() implements JSON-RPC 2.0 dispatch
- Each handler performs authorization checks + calls services
- Authorization: JWT validation (Layer 1) → tool access (Layer 2) → arg augmentation (Layer 3) → handler checks (Layer 4)
"""

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import json
from dataclasses import dataclass, asdict
from typing import Any, Callable, Optional, Dict
import services.user_service as user_service
import services.tower_service as tower_service
import services.ticket_service as ticket_service
import services.entity_audit_service as audit_service


# ============================================================
# McpTool class — describes a single RPC-callable tool
# ============================================================

@dataclass
class McpTool:
    """A tool that the MCP server exposes"""
    name: str
    description: str
    inputSchema: Dict[str, Any]
    handler: Callable
    suggestedPermission: str = "AUTO_RUN"  # AUTO_RUN or CONFIRM
    
    def to_descriptor(self) -> dict:
        """Convert to MCP tool descriptor for tools/list response"""
        return {
            "name": self.name,
            "description": self.description,
            "inputSchema": self.inputSchema,
            "annotations": {
                "suggestedPermission": self.suggestedPermission,
            }
        }


# ============================================================
# Tool Handlers — authorization + service calls
# ============================================================

def get_user_handler(args: dict, user_id: int, user_role: str) -> str:
    """
    Get one user's profile.
    User (role=user): can only get their own profile.
    Admin (role=admin): can get any user.
    """
    requested_user_id = args.get("user_id")
    
    # LAYER 4: Defensive check
    if user_role != "admin" and requested_user_id != user_id:
        raise ValueError(
            f"Cannot view user {requested_user_id}. "
            f"You can only view your own profile (user {user_id})"
        )
    
    user = user_service.get_user(requested_user_id)
    if not user:
        raise ValueError(f"User {requested_user_id} not found")
    
    # Format as compact text
    return (
        f"User {requested_user_id} — {user['first_name']} {user['last_name']}\n"
        f"Email: {user['email']}\n"
        f"Status: {user.get('status', 'N/A')}\n"
        f"Phone: {user.get('phone_number', 'N/A')}"
    )


def list_users_handler(args: dict, user_id: int, user_role: str) -> str:
    """
    List users.
    Admin: sees all users.
    User: only sees their own profile (flagged by _self_only).
    """
    limit = args.get("limit", 50)
    self_only = args.get("_self_only", False)
    
    if self_only and user_role != "admin":
        # User requested list_users, but return only self
        user = user_service.get_user(user_id)
        if not user:
            return f"0 user(s)"
        return (
            f"1 user(s):\n"
            f"- {user_id} | {user['first_name']} {user['last_name']} | {user['email']}"
        )
    
    # Admin path: return all users
    if user_role != "admin":
        raise ValueError("Only admins can list all users")
    
    users = user_service.list_users(limit=limit, include_ids=True)
    
    lines = [f"{len(users)} user(s):"]
    for u in users[:limit]:
        lines.append(
            f"- {u['id']} | {u['first_name']} {u['last_name']} | {u['email']} | {u.get('status', 'N/A')} | {u.get('role', 'N/A')}"
        )
    
    return "\n".join(lines)


def create_user_handler(args: dict, user_id: int, user_role: str) -> str:
    """
    Create a new user.
    ADMIN ONLY.
    """
    # LAYER 4: Defensive check
    if user_role != "admin":
        raise ValueError("Only admins can create users")
    
    first_name = args.get("first_name")
    last_name = args.get("last_name")
    email = args.get("email")
    
    if not first_name or not last_name or not email:
        raise ValueError("Missing required fields: first_name, last_name, email")
    
    result = user_service.create_user({
        "first_name": first_name,
        "last_name": last_name,
        "email": email,
        "status": args.get("status", "active"),
        "role": args.get("role", "user"),
        "created_by": user_id,  # AUDIT: record admin who created this
    })
    
    audit_service.log_action(
        action="INSERT",
        table="users",
        record_id=result["id"],
        user_id=user_id
    )
    
    return f"User {result['id']} created — {first_name} {last_name} ({email})"


def update_user_handler(args: dict, user_id: int, user_role: str) -> str:
    """
    Update a user.
    Admin: can update anyone + all fields.
    User: can only update self + limited fields (_allowed_fields is set by Layer 3).
    """
    target_user_id = args.get("user_id")
    update_data = args.get("data", {})
    allowed_fields = args.get("_allowed_fields")
    
    # LAYER 4: Defensive check for non-admin
    if user_role != "admin":
        if target_user_id != user_id:
            raise ValueError(
                f"You can only update your own profile, not user {target_user_id}"
            )
        
        # Filter to only allowed fields
        if allowed_fields:
            update_data = {k: v for k, v in update_data.items() if k in allowed_fields}
    
    if not update_data:
        raise ValueError("No fields to update")
    
    result = user_service.update_user(target_user_id, update_data)
    
    audit_service.log_action(
        action="UPDATE",
        table="users",
        record_id=target_user_id,
        user_id=user_id
    )
    
    return f"User {target_user_id} updated by {'the Cana connector (admin)' if user_id is None else f'user {user_id}'}"


def delete_user_handler(args: dict, user_id: int, user_role: str) -> str:
    """
    Delete a user.
    ADMIN ONLY.
    """
    # LAYER 4: Defensive check
    if user_role != "admin":
        raise ValueError("Only admins can delete users")
    
    target_user_id = args.get("user_id")
    
    user_service.delete_user(target_user_id)
    
    audit_service.log_action(
        action="DELETE",
        table="users",
        record_id=target_user_id,
        user_id=user_id
    )
    
    return f"User {target_user_id} deleted by {'the Cana connector (admin)' if user_id is None else f'admin {user_id}'}"


def get_tower_handler(args: dict, user_id: int, user_role: str) -> str:
    """
    Get one tower.
    ADMIN ONLY.
    """
    if user_role != "admin":
        raise ValueError("Only admins can view tower details")
    
    tower_id = args.get("tower_id")
    tower = tower_service.get_tower(tower_id)
    
    if not tower:
        raise ValueError(f"Tower {tower_id} not found")
    
    return (
        f"Tower {tower_id} — {tower.get('tower_code', 'N/A')}\n"
        f"City: {tower.get('tower_city', 'N/A')}\n"
        f"Technology: {tower.get('technology', 'N/A')}\n"
        f"Status: {tower.get('tower_status', 'N/A')}"
    )


def list_towers_handler(args: dict, user_id: int, user_role: str) -> str:
    """
    List towers.
    ADMIN ONLY.
    """
    if user_role != "admin":
        raise ValueError("Only admins can list towers")
    
    limit = args.get("limit", 50)
    towers = tower_service.list_towers(limit=limit, include_ids=True)
    
    lines = [f"{len(towers)} tower(s):"]
    for t in towers[:limit]:
        lines.append(
            f"- {t['id']} | {t.get('tower_code', 'N/A')} | {t.get('tower_city', 'N/A')} | {t.get('technology', 'N/A')}"
        )
    
    return "\n".join(lines)


def create_ticket_handler(args: dict, user_id: int, user_role: str) -> str:
    """
    Create a support ticket.
    User: creates their own ticket (user_id forced by Layer 3).
    Admin: can create for any user.
    """
    target_user_id = args.get("user_id")
    subject = args.get("ticket_subject")
    
    if not subject:
        raise ValueError("Missing required field: ticket_subject")
    
    result = ticket_service.create_ticket({
        "user_id": target_user_id,
        "ticket_subject": subject,
        "ticket_priority": args.get("ticket_priority", "Medium"),
        "ticket_status": "Open",
        "created_by": user_id,  # AUDIT
    })
    
    audit_service.log_action(
        action="INSERT",
        table="tickets",
        record_id=result["id"],
        user_id=user_id
    )
    
    return f"Ticket {result['id']} created for user {target_user_id}"


# ============================================================
# MCP Tool Definitions
# ============================================================

TOOLS = [
    # Read tools (AUTO_RUN)
    McpTool(
        name="get_user",
        description="Get a user's profile. Non-admins can only view their own profile.",
        inputSchema={
            "type": "object",
            "properties": {
                "user_id": {"type": "integer", "description": "User ID to fetch"}
            },
            "required": ["user_id"]
        },
        handler=get_user_handler,
        suggestedPermission="AUTO_RUN"
    ),
    
    McpTool(
        name="list_users",
        description="List all users (admins only). Non-admins can only see their own profile.",
        inputSchema={
            "type": "object",
            "properties": {
                "limit": {"type": "integer", "description": "Max users to return", "default": 50}
            }
        },
        handler=list_users_handler,
        suggestedPermission="AUTO_RUN"
    ),
    
    McpTool(
        name="get_tower",
        description="Get a tower's details (admins only).",
        inputSchema={
            "type": "object",
            "properties": {
                "tower_id": {"type": "integer", "description": "Tower ID to fetch"}
            },
            "required": ["tower_id"]
        },
        handler=get_tower_handler,
        suggestedPermission="AUTO_RUN"
    ),
    
    McpTool(
        name="list_towers",
        description="List all towers (admins only).",
        inputSchema={
            "type": "object",
            "properties": {
                "limit": {"type": "integer", "description": "Max towers to return", "default": 50}
            }
        },
        handler=list_towers_handler,
        suggestedPermission="AUTO_RUN"
    ),
    
    # Write tools (CONFIRM)
    McpTool(
        name="create_user",
        description="Create a new user (admins only). Requires: first_name, last_name, email.",
        inputSchema={
            "type": "object",
            "properties": {
                "first_name": {"type": "string", "description": "First name"},
                "last_name": {"type": "string", "description": "Last name"},
                "email": {"type": "string", "description": "Email address"},
                "status": {"type": "string", "description": "active|inactive|suspended", "default": "active"},
                "role": {"type": "string", "description": "admin|user", "default": "user"},
            },
            "required": ["first_name", "last_name", "email"]
        },
        handler=create_user_handler,
        suggestedPermission="CONFIRM"
    ),
    
    McpTool(
        name="update_user",
        description="Update a user. Non-admins can only update themselves + limited fields.",
        inputSchema={
            "type": "object",
            "properties": {
                "user_id": {"type": "integer", "description": "User ID to update"},
                "data": {
                    "type": "object",
                    "description": "Fields to update (first_name, last_name, email, phone_number, status, role, etc.)",
                    "additionalProperties": True
                }
            },
            "required": ["user_id", "data"]
        },
        handler=update_user_handler,
        suggestedPermission="CONFIRM"
    ),
    
    McpTool(
        name="delete_user",
        description="Delete a user (admins only).",
        inputSchema={
            "type": "object",
            "properties": {
                "user_id": {"type": "integer", "description": "User ID to delete"}
            },
            "required": ["user_id"]
        },
        handler=delete_user_handler,
        suggestedPermission="CONFIRM"
    ),
    
    McpTool(
        name="create_ticket",
        description="Create a support ticket. Non-admins create only for themselves.",
        inputSchema={
            "type": "object",
            "properties": {
                "user_id": {"type": "integer", "description": "User ID who owns this ticket"},
                "ticket_subject": {"type": "string", "description": "Ticket subject/title"},
                "ticket_priority": {"type": "string", "description": "Low|Medium|High", "default": "Medium"},
            },
            "required": ["user_id", "ticket_subject"]
        },
        handler=create_ticket_handler,
        suggestedPermission="CONFIRM"
    ),
]


# ============================================================
# Authorization Layers 2 & 3
# ============================================================

def _has_tool_access(tool_name: str, user_role: str) -> bool:
    """
    LAYER 2: Check if user role has access to this tool.
    Returns True if allowed, False otherwise.
    """
    admin_only_tools = {
        "list_users",
        "create_user",
        "update_user",
        "delete_user",
        "get_tower",
        "list_towers",
    }
    
    if tool_name in admin_only_tools:
        return user_role == "admin"
    
    user_allowed_tools = {
        "get_user",
        "create_ticket",
    }
    
    return tool_name in user_allowed_tools or user_role == "admin"


def _augment_tool_args(tool_name: str, args: dict, user_id: int, user_role: str) -> dict:
    """
    LAYER 3: Modify tool arguments based on user role.
    This enforces: "non-admins see only their own data".
    
    Returns modified args dict.
    """
    if user_role == "admin":
        # No modification for admins
        return args
    
    # For regular USERS, modify arguments
    
    if tool_name == "get_user":
        # Force user to view only themselves
        args["user_id"] = user_id
        return args
    
    if tool_name == "list_users":
        # Flag handler to return only self
        args["_self_only"] = True
        return args
    
    if tool_name == "update_user":
        # Force user to update only themselves
        args["user_id"] = user_id
        # Restrict fields (no role/status changes)
        args["_allowed_fields"] = {
            "first_name", "last_name", "email", "phone_number", "address"
        }
        return args
    
    if tool_name == "create_ticket":
        # User can only create tickets for themselves
        args["user_id"] = user_id
        return args
    
    return args


# ============================================================
# JSON-RPC 2.0 Handler
# ============================================================

PROTOCOL_VERSION = "2024-11-05"
SERVER_INFO = {"name": "User Management MCP", "version": "1.0.0"}


def _ok(msg_id, result: dict) -> dict:
    return {"jsonrpc": "2.0", "id": msg_id, "result": result}


def _fail(msg_id, code: int, message: str) -> dict:
    return {"jsonrpc": "2.0", "id": msg_id, "error": {"code": code, "message": message}}


async def handleRpc(msg: dict, user_id: Optional[int], user_role: str) -> Optional[dict]:
    """
    Handle one JSON-RPC 2.0 message (same behaviour as the working
    cana-apps-demo's handleRpc).

    Returns the response dict, or None for notifications (they get no reply).

    Cana's client calls, in order:
        initialize -> notifications/initialized -> tools/list -> tools/call
    """
    if not isinstance(msg, dict):
        return _fail(None, -32600, "Invalid Request")

    method = msg.get("method")
    params = msg.get("params") or {}
    msg_id = msg.get("id")

    if not isinstance(method, str):
        return _fail(msg_id, -32600, "Invalid Request: missing method")

    # Notifications carry no id and get no response.
    if method.startswith("notifications/"):
        return None

    if method == "initialize":
        return _ok(msg_id, {
            "protocolVersion": PROTOCOL_VERSION,
            "capabilities": {"tools": {"listChanged": False}},
            "serverInfo": SERVER_INFO,
        })

    if method == "ping":
        return _ok(msg_id, {})

    if method == "tools/list":
        return _ok(msg_id, {"tools": [tool.to_descriptor() for tool in TOOLS]})

    if method == "tools/call":
        tool_name = params.get("name")
        if not isinstance(tool_name, str) or not tool_name:
            return _fail(msg_id, -32602, "Invalid params: tools/call requires a tool name")

        tool = next((t for t in TOOLS if t.name == tool_name), None)
        if not tool:
            names = ", ".join(t.name for t in TOOLS)
            return _fail(msg_id, -32602, f'Unknown tool "{tool_name}". Available: {names}')

        raw_args = params.get("arguments")
        tool_args = dict(raw_args) if isinstance(raw_args, dict) else {}

        # A tool that refuses or fails is a TOOL error, not a protocol error:
        # it comes back as readable text with isError=true so the model can
        # explain it to the person (or correct itself) instead of the whole
        # call surfacing as a connector failure.
        try:
            # LAYER 2: Check tool access
            if not _has_tool_access(tool_name, user_role):
                raise ValueError(f"You do not have permission to call tool '{tool_name}'")

            # LAYER 3: Augment arguments based on user role
            augmented_args = _augment_tool_args(tool_name, tool_args, user_id, user_role)

            # LAYER 4: Call handler (handler does its own defensive checks)
            result_text = tool.handler(augmented_args, user_id, user_role)
            return _ok(msg_id, {
                "content": [{"type": "text", "text": result_text}],
                "isError": False,
            })
        except Exception as e:
            return _ok(msg_id, {
                "content": [{"type": "text", "text": f"Error: {e}"}],
                "isError": True,
            })

    return _fail(msg_id, -32601, f"Method not found: {method}")


def toolByName(name: str) -> Optional[McpTool]:
    """Find a tool by name"""
    return next((t for t in TOOLS if t.name == name), None)
