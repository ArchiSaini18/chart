import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import psycopg2
from psycopg2 import sql

try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    pass

from config import DB_CONFIG, DB_NAME


# ============================================================
# 1. CREATE THE DATABASE IF IT DOESN'T EXIST
# ============================================================
def create_database_if_not_exists():
    # Connect to the default "postgres" maintenance database first,
    # since you can't create a database while connected to it.
    conn = psycopg2.connect(dbname="postgres", **DB_CONFIG)
    conn.autocommit = True
    cursor = conn.cursor()

    cursor.execute("SELECT 1 FROM pg_database WHERE datname = %s", (DB_NAME,))
    exists = cursor.fetchone()

    if not exists:
        cursor.execute(sql.SQL("CREATE DATABASE {}").format(sql.Identifier(DB_NAME)))
        print(f"Database '{DB_NAME}' created.")
    else:
        print(f"Database '{DB_NAME}' already exists.")

    cursor.close()
    conn.close()


# ============================================================
# 2. CREATE TABLES (in FK-safe order: users first, then children)
# ============================================================

def create_tables():
    conn = psycopg2.connect(dbname=DB_NAME, **DB_CONFIG)
    cursor = conn.cursor()

    print(f"Connected to '{DB_NAME}'.")

    # Drop in reverse dependency order so foreign keys don't block the drop.
    cursor.execute("DROP TABLE IF EXISTS entity_audit_log")
    cursor.execute("DROP TABLE IF EXISTS tickets")
    cursor.execute("DROP TABLE IF EXISTS towers")
    cursor.execute("DROP TABLE IF EXISTS users")

    # ---------------- USERS (parent table) ----------------
    cursor.execute("""
        CREATE TABLE users (
            id              SERIAL PRIMARY KEY,
            first_name      VARCHAR(50)  NOT NULL,
            last_name       VARCHAR(50)  NOT NULL,
            phone_number    VARCHAR(20),
            email           VARCHAR(150) UNIQUE NOT NULL,
            address         TEXT,
            password        VARCHAR(255) NOT NULL,  -- salted hash (werkzeug), never the raw password
            status          VARCHAR(30)  DEFAULT 'active',
            role            VARCHAR(20)  NOT NULL DEFAULT 'user'
                            CHECK (role IN ('admin', 'user')),
            created_by      INT REFERENCES users(id) ON DELETE SET NULL,
            updated_by      INT REFERENCES users(id) ON DELETE SET NULL,
            created_at      TIMESTAMP DEFAULT NOW(),
            updated_at      TIMESTAMP DEFAULT NOW()
        )
    """)
    print("Table 'users' created.")

    # ---------------- TOWERS (child of users) ----------------
    cursor.execute("""
        CREATE TABLE towers (
            id              SERIAL PRIMARY KEY,
            tower_code      VARCHAR(50),
            tower_city      VARCHAR(50),
            tower_area      VARCHAR(100),
            technology      VARCHAR(30),
            tower_status    VARCHAR(30),
            user_id         INT REFERENCES users(id) ON DELETE SET NULL,
            created_at      TIMESTAMP DEFAULT NOW()
        )
    """)
    print("Table 'towers' created.")

    # ---------------- TICKETS (child of users) ----------------
    cursor.execute("""
        CREATE TABLE tickets (
            id                  SERIAL PRIMARY KEY,
            user_id             INT REFERENCES users(id) ON DELETE CASCADE,
            ticket_subject      VARCHAR(200),
            ticket_description  TEXT,
            ticket_category     VARCHAR(50),
            ticket_priority     VARCHAR(30),
            ticket_status       VARCHAR(30),
            created_at          TIMESTAMP DEFAULT NOW()
        )
    """)
    print("Table 'tickets' created.")

    # ---------------- ENTITY_AUDIT_LOG (child of users) ----------------
    cursor.execute("""
        CREATE TABLE entity_audit_log (
            id                  SERIAL PRIMARY KEY,
            user_id             INT REFERENCES users(id) ON DELETE SET NULL,
            audit_action        VARCHAR(100),
            entity_type         VARCHAR(50),
            entity_id           INT,
            audit_description   TEXT,
            created_at          TIMESTAMP DEFAULT NOW()
        )
    """)
    print("Table 'entity_audit_log' created.")

    conn.commit()
    cursor.close()
    conn.close()
    print("\nAll tables created successfully.")


if __name__ == "__main__":
    create_database_if_not_exists()
    create_tables()
