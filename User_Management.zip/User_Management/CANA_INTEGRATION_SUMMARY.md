# Cana Apps Integration — Quick Reference

## What You Need to Know

### 🎯 3 Terminals, 1 Workflow

This system requires **3 running terminals** to work end-to-end:

| Terminal | Task | Command | Keep Running |
|----------|------|---------|--------------|
| **1** | Flask Backend | `python app.py` | ✅ YES (required) |
| **2** | PostgreSQL | `psql -U postgres -d telecom_db` | ✅ YES (if testing) |
| **3** | Cloudflare Tunnel | `python tunnel.py` | ✅ YES (required for Cana) |

---

## 📋 Terminal 1: Flask Backend

**Location**: `User_Management/User_Management`

**One-time setup**:
```bash
python -m venv venv
venv\Scripts\activate          # Windows
# source venv/bin/activate    # macOS/Linux
pip install -r requirements.txt
cp .env.example .env
# Edit .env and add CANA_APP_ID + CANA_APP_SIGNING_KEY
python create_table.py         # Create database (one-time)
python seed_data.py            # Load sample data (optional)
```

**Every time you start**:
```bash
python app.py
# Runs on http://localhost:5002
```

**Expected output**:
```
 * Running on http://127.0.0.1:5002
 * WARNING: This is a development server. Do not use it in production.
```

**Keep this terminal open** ← Cana widget calls this Flask app.

---

## 📊 Terminal 2: PostgreSQL

**Verify it's running** (you likely don't need a terminal for this):

```bash
# If you have psql installed:
psql -U postgres -d telecom_db
\dt                            # List tables
\q                             # Quit

# If not installed, just verify PostgreSQL is running via:
# - Windows Services (search: services.msc)
# - Or check: pg_isready -h localhost
```

**You may close this terminal** after verification. PostgreSQL runs as a service.

---

## 🌐 Terminal 3: Cloudflare Tunnel

**One-time setup** (on Windows):
```bash
# Install cloudflared
scoop install cloudflare
# OR
choco install cloudflare
# OR download from https://github.com/cloudflare/cloudflared/releases

# Verify
cloudflared --version
```

**Every time you start**:
```bash
cd User_Management/User_Management
python tunnel.py
```

**Expected output**:
```
Checking cloudflared binary... OK
Checking Flask on http://localhost:5002... OK
Starting Cloudflare tunnel...
Tunnel created: https://xyz-abc-123.trycloudflare.com

Setup Instructions for cana.build:
  1. Go to cana.build dashboard → Connectors → New MCP Connector
  2. Name: "User Management"
  3. MCP URL: https://xyz-abc-123.trycloudflare.com/api/mcp
  4. Save
  
  5. Go to App Settings → Issuer URL
  6. Set to: https://xyz-abc-123.trycloudflare.com/api/cana-token
  7. Save
  
  8. Go to Embed Origins
  9. Add: https://xyz-abc-123.trycloudflare.com
  10. Save

Config saved to: .cana-tunnel.json
Press Ctrl+C to stop tunnel.
```

**Keep this terminal open** ← Cana widget calls this tunnel.

---

## ✅ Quick Startup Checklist

- [ ] **Terminal 1**: `python app.py` running (http://localhost:5002)
- [ ] **Terminal 2**: PostgreSQL verified running
- [ ] **Terminal 3**: `python tunnel.py` running (tunnel URL printed)
- [ ] **cana.build**: Configured with tunnel URL + issuer URL + embed origin
- [ ] **Login**: Go to http://localhost:5002, log in with seeded credentials
- [ ] **Widget**: Open Cana widget, test a query (e.g., "List users")

---

## 🔑 Configuration (.env)

**Required for Cana integration**:
```env
CANA_APP_ID=your_app_id_from_cana_build
CANA_APP_SIGNING_KEY=your_signing_key_from_cana_build
```

Get these from **cana.build** → **App Settings** → **API Keys**.

---

## 🤖 What Cana Can Do

**As Admin**:
- "List all users" → Returns 50 users
- "Create a user" → Creates new account
- "Delete user #5" → Deletes user (requires confirmation)

**As Regular User**:
- "Show my profile" → Shows own details
- "Create a ticket" → Creates support ticket
- "List users" → DENIED (admin-only)
- "Delete user" → DENIED (admin-only)

---

## 🐛 Troubleshooting

| Issue | Fix |
|-------|-----|
| "Connection refused" | Flask not running (Terminal 1) |
| "Invalid token" | CANA_APP_SIGNING_KEY mismatch between .env and cana.build |
| "Tunnel connection refused" | Cloudflare tunnel not running (Terminal 3) |
| "User sees other user's data" | Bug in authorization layer (Layer 3) |
| "Tunnel URL keeps changing" | Normal — free tunnels are temporary. Update cana.build with new URL |

---

## 📚 Full Documentation

See **README.md** for:
- Complete API endpoint list
- Authorization rules & examples
- MCP tool descriptions
- Architecture diagrams
- Database schema

---

## 🎓 How It Works (High Level)

```
Browser (User logs in)
    ↓
Flask Session Created
    ↓
Cana Widget Loads
    ↓
GET /api/cana-token
    ↓
JWT minted (with user_id + role)
    ↓
Widget displays chat interface
    ↓
User: "List all users"
    ↓
Cana: POST /api/mcp (with JWT)
    ↓
Flask validates JWT
    ↓
MCP Server checks authorization
    ↓
Admin? → 50 users returned
User? → "Permission denied"
```

---

## 📞 Support

- **Tunnel issues**: Check cloudflared version (`cloudflared --version`)
- **JWT issues**: Verify CANA_APP_SIGNING_KEY is set
- **Flask issues**: Check http://localhost:5002 is accessible
- **Database issues**: Verify PostgreSQL is running (Windows Services)

---

**Last Updated**: September 2024  
**Status**: Production Ready
