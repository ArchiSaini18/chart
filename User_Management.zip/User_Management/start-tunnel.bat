@echo off
REM Simple script to start the tunnel - run this in a new terminal window
REM Keep this window open while using the Cana app

echo Starting User Management Tunnel...
echo.
echo NOTE: Keep this window open. The tunnel URL will be printed below.
echo Every time you close and restart, you get a NEW tunnel URL.
echo.
python tunnel.py
pause
