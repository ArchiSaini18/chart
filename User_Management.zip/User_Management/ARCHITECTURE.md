# System Architecture — Complete Overview

## 🏗️ High-Level Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                      USER'S BROWSER                             │
│  http://localhost:5002 (login, admin/user dashboards)          │
└────────────┬─────────────────────────────────────────────────────┘
             │ (HTTP fetch + Flask session cookie)
             ▼
┌─────────────────────────────────────────────────────────────────┐
│              FLASK APP (Terminal 1)                              │
│  - app.py entrypoint                                            │
│  - 5 REST API routers: auth, users, towers, tickets, audit      │
│  - 2 Cana routers: /api/mcp, /api/cana-token                    │
│  - Session-based auth for regular API                           │
│  - JWT-based auth for Cana widget                               │
│                                                                  │
│  ┌─ REST Endpoints ──────────────────────────────────────────┐  │
│  │ POST /api/auth/login          (email + password)          │  │
│  │ POST /api/auth/signup         (create account)            │  │
│  │ GET  /api/users               (admin only)                │  │
│  │ POST /api/users               (admin only)                │  │
│  │ PUT  /api/users/:id           (admin or self)             │  │
│  │ DELETE /api/users/:id         (admin only)                │  │
│  │ GET  /api/towers              (admin only)                │  │
│  │ GET  /api/tickets             (own or all if admin)       │  │
│  │ GET  /api/entity-audit-log    (admin only)                │  │
│  └────────────────────────────────────────────────────────────┘  │
│                                                                  │
│  ┌─ Cana Integration Endpoints ──────────────────────────────┐  │
│  │ GET  /api/cana-token          (JWT issuer for widget)     │  │
│  │ POST /api/mcp                 (JSON-RPC MCP handler)      │  │
│  │ GET  /api/mcp                 (tool descriptor list)      │  │
│  └────────────────────────────────────────────────────────────┘  │
│                                                                  │
│  ┌─ Service Layer ────────────────────────────────────────────┐  │
│  │ auth_service.py     (login/signup + bcrypt hashing)       │  │
│  │ user_service.py     (CRUD + validation)                   │  │
│  │ tower_service.py    (CRUD + validation)                   │  │
│  │ ticket_service.py   (CRUD + scoping)                      │  │
│  │ entity_audit_service.py (logging all actions)             │  │
│  │ authz.py            (role-based access control)           │  │
│  │ jwt_utils.py        (JWT encode/decode)                   │  │
│  │ mcp_server.py       (8 MCP tools + 4-layer auth)          │  │
│  └────────────────────────────────────────────────────────────┘  │
│                                                                  │
│  ┌─ Model Layer (SQL) ────────────────────────────────────────┐  │
│  │ user_model.py       (SELECT/INSERT/UPDATE/DELETE users)   │  │
│  │ tower_model.py      (SELECT/INSERT/UPDATE/DELETE towers)  │  │
│  │ ticket_model.py     (SELECT/INSERT/UPDATE/DELETE tickets) │  │
│  │ entity_audit_model.py (log all mutations)                 │  │
│  └────────────────────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────────────┘
             │ (psycopg2 driver)
             ▼
┌─────────────────────────────────────────────────────────────────┐
│              POSTGRESQL DATABASE                                 │
│  - users (id, email, password_hash, first_name, role, status)   │
│  - towers (id, code, city, area, technology, status)            │
│  - tickets (id, user_id, category, priority, status, notes)     │
│  - entity_audit_log (id, entity, action, old/new, created_by)   │
└─────────────────────────────────────────────────────────────────┘
```

---

## 🤖 Cana Integration Flow

```
SEPARATE FLOW: Cana Widget Integration
═════════════════════════════════════════════════════════════════

1. User Opens Dashboard
   └─→ Flask session created (via /api/auth/login)

2. Cana Widget Loads (in browser)
   └─→ Calls GET /api/cana-token
   └─→ Flask checks Flask session (user_id in session)
   └─→ Returns JWT signed with CANA_APP_SIGNING_KEY

3. User Asks Question in Cana Chat
   ("List all users" / "Show my profile" / etc.)
   └─→ Cana.build receives question
   └─→ Cana calls POST /api/mcp
   └─→ Payload: {method: "tools/call", params: {name: "list_users", arguments: {}}}
   └─→ Header: Authorization: Bearer <JWT>

4. Flask Processes MCP Request
   
   ┌─ Layer 1: JWT Validation ─────────────────┐
   │ - Extract JWT from Authorization header   │
   │ - Verify signature (CANA_APP_SIGNING_KEY) │
   │ - Check expiration (60 minutes)           │
   │ - Extract user_id + role ("admin"/"user") │
   └──────────────────────────────────────────┘
            ↓
   ┌─ Layer 2: Tool Access Control ────────────┐
   │ - Admin tools: list_users, create_user,    │
   │   update_user, delete_user, list_towers    │
   │ - User tools: get_user, create_ticket      │
   │ - Deny if user calls admin tool            │
   └──────────────────────────────────────────┘
            ↓
   ┌─ Layer 3: Argument Augmentation ──────────┐
   │ - Non-admin users: force user_id to self   │
   │ - Filter fields (whitelist visible fields) │
   └──────────────────────────────────────────┘
            ↓
   ┌─ Layer 4: Handler Execution ──────────────┐
   │ - Call handler function (e.g., list_users)│
   │ - Query database                          │
   │ - Return results as text                  │
   └──────────────────────────────────────────┘

5. Flask Returns Response
   └─→ JSON-RPC format: {result: {content: [{type: "text", text: "..."}]}}

6. Cana Processes Response
   └─→ Parses text
   └─→ Sends to LLM for natural language response
   └─→ Displays to user in chat

Example Dialog:
───────────────

USER:  "List all users"
CANA:  [calls /api/mcp with tool=list_users]
FLASK: [Layer 2 check] Admin? YES → allowed
       [Layer 4 query] SELECT * FROM users LIMIT 50
       Returns: "User 1: alice@ex.com (admin) [active]..."
CANA:  [LLM processes] "Here are all 50 users in the system:..."
USER:  [sees response]

USER:  "List all users" (as non-admin)
CANA:  [calls /api/mcp with tool=list_users]
FLASK: [Layer 2 check] Admin? NO → DENIED
       Returns error: "Permission denied for tool 'list_users'"
CANA:  [LLM processes] "I don't have permission to list all users..."
USER:  [sees error]
```

---

## 🔐 4-Layer Authorization in Detail

### Layer 1: JWT Token Validation
**Location**: `routers/mcp_router.py` → `validate_jwt_token()`

```python
# Extract Authorization: Bearer <jwt>
# Verify signature: jwt.decode(token, CANA_APP_SIGNING_KEY)
# Extract claims: user_id (sub), role
# Return: (user_id, user_role)
```

**Rejects if**:
- No Authorization header
- Invalid JWT signature
- Token expired (> 60 minutes old)
- Missing user_id or role claim

---

### Layer 2: Tool Access Control
**Location**: `lib/mcp_server.py` → `_has_tool_access()`

```python
ADMIN_ONLY_TOOLS = [
    "list_users",      # Only admins can list all users
    "create_user",     # Only admins can create users
    "update_user",     # Only admins can update other users
    "delete_user",     # Only admins can delete users
    "get_tower",       # Only admins can see towers (in this version)
    "list_towers",     # Only admins can list towers
]

USER_ALLOWED_TOOLS = [
    "get_user",        # All can get a user (but Layer 3 forces self)
    "create_ticket",   # All can create tickets (but Layer 3 forces own)
]

if tool_name in ADMIN_ONLY_TOOLS and user_role != "admin":
    raise ValueError(f"Permission denied for tool '{tool_name}'")
```

**Rejects if**:
- User tries to call admin-only tool

---

### Layer 3: Argument Augmentation
**Location**: `lib/mcp_server.py` → `_augment_tool_args()`

```python
# For non-admins, force certain arguments:
if user_role == "user":
    # Force user_id to authenticated user
    arguments["user_id"] = user_id
    
    # Force created_by to authenticated user (for tickets)
    arguments["created_by"] = user_id
    
    # Filter allowed fields
    if "fields" in arguments:
        arguments["fields"] = [f for f in arguments["fields"] 
                              if f in ALLOWED_FIELDS_FOR_USER]
```

**Enforces**:
- Non-admins always see/edit only their own data
- Can't escalate privileges via arguments

---

### Layer 4: Handler Defensive Checks
**Location**: `lib/mcp_server.py` → Individual handler functions

```python
def get_user_handler(args, user_id, user_role):
    """Get a user by ID (with authorization checks)"""
    target_user_id = args.get("user_id")
    
    # Defensive check: user can only see themselves
    if user_role == "user" and target_user_id != user_id:
        raise ValueError("Access denied: cannot view other users")
    
    # Query database
    user = user_model.get_by_id(target_user_id)
    if not user:
        raise ValueError(f"User {target_user_id} not found")
    
    # Return formatted text
    return f"User {user['id']} — {user['first_name']} {user['last_name']}..."
```

**Ensures**:
- Each handler validates permissions independently
- Catches any bugs in Layers 1-3
- Returns human-readable errors

---

## 📊 Database Schema

```sql
-- Users
CREATE TABLE users (
  id SERIAL PRIMARY KEY,
  email VARCHAR(255) UNIQUE NOT NULL,
  password_hash VARCHAR(255) NOT NULL,
  first_name VARCHAR(100),
  last_name VARCHAR(100),
  phone VARCHAR(20),
  address TEXT,
  status VARCHAR(20) CHECK (status IN ('active', 'inactive', 'suspended')),
  role VARCHAR(20) CHECK (role IN ('admin', 'user')),
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);

-- Towers
CREATE TABLE towers (
  id SERIAL PRIMARY KEY,
  code VARCHAR(50) UNIQUE NOT NULL,
  city VARCHAR(100),
  area VARCHAR(100),
  technology VARCHAR(50),
  status VARCHAR(20),
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);

-- Tickets
CREATE TABLE tickets (
  id SERIAL PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id),
  category VARCHAR(100),
  priority VARCHAR(20),
  status VARCHAR(20),
  title VARCHAR(255),
  notes TEXT,
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);

-- Entity Audit Log
CREATE TABLE entity_audit_log (
  id SERIAL PRIMARY KEY,
  entity VARCHAR(100),                  -- 'user', 'tower', 'ticket'
  entity_id INTEGER,
  action VARCHAR(20),                   -- 'INSERT', 'UPDATE', 'DELETE', 'LOGIN', 'LOGOUT'
  old_values JSONB,                     -- Previous values (for UPDATE/DELETE)
  new_values JSONB,                     -- New values (for INSERT/UPDATE)
  created_by INTEGER REFERENCES users(id),
  created_at TIMESTAMP DEFAULT NOW()
);
```

---

## 🔄 Data Flow: Get User Profile (Example)

```
SCENARIO: Regular user (user_id=5, role="user") asks "Show my profile"

1. USER ACTION
   └─→ Opens Cana chat
   └─→ Types: "Show my profile"

2. CANA PROCESSING
   └─→ Calls /api/mcp with:
       {
         "jsonrpc": "2.0",
         "id": 1,
         "method": "tools/call",
         "params": {
           "name": "get_user",
           "arguments": {}  ← No user_id specified
         }
       }
   └─→ Header: Authorization: Bearer <jwt_for_user_5>

3. FLASK LAYER 1 (JWT Validation)
   └─→ Extracts JWT
   └─→ Verifies signature with CANA_APP_SIGNING_KEY
   └─→ Decodes: {sub: 5, role: "user", exp: ...}
   └─→ Continues with user_id=5, user_role="user"

4. FLASK LAYER 2 (Tool Access)
   └─→ Tool "get_user" is in USER_ALLOWED_TOOLS
   └─→ Allows access
   └─→ Continues

5. FLASK LAYER 3 (Argument Augmentation)
   └─→ User is not admin (role="user")
   └─→ Force arguments["user_id"] = 5 (authenticated user)
   └─→ Force arguments["fields"] = ["id", "email", "first_name", ...] (whitelist)
   └─→ Augmented args: {user_id: 5}
   └─→ Continues

6. FLASK LAYER 4 (Handler Execution)
   └─→ Call get_user_handler({user_id: 5}, user_id=5, role="user")
   └─→ Handler checks: target_user_id (5) == authenticated_user_id (5)? YES
   └─→ Query: SELECT * FROM users WHERE id=5
   └─→ Result: {id: 5, email: "john@example.com", first_name: "John", ...}
   └─→ Format: "User 5 — John Doe\nEmail: john@example.com\nStatus: active"
   └─→ Return text response

7. FLASK RETURNS
   └─→ {
       "jsonrpc": "2.0",
       "id": 1,
       "result": {
         "content": [{
           "type": "text",
           "text": "User 5 — John Doe\nEmail: john@example.com..."
         }]
       }
     }

8. CANA PROCESSES
   └─→ Receives text: "User 5 — John Doe\n..."
   └─→ Sends to LLM
   └─→ LLM generates natural language: "Here's your profile: ..."

9. USER SEES
   └─→ "Here's your profile: John Doe, email john@example.com, active..."
```

---

## 🌐 Public Tunnel Architecture

```
CLOUDFLARE TUNNEL (Terminal 3):
════════════════════════════════════════════════════════════════

Local Network (Your Machine)
┌──────────────────────────────────────┐
│ Flask App (http://localhost:5002)    │
│ - Port 5002 not exposed to internet  │
│ - Only accessible from your machine  │
└──────────────────────────────────────┘
         ↑
         │ (wsgi connection)
         │
    tunnel.py
    (cloudflared)
         │
    ════════════════════════════════ (Encrypted Tunnel)
         │
         ↓
Cloudflare Global Network
┌──────────────────────────────────────┐
│ Temporary Public URL                 │
│ https://xyz-abc-123.trycloudflare.com│
│ (new each restart)                   │
└──────────────────────────────────────┘
         ↑
         │ (HTTP requests)
         │
    Cana.build Cloud
    (Cana AI Platform)

BENEFIT:
- Flask app stays private (no firewall changes needed)
- Tunnel exposes it safely to Cana only
- No static IP, no domain registration required
- Free tier included with Cloudflare
```

---

## 🔄 Deployment Topology

```
DEVELOPMENT (Current Setup)
════════════════════════════════════════════════════════════════

Your Machine (Windows):
┌─ Terminal 1: Flask (http://localhost:5002) ──────────────┐
│ - Services: REST API, MCP endpoint, JWT issuer           │
│ - DB: PostgreSQL local (localhost:5432)                  │
└──────────────────────────────────────────────────────────┘

┌─ Terminal 3: Cloudflare Tunnel ─────────────────────────┐
│ - Exposes http://localhost:5002 → https://xyz-...com    │
└──────────────────────────────────────────────────────────┘

Browser:
├─ http://localhost:5002 (regular UI)
└─ Cana widget (embedded, talks to Tunnel URL)

PRODUCTION (Recommended Future Setup)
════════════════════════════════════════════════════════════════

Cloud Server (e.g., AWS, Azure, DigitalOcean):
┌─ Flask App (with gunicorn/uwsgi) ──────────────────────┐
│ - Reverse proxy (nginx)                                 │
│ - SSL/HTTPS enabled                                     │
│ - Domain: api.yourdomain.com                            │
│ - Service: runs as daemon                               │
└────────────────────────────────────────────────────────┘

┌─ PostgreSQL (managed or self-hosted) ───────────────────┐
│ - Backups enabled                                       │
│ - Replication configured                                │
│ - Not exposed to internet (VPC)                         │
└────────────────────────────────────────────────────────┘

Cana.build Configuration:
├─ MCP URL: https://api.yourdomain.com/api/mcp
├─ Issuer: https://api.yourdomain.com/api/cana-token
└─ Embed Origins: https://yourdomain.com

Browser:
├─ https://yourdomain.com (app UI)
└─ Cana widget (embedded)
```

---

## 📈 Performance & Security Notes

| Aspect | Current | Production |
|--------|---------|-----------|
| **Database** | Local PostgreSQL | Managed (RDS/Azure) with backups |
| **API** | Flask dev server | Gunicorn + Nginx + SSL |
| **Tunnel** | Free temporary URL | Custom domain (no tunnel needed) |
| **Auth** | Session + JWT | Session + JWT + MFA (future) |
| **Rate Limit** | None | Implement: 100 req/min per user |
| **Logging** | Console | Centralized (CloudWatch/ELK) |
| **Monitoring** | None | APM tools (New Relic, Datadog) |

---

**See README.md for full API docs, SETUP_GUIDE.md for setup instructions.**
