import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))  # project root add karo

from contextlib import contextmanager
from typing import Any, Optional

import psycopg2
import psycopg2.extras
from psycopg2 import Error as PostgresError

from config import DB_CONFIG, DB_NAME


@contextmanager
def get_connection():
    conn = None
    try:
        conn = psycopg2.connect(dbname=DB_NAME, **DB_CONFIG)
        yield conn
    except PostgresError as e:
        raise RuntimeError(f"PostgreSQL connection error: {e}") from e
    finally:
        if conn is not None:
            conn.close()


def run_select(query: str, params: Optional[tuple] = None, limit: Optional[int] = None) -> list[dict[str, Any]]:
    """SELECT chalao, sab rows dict list me wapas milegi."""
    with get_connection() as conn:
        cursor = conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor)
        try:
            cursor.execute(query, params or ())
            rows = cursor.fetchmany(limit) if limit else cursor.fetchall()
            return [dict(row) for row in rows]
        finally:
            cursor.close()


def run_write(query: str, params: Optional[tuple] = None) -> dict[str, Any]:
    """INSERT/UPDATE/DELETE ke liye. Kitni rows change hui wo batata hai."""
    with get_connection() as conn:
        cursor = conn.cursor()
        try:
            cursor.execute(query, params or ())
            conn.commit()
            return {"rowcount": cursor.rowcount}
        finally:
            cursor.close()


def run_write_returning_id(query: str, params: Optional[tuple] = None) -> int:
    """INSERT ... RETURNING id ke liye. Naye row ki id wapas deta hai."""
    with get_connection() as conn:
        cursor = conn.cursor()
        try:
            cursor.execute(query, params or ())
            new_id = cursor.fetchone()[0]
            conn.commit()
            return new_id
        finally:
            cursor.close()


def strip_fields(data, hidden: set):
    """Remove the given column names from a row dict, or from every row
    in a list of dicts. Used by models to hide internal/system columns
    (audit/timestamp columns, credentials, etc.) from API responses
    without changing the underlying SQL — the columns are still fetched
    and still usable inside the app, just not serialized out to callers."""
    if data is None:
        return None
    if isinstance(data, list):
        return [{k: v for k, v in row.items() if k not in hidden} for row in data]
    return {k: v for k, v in data.items() if k not in hidden}


def generic_get_by_id(table: str, id_column: str, record_id: int) -> Optional[dict[str, Any]]:
    rows = run_select(f"SELECT * FROM {table} WHERE {id_column} = %s", (record_id,))
    return rows[0] if rows else None


def generic_list(table: str, limit: Optional[int] = None, order_by: str = "id", where_sql: str = "", params: tuple = ()) -> list[dict[str, Any]]:
    limit_sql = f"LIMIT {int(limit)}" if limit else ""
    query = f"SELECT * FROM {table} {where_sql} ORDER BY {order_by} {limit_sql}"
    return run_select(query, params)


def generic_insert(table: str, id_column: str, data: dict[str, Any]) -> dict[str, Any]:
    columns = list(data.keys())
    placeholders = ", ".join(["%s"] * len(columns))
    col_sql = ", ".join(columns)
    query = f"INSERT INTO {table} ({col_sql}) VALUES ({placeholders}) RETURNING {id_column}"
    new_id = run_write_returning_id(query, tuple(data[c] for c in columns))
    return {"rowcount": 1, "id": new_id}


def generic_update(table: str, id_column: str, record_id: int, data: dict[str, Any]) -> dict[str, Any]:
    if not data:
        return {"rowcount": 0}
    set_sql = ", ".join(f"{col} = %s" for col in data.keys())
    query = f"UPDATE {table} SET {set_sql} WHERE {id_column} = %s"
    return run_write(query, tuple(data.values()) + (record_id,))


def generic_delete(table: str, id_column: str, record_id: int) -> dict[str, Any]:
    query = f"DELETE FROM {table} WHERE {id_column} = %s"
    return run_write(query, (record_id,))
