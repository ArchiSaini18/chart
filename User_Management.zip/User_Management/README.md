# NOC · Telecom Console — User Management

A full-stack **User Management System** for a telecom NOC (Network Operations Center) console, built with **Flask + PostgreSQL**. Features role-based dashboards (admin & user), CRUD for users/towers/tickets/audit logs, session-based authentication.

---

## ✨ Features

| Feature | Description |
|---------|-------------|
| **Authentication** | Session-cookie login/signup with password hashing (bcrypt) |
| **Role-Based Access** | `admin` sees full console (Users, Towers, Tickets, Audit Log); `user` sees personal dashboard |
| **User Management** | CRUD operations on user accounts with status (active/inactive/suspended) and roles |
| **Tower Inventory** | Manage cell towers — code, city, area, technology (2G–5G), status |
| **Support Tickets** | Create, update, track tickets with priority/category/status |
| **Entity Audit Log** | Automatic tracking of CREATE/UPDATE/DELETE/LOGIN/LOGOUT actions |
| **Profile Menu** | Avatar dropdown with initials, profile link, and logout |
| **Single-Page App** | No page reloads — JavaScript swaps views in-place with `pushState` routing |
| **Responsive Design** | Works on desktop and mobile with collapsible sidebar |

---

## 🏗️ Architecture

```
┌─────────────────────────────────────────────────────┐
│                    Browser (SPA)                     │
│  index.html — Login ↔ Admin Dashboard ↔ User Dash   │
└─────────────────┬───────────────────────────────────┘
                  │  fetch() + session cookie
                  ▼
┌─────────────────────────────────────────────────────┐
│              Flask App  (app.py :5002)               │
│                                                      │
│  Routers:  auth · users · towers · tickets · audit   │
│  Services: auth · users · towers · tickets · audit   │
│  Models:   user · tower · ticket · entity_audit      │
│  Auth:     session cookie  (authz.py middleware)      │
└─────────────────┬───────────────────────────────────┘
                  │  psycopg2
                  ▼
┌─────────────────────────────────────────────────────┐
│           PostgreSQL  (telecom_db)                   │
│  Tables: users · towers · tickets · entity_audit_log │
└─────────────────────────────────────────────────────┘
```

---

## 🛠️ Tech Stack

| Layer | Technology |
|-------|-----------|
| **Backend** | Python 3.10+, Flask 3.x |
| **Database** | PostgreSQL 14+ |
| **DB Driver** | psycopg2-binary |
| **Frontend** | Vanilla HTML/CSS/JS (single file SPA) |
| **Auth** | Flask session cookies + bcrypt |
| **CORS** | flask-cors |
| **Config** | python-dotenv (.env files) |
| **MCP Server** | Transport-agnostic JSON-RPC (via Cana Apps) |
| **JWT** | HS256 token signing for Cana widget authentication |
| **Public Tunnel** | Cloudflare Tunnel (cloudflared) for Cana integration |

---

## 📋 Prerequisites

- **Python** 3.10 or higher
- **PostgreSQL** 14 or higher (running and accessible)
- **pip** (Python package manager)

---

## 🚀 Quick Start

### 1. Clone & Enter

```bash
cd User_Management/User_Management
```

### 2. Create Virtual Environment (recommended)

```bash
python -m venv venv
# Windows
venv\Scripts\activate
# macOS/Linux
source venv/bin/activate
```

### 3. Install Dependencies

```bash
pip install -r requirements.txt
```

### 4. Configure Environment

Copy the example `.env` file and fill in your values:

```bash
cp .env.example .env
```

Edit `.env`:

```env
PG_HOST=localhost
PG_PORT=5432
PG_USER=postgres
PG_PASSWORD=your_password_here
PG_DB_NAME=telecom_db

FLASK_PORT=5003
FLASK_DEBUG=false
SECRET_KEY=your-secret-key-change-me
```

### 5. Create Database & Tables

```bash
python create_table.py
```

### 6. Seed Sample Data (optional)

```bash
python seed_data.py
```

### 7. Run the App

```bash
python app.py
```

Open **http://localhost:5003** in your browser.

---

## 🤖 Cana Apps Integration (AI Chat Widget)

This User Management system is **fully integrated with Cana Apps** for AI-powered chat-based access to user data, tower inventory, and ticket management. The integration includes:

- **MCP Server**: 8 tools (get_user, list_users, create_user, update_user, delete_user, get_tower, list_towers, create_ticket)
- **JWT Issuer**: `/api/cana-token` endpoint for secure widget authentication
- **JSON-RPC Handler**: `/api/mcp` endpoint for tool execution
- **4-Layer Authorization**: Role-based access control (admin vs user)
- **Public Tunnel**: Cloudflare Tunnel for exposing local Flask app to cana.build

### Setup (3 Terminals Required)

#### **Terminal 1: Flask Backend**

```bash
cd User_Management/User_Management
python -m venv venv

# Windows
venv\Scripts\activate
# macOS/Linux
source venv/bin/activate

pip install -r requirements.txt
cp .env.example .env
```

Edit `.env` and add Cana credentials (get from cana.build dashboard):

```env
PG_HOST=localhost
PG_PORT=5432
PG_USER=postgres
PG_PASSWORD=your_password
PG_DB_NAME=telecom_db

FLASK_PORT=5003
FLASK_DEBUG=false
SECRET_KEY=your-secret-key-change-me

# Cana Apps Configuration (REQUIRED for widget integration)
CANA_APP_ID=your_app_id_from_cana_build
CANA_APP_SIGNING_KEY=your_signing_key_from_cana_build
MCP_AUTH_KEY=optional_static_auth_header
```

Then start Flask:

```bash
python create_table.py      # Create database tables (one-time)
python seed_data.py         # Load sample data (optional)
python app.py               # Start Flask on http://localhost:5003
```

**Expected output**:
```
 * Serving Flask app 'app'
 * Debug mode: off
 * Running on http://127.0.0.1:5003
```

Leave **Terminal 1 running**.

---

#### **Terminal 2: PostgreSQL Database**

Ensure PostgreSQL is running. On Windows:

```bash
# Option A: Using Windows Service (if installed)
# Just verify it's running via Windows Services app

# Option B: Using PostgreSQL's bundled tools
psql -U postgres -d telecom_db

# Test connection
\dt  # Should list tables: users, towers, tickets, entity_audit_log
\q   # Quit
```

**Expected**: Database is accessible. Leave **Terminal 2 available** (or close after verification).

---

#### **Terminal 3: Cloudflare Tunnel**

```bash
# Windows: Download cloudflared (one-time)
# Via Scoop:
scoop install cloudflare

# OR via Chocolatey:
choco install cloudflare

# OR download manually from:
# https://github.com/cloudflare/cloudflared/releases
# Extract to C:\Program Files\cloudflared\ and add to PATH

# Verify installation
cloudflared --version
```

Then start the tunnel:

```bash
cd User_Management/User_Management
python tunnel.py
```

**Expected output**:
```
Checking cloudflared binary... OK
Checking Flask on http://localhost:5003... OK
Starting Cloudflare tunnel...
Tunnel created: https://xyz-abc-123.trycloudflare.com

Setup Instructions for cana.build:
  1. Go to cana.build dashboard → Connectors → New MCP Connector
  2. Name: "User Management"
  3. MCP URL: https://xyz-abc-123.trycloudflare.com/api/mcp
  4. Add header: Authorization: Bearer <static_token> (if MCP_AUTH_KEY set)
  5. Save and test
  
  6. Go to App Settings → Issuer URL
  7. Set to: https://xyz-abc-123.trycloudflare.com/api/cana-token
  8. Save
  
  9. Go to Embed Origins
  10. Add: https://xyz-abc-123.trycloudflare.com
  11. Save

Config saved to: .cana-tunnel.json
Press Ctrl+C to stop tunnel.
```

Copy the tunnel URL (e.g., `https://xyz-abc-123.trycloudflare.com`) and follow the setup steps in cana.build.

Leave **Terminal 3 running**.

---

### Testing the Integration

Once all 3 terminals are running:

1. **Login to your app**: http://localhost:5003 (with seeded credentials)
2. **Go to cana.build dashboard**: Open your Cana App
3. **Open the chat widget**: Should appear in the corner
4. **Test a query**: "List all users" (admin) or "Show my profile" (user)

Expected responses:
- ✅ Admins see all 50 users
- ✅ Users see only their own profile
- ✅ Users denied access to list_users tool
- ✅ Audit log records all MCP calls

---

### Cana MCP Tools

| Tool | Role | Permission | Returns |
|------|------|-----------|---------|
| `get_user` | All | AUTO_RUN | User details (email, name, role, status) |
| `list_users` | Admin | AUTO_RUN | All users (paginated) |
| `create_user` | Admin | CONFIRM | "User created: email@example.com" |
| `update_user` | Admin | CONFIRM | "User updated" |
| `delete_user` | Admin | CONFIRM | "User deleted" |
| `get_tower` | All | AUTO_RUN | Tower details (code, city, tech, status) |
| `list_towers` | Admin | AUTO_RUN | All towers (paginated) |
| `create_ticket` | All | CONFIRM | "Ticket created: #123" |

**AUTO_RUN**: Cana executes immediately.  
**CONFIRM**: User sees a dialog before execution.

---

### Authorization Rules

| Scenario | Result |
|----------|--------|
| Admin calls `list_users` | ✅ See all 50 users |
| User calls `list_users` | ❌ "Permission denied" |
| User calls `get_user` with `user_id=2` (own ID) | ✅ See own profile |
| User calls `get_user` with `user_id=99` (other ID) | ✅ See own profile (forced to self) |
| User calls `create_ticket` | ✅ Creates ticket (created_by = self) |
| User calls `delete_user` | ❌ "Permission denied" |

---

### Troubleshooting

**"Tunnel connection refused"**
- Verify Flask is running (Terminal 1)
- Check http://localhost:5003 works
- Restart tunnel: `python tunnel.py`

**"Invalid token" on Cana widget**
- Verify CANA_APP_SIGNING_KEY in .env matches cana.build
- Check token expires in 60 minutes

**"Tool not found"**
- Verify MCP connector URL in cana.build matches tunnel URL
- Check `/api/mcp` endpoint returns 8 tools via curl:
  ```bash
  curl -H "Authorization: Bearer <token>" https://tunnel-url/api/mcp
  ```

**"User sees other user's data"**
- This is a bug. Check Layer 3 argument augmentation in lib/mcp_server.py
- Should force `user_id` to authenticated user's ID

---

## 🔑 Default Accounts (after seeding)

| Role | Email | Password |
|------|-------|----------|
| Admin | *(check seed_data.py)* | *(check seed_data.py)* |
| User | *(check seed_data.py)* | *(check seed_data.py)* |

---

## 📁 Project Structure

```
User_Management/
├── app.py                     # Flask entrypoint — registers blueprints, serves SPA
├── config.py                  # Centralised config from .env
├── create_table.py            # DDL — creates all PostgreSQL tables
├── seed_data.py               # Inserts sample users, towers, tickets, audit logs
├── requirements.txt           # Python dependencies
├── .env.example               # Environment variable template
│
├── database/
│   └── db.py                  # PostgreSQL connection helper (psycopg2)
│
├── models/
│   ├── user_model.py          # User SQL queries (SELECT/INSERT/UPDATE/DELETE)
│   ├── tower_model.py         # Tower SQL queries
│   ├── ticket_model.py        # Ticket SQL queries
│   └── entity_audit_model.py  # Audit log SQL queries
│
├── services/
│   ├── auth_service.py        # Login/signup/session logic + bcrypt
│   ├── authz.py               # Role-based authorization middleware
│   ├── user_service.py        # User business logic
│   ├── tower_service.py       # Tower business logic
│   ├── ticket_service.py      # Ticket business logic
│   └── entity_audit_service.py# Audit log business logic
│
├── routers/
│   ├── auth_router.py         # /api/auth/* endpoints (login, signup, logout, me)
│   ├── user_router.py         # /api/users/* endpoints
│   ├── tower_router.py        # /api/towers/* endpoints
│   ├── ticket_router.py       # /api/tickets/* endpoints
│   ├── entity_audit_router.py # /api/entity-audit-log/* endpoints
│   ├── mcp_router.py          # /api/mcp endpoint (JSON-RPC handler for Cana)
│   └── cana_token_router.py   # /api/cana-token endpoint (JWT issuer for widget)
│
├── lib/
│   ├── mcp_server.py          # MCP server: McpTool class, handleRpc(), 8 tool handlers
│   ├── jwt_utils.py           # JWT utilities: encode_jwt(), decode_jwt()
│   └── __init__.py            # Package marker
│
├── template/
│   └── index.html             # Single-page app (login + admin dash + user dash)
│
├── tunnel.py                  # Cloudflare tunnel setup script (Python equivalent of npm run tunnel)
├── .cana-tunnel.json          # Auto-generated tunnel config (do not commit)
│
└── tests_manual/              # Manual test scripts
```

---

## 🌐 API Endpoints

### Authentication

| Method | Path | Description |
|--------|------|-------------|
| POST | `/api/auth/signup` | Create a new account and log in (sets session cookie) |
| POST | `/api/auth/login` | Log in (sets session cookie) |
| POST | `/api/auth/logout` | Log out (clears session) |
| GET | `/api/auth/me` | Get current user's profile |

### Users (admin)

| Method | Path | Description |
|--------|------|-------------|
| GET | `/api/users` | List all users (filterable) |
| GET | `/api/users/:id` | Get a single user |
| POST | `/api/users` | Create a user |
| PUT | `/api/users/:id` | Update a user |
| DELETE | `/api/users/:id` | Delete a user |

### Towers (admin)

| Method | Path | Description |
|--------|------|-------------|
| GET | `/api/towers` | List all towers (filterable) |
| GET | `/api/towers/:id` | Get a single tower |
| POST | `/api/towers` | Create a tower |
| PUT | `/api/towers/:id` | Update a tower |
| DELETE | `/api/towers/:id` | Delete a tower |

### Tickets

| Method | Path | Description |
|--------|------|-------------|
| GET | `/api/tickets` | List tickets (scoped by role) |
| GET | `/api/tickets/:id` | Get a single ticket |
| POST | `/api/tickets` | Create a ticket |
| PUT | `/api/tickets/:id` | Update a ticket |
| DELETE | `/api/tickets/:id` | Delete a ticket |

### Entity Audit Log (admin)

| Method | Path | Description |
|--------|------|-------------|
| GET | `/api/entity-audit-log` | List audit log entries |
| GET | `/api/entity-audit-log/:id` | Get a single audit log entry |
| POST | `/api/entity-audit-log` | Create an audit log entry |
| PUT | `/api/entity-audit-log/:id` | Update an audit log entry |
| DELETE | `/api/entity-audit-log/:id` | Delete an audit log entry |

### Cana Apps (MCP Server)

| Method | Path | Description |
|--------|------|-------------|
| POST | `/api/mcp` | JSON-RPC 2.0 handler (requires JWT in Authorization header) |
| GET | `/api/mcp` | Tool descriptor list (for browser/debugging) |
| GET | `/api/cana-token` | JWT issuer for Cana widget (requires Flask session) |
| GET | `/api/cana-token/test` | Test endpoint (returns current Flask session info) |

**Authorization**: All MCP endpoints require `Authorization: Bearer <jwt>` header with valid HS256 JWT signed with `CANA_APP_SIGNING_KEY`.

### Utility

| Method | Path | Description |
|--------|------|-------------|
| GET | `/health` | Health check (API + database status) |
| GET | `/api/tables` | List available tables |

---

## 👤 Role-Based Dashboards

### Admin Dashboard
- **Users**: Full CRUD with status/role management
- **Towers**: Network tower inventory with city/tech/status filters
- **Tickets**: All user tickets with priority and status management
- **Entity Audit Log**: Complete activity history with action-type filters

### User Dashboard
- **Dashboard**: Account overview with status, role, ticket count, and coming-soon cards
- **My Tickets**: Own tickets with create/edit/delete
- **Profile**: Edit name, phone, address (email/role/status are admin-managed)

---

## 📄 License

This project is for internal/educational use. See your organization's licensing policy.
