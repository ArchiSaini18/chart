"""
app.py
=======
Entrypoint for user_management. Creates the Flask app, registers each
entity's router blueprint, and keeps a couple of small cross-cutting
endpoints (health check, table list) that don't belong to any single
entity.

Run:
    python app.py
Default: http://localhost:5003
"""

import sys
import os
from datetime import timedelta
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from flask import Flask, jsonify, send_from_directory

from flask_cors import CORS
from werkzeug.middleware.proxy_fix import ProxyFix

from config import (
    DB_NAME, FLASK_PORT, FLASK_DEBUG, SECRET_KEY,
    SESSION_COOKIE_SECURE, TRUSTED_PROXY_HOPS,
)
from database.db import get_connection
from routers.user_router import user_bp
from routers.tower_router import tower_bp
from routers.ticket_router import ticket_bp
from routers.entity_audit_router import audit_bp
from routers.auth_router import auth_bp
from routers.mcp_router import mcp_bp
from routers.cana_token_router import cana_token_bp

TEMPLATE_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "template")

app = Flask(__name__)
app.json.sort_keys = False  # keep the API's intentional column order instead of sorting keys alphabetically
app.secret_key = SECRET_KEY  # needed to keep the login session cookie

# --------------------------------------------------------------------
# Session cookie settings
# --------------------------------------------------------------------
# Without these, Flask issues a plain, non-permanent session cookie with
# no explicit SameSite/Secure attributes. That's exactly what makes the
# Cana widget flash "Authentication required / Your session expired":
# the widget's GET /api/cana-token fetch (credentials: "include") either
# doesn't get the cookie back (browser drops it) or the cookie is already
# gone by the time the widget checks, so session.get("user_id") in
# cana_token_router.py comes back empty and the endpoint replies 401.
#   - SESSION_COOKIE_SAMESITE="Lax": sent on normal same-site navigation
#     and on same-origin fetches (the widget calls the SAME tunnel/host
#     the page is on), without the stricter "Strict" mode's rough edges.
#   - SESSION_COOKIE_SECURE=True: required by browsers for cookies to
#     survive on an https origin (the Cloudflare tunnel URL is https);
#     "localhost" is treated as a secure context too, so local dev over
#     plain http still works.
#   - PERMANENT_SESSION_LIFETIME + session.permanent=True (set at login/
#     signup, see routers/auth_router.py): gives the cookie a real
#     expiry instead of "until the browser process closes", which is
#     unreliable in embedded/mobile webviews.
app.config["SESSION_COOKIE_SAMESITE"] = "Lax"
app.config["SESSION_COOKIE_SECURE"] = SESSION_COOKIE_SECURE
app.config["PERMANENT_SESSION_LIFETIME"] = timedelta(hours=12)

# Behind the Cloudflare tunnel the browser speaks https to the edge, but the
# edge speaks plain http to Flask. Without this, request.host_url reports the
# http:// inner hop, so the 401 body handed to the widget carried an http://
# login URL for an https page — the browser blocks that as mixed content and
# the chat just shows "Authentication required" with no way back to sign-in.
# ProxyFix makes Flask read X-Forwarded-Proto/Host instead. Trust exactly
# TRUSTED_PROXY_HOPS hop(s); trusting headers with no proxy would let a client
# spoof its own scheme/host.
if TRUSTED_PROXY_HOPS > 0:
    app.wsgi_app = ProxyFix(
        app.wsgi_app, x_for=TRUSTED_PROXY_HOPS, x_proto=TRUSTED_PROXY_HOPS,
        x_host=TRUSTED_PROXY_HOPS, x_prefix=TRUSTED_PROXY_HOPS,
    )

CORS(app, supports_credentials=True)  # allow calls from other origins/services — lock this down in production

app.register_blueprint(user_bp)
app.register_blueprint(tower_bp)
app.register_blueprint(ticket_bp)
app.register_blueprint(audit_bp)
app.register_blueprint(auth_bp)
app.register_blueprint(mcp_bp)
app.register_blueprint(cana_token_bp)


# ------------------------------------------------------------------
# Pages (plain static HTML, no Jinja templating needed — the JS in
# each file calls the JSON API above via fetch()).
# ------------------------------------------------------------------
@app.get("/")
@app.get("/login")
@app.get("/dashboard")
@app.get("/users")
@app.get("/towers")
@app.get("/tickets")
@app.get("/audit-log")
def app_page():
    """Single-page app: login/sign-up and the admin console
    (users/towers/tickets/audit log) live together in index.html and
    switch views with JavaScript.

    Every one of these paths returns the exact same index.html file —
    Flask doesn't render a different page per route. What changes is
    what the JavaScript inside index.html does once it loads: it reads
    window.location.pathname and (a) shows the login form if there's no
    valid session, or (b) shows the dashboard pre-switched to the
    matching section (Users/Towers/Tickets/Audit log) if there is one.
    That's also why each is a *separate* @app.get(...) here: Flask needs
    a route registered for a path or it 404s, so /users, /towers, etc.
    all had to be added explicitly instead of only /, /login, /dashboard.
    """
    resp = send_from_directory(TEMPLATE_DIR, "index.html")
    # Never let the browser reuse an old copy of the page - otherwise after
    # an update people keep seeing the previous version until a hard refresh.
    resp.headers["Cache-Control"] = "no-store, no-cache, must-revalidate, max-age=0"
    return resp

TABLES = {"users", "towers", "tickets", "entity_audit_log"}


@app.get("/health")
def health():
    try:
        with get_connection():
            pass
        return jsonify({"status": "ok", "database": DB_NAME})
    except RuntimeError as e:
        return jsonify({"status": "error", "detail": str(e)}), 503


@app.get("/api/tables")
def list_tables():
    return jsonify(sorted(TABLES))


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=FLASK_PORT, debug=FLASK_DEBUG)
