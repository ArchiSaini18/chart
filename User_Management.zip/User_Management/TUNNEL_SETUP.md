# Tunnel Setup Guide

## The Problem
You're getting "Couldn't connect: fetch failed" when trying to add an MCP connector in cana.build because **the cloudflared tunnel is not running**.

## The Solution (3 Simple Steps)

### Step 1: Start the Tunnel
Open a **NEW terminal window** (PowerShell, CMD, or Git Bash) in this folder and run:

```bash
python tunnel.py
```

You should see:
```
User Management + Cana Tunnel Setup

cloudflared cloudflared version 2026.9.1 (built 2026-09-10T13:52 UTC)
Checking Flask app on port 5002…
✓ Flask is running on port 5002
Opening a public tunnel…
  (this may take up to 30 seconds on first run)
  ...
✓ https://eminem-efficient-jay-london.trycloudflare.com
```

**KEEP THIS TERMINAL OPEN.** The tunnel must stay running while you use Cana.

### Step 2: Copy the Tunnel URL
From the output, copy the URL that looks like:
```
https://eminem-efficient-jay-london.trycloudflare.com
```

(Your actual URL will be different - it's random each time)

### Step 3: Use the URL in cana.build
In the "Add MCP connector" dialog:

- **Name:** `User Management`
- **MCP server URL:** `https://[your-url-from-step-2]/api/mcp`
- **Authentication mode:** Static credential (leave empty)
- **Click "Connect"** ← Should work now!

## Why It Was Failing

The error "Couldn't connect: fetch failed" means:
- ❌ You entered a URL (placeholder `https://xxx.trycloudflare.com`)
- ❌ But cloudflared tunnel was NOT running
- ❌ So Cana couldn't reach your Flask app

## Important: Tunnel URL Changes Every Time

⚠️ **Every time you restart the tunnel script, you get a NEW URL.**

If you stop and restart the tunnel:
1. Run `python tunnel.py` again
2. Copy the NEW URL
3. Update it in cana.build (Connectors tab and Embed tab)

## Setup Once, Then Keep Running

**Best practice:**
1. Copy your `.env.example` to `.env` with your Cana credentials (they're already there!)
2. Start `python tunnel.py` once
3. Keep it running in a dedicated terminal
4. Restart it only when you need a fresh tunnel

## Troubleshooting

**If tunnel still doesn't start:**
- Check Flask is running: `python app.py` in another terminal
- Check cloudflared is installed: `cloudflared --version`
- Check network connection (internet must be available for Cloudflare)

**If MCP connector still says "Couldn't connect":**
- Make sure tunnel terminal shows `✓ https://...trycloudflare.com`
- Make sure you copied the FULL URL correctly
- Wait 10-20 seconds after starting tunnel (it takes time to be reachable)
- Try "Connect" button again


