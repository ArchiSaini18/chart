"""
Cana integration test — no Postgres, no network. Checks the exact things
cana.build verifies / calls, using the same contract as cana-apps-demo:

  token   : HS256, JOSE header kid = App id, claims sub/exp/jti, valid signature
  issuer  : logged-in -> 200 {token}; logged-out -> 401 {loginUrl}; open-redirect blocked
  MCP     : initialize -> notifications/initialized (202) -> tools/list -> tools/call
  config  : /api/cana-config exposes app id but NEVER the signing key

Run:  python3 tests_manual/run_cana_test.py
"""
import sys, os, json, base64
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import fake_db
import database.db as real_db
for name in ["generic_get_by_id", "generic_list", "generic_insert", "generic_update",
             "generic_delete", "run_select", "run_write", "strip_fields"]:
    setattr(real_db, name, getattr(fake_db, name))

import jwt
from werkzeug.security import generate_password_hash
import app as flask_app_module
import config

app = flask_app_module.app
app.testing = True
passed = failed = 0

def check(label, cond, extra=""):
    global passed, failed
    if cond: passed += 1; print(f"  OK   {label}")
    else:    failed += 1; print(f"  FAIL {label} {extra}")

def b64json(seg):
    return json.loads(base64.urlsafe_b64decode(seg + "=" * (-len(seg) % 4)))

fake_db.reset()
fake_db.generic_insert("users", "id", {"first_name": "Alice", "last_name": "Admin", "email": "alice@x.com",
    "password": generate_password_hash("pw123456"), "role": "admin", "status": "active"})
fake_db.generic_insert("users", "id", {"first_name": "Bob", "last_name": "User", "email": "bob@x.com",
    "password": generate_password_hash("pw123456"), "role": "user", "status": "active"})

print("config")
check("CANA_APP_ID loaded from .env", bool(config.CANA_APP_ID))
check("CANA_APP_SIGNING_KEY loaded from .env", config.CANA_APP_SIGNING_KEY.startswith("csk_"))

anon = app.test_client()
r = anon.get("/api/cana-config")
j = r.get_json()
check("/api/cana-config returns app id + sources", r.status_code == 200 and j["appId"] == config.CANA_APP_ID and len(j["sources"]) >= 1)
check("/api/cana-config NEVER leaks the signing key", config.CANA_APP_SIGNING_KEY not in r.get_data(as_text=True))
check("bundle sources try CDN first then cana.build/embed", j["sources"][0].endswith("cdn.cana.build/app.js") and j["sources"][-1].endswith("/embed/app.js"), str(j["sources"]))

print("issuer — logged out")
r = anon.get("/api/cana-token?format=json")
check("logged-out widget call -> 401", r.status_code == 401)
check("401 body carries loginUrl", r.get_json().get("loginUrl", "").endswith("/login"))

print("issuer — logged in")
c = app.test_client()
r = c.post("/api/auth/login", json={"email": "bob@x.com", "password": "pw123456"})
check("bob logs in", r.status_code == 200)
r = c.get("/api/cana-token?format=json")
check("logged-in -> 200 with token", r.status_code == 200 and "token" in r.get_json())
token = r.get_json()["token"]
h_seg, p_seg, _ = token.split(".")
header, payload = b64json(h_seg), b64json(p_seg)
check("JOSE header kid == App id", header.get("kid") == config.CANA_APP_ID, str(header))
check("header alg HS256", header.get("alg") == "HS256")
check("payload has sub (string), exp, jti", isinstance(payload.get("sub"), str) and "exp" in payload and payload.get("jti"))
check("payload does NOT carry kid (that was the old bug)", "kid" not in payload)
ttl = payload["exp"] - payload["iat"]
check("ttl within Cana's 300-3600s window", 300 <= ttl <= 3600, str(ttl))
try:
    jwt.decode(token, config.CANA_APP_SIGNING_KEY, algorithms=["HS256"], options={"verify_sub": False})
    check("signature verifies with the App signing key", True)
except Exception as e:
    check("signature verifies with the App signing key", False, str(e))
check("role travels in metadata", payload["metadata"]["role"] == "user" and payload["email"] == "bob@x.com")
t2 = c.get("/api/cana-token?format=json").get_json()["token"]
check("jti unique per token (replay protection)", jwt.decode(t2, options={"verify_signature": False})["jti"] != payload["jti"])
check("Cache-Control: no-store", "no-store" in c.get("/api/cana-token").headers.get("Cache-Control", ""))

print("issuer — hosted-page mode")
r = c.get("/api/cana-token?return_to=https://evil.example.com/steal")
check("open redirect to a foreign host is refused (400)", r.status_code == 400)
r = c.get("/api/cana-token?return_to=https://cana.build.evil.com/x")
check("look-alike host (cana.build.evil.com) refused", r.status_code == 400)
r = c.get("/api/cana-token?return_to=https://cana.build/a/my-app")
loc = r.headers.get("Location", "")
check("cana.build return_to -> 302 with ?token= fallback (no network here)", r.status_code == 302 and loc.startswith("https://cana.build/a/my-app?") and ("token=" in loc or "exchange=" in loc), loc[:80])
r = anon.get("/api/cana-token?return_to=https://cana.build/a/x")
check("logged-out hosted mode -> 302 /login", r.status_code == 302 and r.headers["Location"].endswith("/login"))

print("MCP handshake (what cana.build's client does)")
def rpc(client, body, **kw):
    return client.post("/api/mcp", json=body, **kw)
r = rpc(anon, {"jsonrpc": "2.0", "id": 1, "method": "initialize", "params": {"protocolVersion": "2024-11-05", "capabilities": {}, "clientInfo": {"name": "cana", "version": "1"}}})
check("initialize -> 200 + serverInfo", r.status_code == 200 and r.get_json()["result"]["serverInfo"]["name"])
check("initialize sets mcp-session-id header", bool(r.headers.get("mcp-session-id")))
r = rpc(anon, {"jsonrpc": "2.0", "method": "notifications/initialized"})
check("notifications/initialized -> 202 empty", r.status_code == 202 and r.get_data() == b"")
r = rpc(anon, {"jsonrpc": "2.0", "id": 2, "method": "tools/list"})
tools = r.get_json()["result"]["tools"]
check("tools/list returns 8 tools with schemas", len(tools) == 8 and all("inputSchema" in t for t in tools))
r = rpc(anon, {"jsonrpc": "2.0", "id": 3, "method": "ping"})
check("ping -> {}", r.get_json()["result"] == {})
r = rpc(anon, {"jsonrpc": "2.0", "id": 4, "method": "nope/nope"})
check("unknown method -> -32601", r.get_json()["error"]["code"] == -32601)
r = rpc(anon, {"jsonrpc": "2.0", "id": 5, "method": "tools/call", "params": {"name": "list_users", "arguments": {}}})
res = r.get_json()["result"]
check("tools/call list_users works with no Authorization header", res["isError"] is False and "user(s)" in res["content"][0]["text"], str(res)[:120])
r = rpc(anon, {"jsonrpc": "2.0", "id": 6, "method": "tools/call", "params": {"name": "get_user", "arguments": {"user_id": 999}}})
res = r.get_json()["result"]
check("tool failure comes back as isError=true (not a protocol error)", res["isError"] is True and "error" not in r.get_json())
r = rpc(anon, {"jsonrpc": "2.0", "id": 7, "method": "tools/call", "params": {"name": "ghost"}})
check("unknown tool -> -32602 naming available tools", r.get_json()["error"]["code"] == -32602 and "list_users" in r.get_json()["error"]["message"])
r = rpc(anon, [{"jsonrpc": "2.0", "id": 8, "method": "ping"}, {"jsonrpc": "2.0", "method": "notifications/initialized"}])
check("batch: notification skipped, ping answered", isinstance(r.get_json(), list) or r.get_json().get("id") == 8)

print("MCP with a visitor JWT (if Cana forwards one)")
r = rpc(anon, {"jsonrpc": "2.0", "id": 9, "method": "tools/call", "params": {"name": "list_users", "arguments": {}}},
        headers={"Authorization": f"Bearer {token}"})
res = r.get_json()["result"]
check("bob's JWT is honoured as role=user -> admin tool refused", res["isError"] is True and "permission" in res["content"][0]["text"], str(res)[:150])
ca = app.test_client(); ca.post("/api/auth/login", json={"email": "alice@x.com", "password": "pw123456"})
atok = ca.get("/api/cana-token?format=json").get_json()["token"]
r = rpc(anon, {"jsonrpc": "2.0", "id": 10, "method": "tools/call", "params": {"name": "list_users", "arguments": {}}},
        headers={"Authorization": f"Bearer {atok}"})
check("alice's JWT is honoured as role=admin -> list_users allowed", r.get_json()["result"]["isError"] is False)

print("page")
r = anon.get("/dashboard")
html = r.get_data(as_text=True)
check("index.html has both AI Agent buttons", html.count('data-agent-btn') >= 2 and 'id="btn-ai-agent"' in html and 'id="udash-btn-ai-agent"' in html)
check("widget loaded after login only (CanaAgent.load() in enterDashboard)", "CanaAgent.load();" in html)
check("page never hard-codes the signing key", config.CANA_APP_SIGNING_KEY not in html)

# The dead-banner bug the user hit: the chat panel opened whenever the bundle
# happened to be loaded, even with no live session (expired, logged out in
# another tab, server restarted). The widget then fetched /api/cana-token, got
# 401, and rendered "Authentication required / Your session expired" with a
# Reload button that cannot help — reloading /login just redraws the login
# form — so the composer sat there dead. toggle() must re-check the session
# and send the person to the login form instead of opening a useless panel.
_toggle = html.split("async toggle()", 1)[-1].split("sessionLost()", 1)[0]
check("opening the chat re-checks the session (toggle is gated)",
      "async toggle()" in html and "/api/auth/me" in _toggle)
check("a dead session routes to the login form, not a dead banner",
      "sessionLost()" in html and 'location.replace("/login")' in html)
check("a dead session destroys the widget (no chat from the old identity)",
      "window.Cana.destroy" in html.split("sessionLost()", 1)[-1][:400])

print("behind the tunnel (the 'Authentication required' regression)")
# The widget is served over https by the Cloudflare tunnel, but the tunnel
# speaks plain http to Flask. Without ProxyFix in app.py, request.host_url
# reported that inner http:// hop, so the 401 handed to the widget pointed at
# an http:// login URL on an https page — mixed content, blocked by the
# browser, and the chat could only show "Authentication required".
# Each of these FAILS without the ProxyFix wrapper.
PROXY = {"X-Forwarded-Proto": "https", "X-Forwarded-Host": "tunnel.example.com"}

r = anon.get("/api/cana-token?format=json", headers=PROXY)
login_url = r.get_json().get("loginUrl", "")
check("logged-out behind https proxy -> 401", r.status_code == 401)
check("loginUrl uses https, not the proxy's inner http hop",
      login_url.startswith("https://"), login_url)
check("loginUrl uses the PUBLIC tunnel host, not localhost",
      "tunnel.example.com" in login_url, login_url)

r = c.get("/api/cana-token?return_to=https://cana.build/a/my-app", headers=PROXY)
check("hosted-mode redirect still works behind the proxy", r.status_code == 302)

print("both roles get a working widget token (admin + user)")
# The bug had to be fixed for BOTH sign-in types, so assert each one
# end-to-end: fresh login -> 200 -> token that verifies -> correct role.
for label, email, want_role in (("admin (alice)", "alice@x.com", "admin"),
                                ("user  (bob)",   "bob@x.com",   "user")):
    cl = app.test_client()
    lr = cl.post("/api/auth/login", json={"email": email, "password": "pw123456"})
    check(f"{label}: logs in", lr.status_code == 200)
    tr = cl.get("/api/cana-token?format=json", headers=PROXY)
    check(f"{label}: widget token -> 200 (no auth banner)", tr.status_code == 200,
          str(tr.get_json())[:120])
    tok = tr.get_json().get("token", "")
    try:
        claims = jwt.decode(tok, config.CANA_APP_SIGNING_KEY, algorithms=["HS256"],
                            options={"verify_sub": False})
        ok = claims["metadata"]["role"] == want_role and claims["email"] == email
        check(f"{label}: token verifies and carries role={want_role}", ok, str(claims)[:120])
    except Exception as e:
        check(f"{label}: token verifies and carries role={want_role}", False, str(e))

    # A session that goes stale must fail CLOSED with a usable way back,
    # never mint a token for a user who is no longer signed in.
    with cl.session_transaction() as s:
        s.clear()
    sr = cl.get("/api/cana-token?format=json", headers=PROXY)
    check(f"{label}: cleared session -> 401 + https loginUrl",
          sr.status_code == 401 and sr.get_json().get("loginUrl", "").startswith("https://"),
          str(sr.get_json())[:120])

print(f"\n{passed} passed, {failed} failed")
sys.exit(1 if failed else 0)
