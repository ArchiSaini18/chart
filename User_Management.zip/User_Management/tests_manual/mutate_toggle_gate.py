"""
Mutation check for the session gate on the chat toggle.

A test that passes whether or not the fix is present proves nothing. So:
temporarily put the OLD ungated toggle() back into template/index.html, run
the suite, and confirm the three new assertions FAIL. Then restore the file.

The original is backed up first and restored in a finally block, so the page
is never left mutated even if the suite blows up.

Run:  python tests_manual/mutate_toggle_gate.py
"""
import os, sys, shutil, subprocess

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
PAGE = os.path.join(ROOT, "template", "index.html")
BAK = PAGE + ".mutbak"

GATED_START = "  // Opening the chat is gated on the session still being alive."
GATED_END = "  // Called on logout: a chat opened as the previous user must not survive."

OLD_TOGGLE = """  toggle() {
    if (this.state === "failed") { this.state = "idle"; this.load(); return; }
    if (window.Cana && typeof window.Cana.toggle === "function") window.Cana.toggle();
  },

"""

src = open(PAGE, encoding="utf-8").read()
if GATED_START not in src or GATED_END not in src:
    print("!! could not locate the gated toggle block — aborting, file untouched")
    sys.exit(2)

head, rest = src.split(GATED_START, 1)
_removed, tail = rest.split(GATED_END, 1)
mutated = head + OLD_TOGGLE + GATED_END + tail

shutil.copy2(PAGE, BAK)
try:
    open(PAGE, "w", encoding="utf-8").write(mutated)
    print("=" * 68)
    print("  MUTATION: session gate REMOVED from toggle() — new checks must FAIL")
    print("=" * 68)
    p = subprocess.run([sys.executable, os.path.join("tests_manual", "run_cana_test.py")],
                       cwd=ROOT, capture_output=True, text=True)
    out = p.stdout + p.stderr
    for line in out.splitlines():
        if "FAIL" in line or "passed," in line:
            print("  " + line.strip())
    print(f"\n  suite exit code: {p.returncode}")
    gate_fails = sum(1 for l in out.splitlines() if l.strip().startswith("FAIL") and (
        "re-checks the session" in l or "routes to the login form" in l or "destroys the widget" in l))
    print(f"  gate assertions that failed: {gate_fails} (expect 3)")
    print()
    if gate_fails == 3 and p.returncode != 0:
        print("  RESULT: PASS — the three new checks genuinely detect the missing gate.")
        verdict = 0
    else:
        print("  RESULT: FAIL — the checks passed without the fix, so they prove nothing.")
        verdict = 1
finally:
    shutil.copy2(BAK, PAGE)
    os.remove(BAK)
    restored = open(PAGE, encoding="utf-8").read()
    print("  index.html restored:", "OK" if GATED_START in restored else "!! RESTORE FAILED")

sys.exit(verdict)
