"""
Manual smoke test — no real Postgres needed. Monkeypatches
database.db with an in-memory fake, then drives the Flask app through
a normal HTTP-shaped flow (via the Flask test client) to check that
role-based access control actually behaves as designed:

  - a plain "user" can see/edit only their own profile and tickets
  - a plain "user" is blocked from admin-only endpoints (list all
    users, towers, audit log, someone else's ticket)
  - an "admin" can do all of the above for everyone

Run with:  python3 tests_manual/run_smoke_test.py
"""

import sys
import os

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import fake_db  # noqa: E402
import database.db as real_db  # noqa: E402

# Monkeypatch the DB layer before anything imports models/services.
for name in ["generic_get_by_id", "generic_list", "generic_insert",
             "generic_update", "generic_delete", "run_select", "run_write",
             "strip_fields"]:
    setattr(real_db, name, getattr(fake_db, name))

from werkzeug.security import generate_password_hash  # noqa: E402
import app as flask_app_module  # noqa: E402

app = flask_app_module.app
app.testing = True

passed = 0
failed = 0


def check(label, cond):
    global passed, failed
    if cond:
        passed += 1
        print(f"  OK   {label}")
    else:
        failed += 1
        print(f"  FAIL {label}")


def seed():
    fake_db.reset()
    fake_db.generic_insert("users", "id", {
        "first_name": "Alice", "last_name": "Admin", "email": "alice@corp.test",
        "password": generate_password_hash("adminpass"), "status": "active", "role": "admin",
    })
    fake_db.generic_insert("users", "id", {
        "first_name": "Bob", "last_name": "User", "email": "bob@corp.test",
        "password": generate_password_hash("bobpass"), "status": "active", "role": "user",
    })
    fake_db.generic_insert("users", "id", {
        "first_name": "Cara", "last_name": "Customer", "email": "cara@corp.test",
        "password": generate_password_hash("carapass"), "status": "active", "role": "user",
    })
    fake_db.generic_insert("towers", "id", {"tower_code": "DEL-5G-001", "tower_city": "Delhi", "tower_status": "Active"})
    fake_db.generic_insert("tickets", "id", {"user_id": 2, "ticket_subject": "Bob's issue", "ticket_status": "Open"})
    fake_db.generic_insert("tickets", "id", {"user_id": 3, "ticket_subject": "Cara's issue", "ticket_status": "Open"})


def login(client, email, password):
    r = client.post("/api/auth/login", json={"email": email, "password": password})
    return r


def main():
    seed()
    bob, alice, cara = app.test_client(), app.test_client(), app.test_client()
    if True:
        r = login(bob, "bob@corp.test", "bobpass")
        check("bob logs in", r.status_code == 200 and r.get_json()["data"]["role"] == "user")

        r = login(alice, "alice@corp.test", "adminpass")
        check("alice (admin) logs in", r.status_code == 200 and r.get_json()["data"]["role"] == "admin")

        r = login(cara, "cara@corp.test", "carapass")
        check("cara logs in", r.status_code == 200 and r.get_json()["data"]["role"] == "user")

        # --- Bob (plain user) ---
        r = bob.get("/api/users")
        check("bob CANNOT list all users (403)", r.status_code == 403)

        r = bob.get("/api/users/2")
        check("bob CAN read his own profile", r.status_code == 200)

        r = bob.get("/api/users/3")
        check("bob CANNOT read Cara's profile (403)", r.status_code == 403)

        r = bob.put("/api/users/2", json={"first_name": "Bobby", "role": "admin", "status": "suspended"})
        ok = r.status_code == 200
        data = r.get_json()["data"] if ok else {}
        check("bob CAN update his own name", ok and data.get("first_name") == "Bobby")
        check("bob's role/status injection is ignored by the server", data.get("role") == "user" and data.get("status") == "active")

        r = bob.get("/api/tickets")
        ok = r.status_code == 200
        rows = r.get_json() if ok else []
        check("bob's ticket list contains ONLY his own ticket", ok and len(rows) == 1 and rows[0]["ticket_subject"] == "Bob's issue")

        r = bob.get("/api/tickets?user_id=3")  # trying to peek at Cara's tickets via query param
        rows = r.get_json() if r.status_code == 200 else []
        check("bob cannot use ?user_id= to see Cara's tickets", len(rows) == 1 and rows[0]["ticket_subject"] == "Bob's issue")

        r = bob.post("/api/tickets", json={"ticket_subject": "New router issue", "user_id": 3})
        ok = r.status_code == 201
        check("bob's ticket is created under HIS OWN id, not the spoofed one", ok)
        new_ticket_id = r.get_json()["data"] if ok else None

        r = bob.get("/api/tickets/3")  # Cara's ticket id (created in seed = id 2, but let's target explicitly)
        # figure out Cara's actual ticket id
        cara_ticket_id = [tid for tid, row in fake_db._TABLES["tickets"].items() if row["user_id"] == 3][0]
        r = bob.get(f"/api/tickets/{cara_ticket_id}")
        check("bob CANNOT view Cara's ticket (404, not leaked)", r.status_code == 404)

        r = bob.delete(f"/api/tickets/{cara_ticket_id}")
        check("bob CANNOT delete Cara's ticket", r.status_code == 404)
        check("Cara's ticket still exists after bob's delete attempt", cara_ticket_id in fake_db._TABLES["tickets"])

        r = bob.get("/api/towers")
        check("bob CANNOT list towers (admin-only system data)", r.status_code == 403)

        r = bob.get("/api/entity-audit-log")
        check("bob CANNOT read the audit log", r.status_code == 403)

        r = bob.delete("/api/users/3")
        check("bob CANNOT delete another user", r.status_code == 403)

        # --- Alice (admin) ---
        r = alice.get("/api/users")
        check("alice (admin) CAN list all users", r.status_code == 200 and len(r.get_json()) == 3)

        r = alice.get("/api/tickets")
        check("alice (admin) sees ALL tickets", r.status_code == 200 and len(r.get_json()) >= 3)

        r = alice.get("/api/towers")
        check("alice (admin) CAN list towers", r.status_code == 200)

        r = alice.get("/api/entity-audit-log")
        check("alice (admin) CAN read the audit log", r.status_code == 200)

        r = alice.put("/api/users/2", json={"status": "suspended", "role": "admin"})
        ok = r.status_code == 200
        check("alice (admin) CAN change bob's role/status", ok and r.get_json()["data"].get("status") == "suspended")

        # --- Logged out ---
        anon = app.test_client()
        r = anon.get("/api/tickets")
        check("anonymous request is rejected (401)", r.status_code == 401)
        r = anon.get("/api/auth/me")
        check("anonymous /api/auth/me is rejected (401)", r.status_code == 401)

    print(f"\n{passed} passed, {failed} failed")
    sys.exit(1 if failed else 0)


if __name__ == "__main__":
    main()
