"""Tiny in-memory stand-in for database/db.py, used only for the manual
smoke test in run_smoke_test.py. Mimics just enough of the generic_*
helpers' behavior (dict rows, autoincrement id, simple WHERE filtering)
to exercise the routers/services/models unchanged."""

import re

_TABLES = {"users": {}, "tickets": {}, "towers": {}, "entity_audit_log": {}}
_NEXT_ID = {"users": 1, "tickets": 1, "towers": 1, "entity_audit_log": 1}


def reset():
    for t in _TABLES:
        _TABLES[t].clear()
        _NEXT_ID[t] = 1


def generic_get_by_id(table, id_column, record_id):
    row = _TABLES[table].get(int(record_id))
    return dict(row) if row else None


def generic_list(table, limit=None, where_sql="", params=()):
    rows = list(_TABLES[table].values())
    # extremely small WHERE parser: only handles "col = %s AND col2 = %s"
    if where_sql:
        conds = re.findall(r"(\w+)\s*=\s*%s", where_sql)
        for col, val in zip(conds, params):
            rows = [r for r in rows if r.get(col) == val]
    if limit:
        rows = rows[:limit]
    return [dict(r) for r in rows]


def generic_insert(table, id_column, payload):
    new_id = _NEXT_ID[table]
    _NEXT_ID[table] += 1
    row = dict(payload)
    row[id_column] = new_id
    row.setdefault("created_at", "now")
    _TABLES[table][new_id] = row
    return {"id": new_id}


def generic_update(table, id_column, record_id, payload):
    row = _TABLES[table].get(int(record_id))
    if not row:
        return {"rowcount": 0}
    row.update(payload)
    return {"rowcount": 1}


def generic_delete(table, id_column, record_id):
    existed = int(record_id) in _TABLES[table]
    _TABLES[table].pop(int(record_id), None)
    return {"rowcount": 1 if existed else 0}


def run_select(query, params=None):
    # only used by user_model.get_by_email(email)
    m = re.search(r"FROM (\w+) WHERE email = %s", query)
    if m:
        table = m.group(1)
        email = params[0]
        return [dict(r) for r in _TABLES[table].values() if r.get("email") == email]
    return []


def run_write(query, params=None):
    return {"rowcount": 0}


def strip_fields(rows, hidden):
    def _strip(row):
        return {k: v for k, v in row.items() if k not in hidden}
    if rows is None:
        return None
    if isinstance(rows, list):
        return [_strip(r) for r in rows]
    return _strip(rows)
