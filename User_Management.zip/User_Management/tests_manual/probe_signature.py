"""
Disambiguate the `bad_signature` from cana.build.

exchange/issue rejecting us can mean either of two VERY different things:

  (1) our HMAC is built the wrong way  -> a bug in cana_token_router.py we fix
  (2) the signing key genuinely doesn't match the App -> only the dashboard fixes it

Same symptom, opposite owners. So try every plausible signing variant against
the real endpoint. If ANY variant stops saying bad_signature, it's (1).
If every variant says bad_signature, it's (2).

Run:  python tests_manual/probe_signature.py
Read-only: sends probe tokens, changes nothing.
"""
import sys, os, json, time, hmac, hashlib, base64, urllib.request, urllib.error
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import config

KEY = config.CANA_APP_SIGNING_KEY
APP = config.CANA_APP_ID
WEB = config.CANA_WEB_BASE
URL = f"{WEB}/api/v1/apps/{APP}/exchange/issue"


def post(url, raw_body: bytes, sig_header: str):
    req = urllib.request.Request(
        url, data=raw_body, method="POST",
        headers={"Content-Type": "application/json",
                 "User-Agent": "Mozilla/5.0 (compatible; cana-probe/1.0)",
                 "X-Cana-Signature": sig_header},
    )
    try:
        with urllib.request.urlopen(req, timeout=12) as r:
            return r.status, r.read().decode("utf-8", "replace")
    except urllib.error.HTTPError as e:
        return e.code, e.read().decode("utf-8", "replace")
    except Exception as e:
        return None, f"{type(e).__name__}: {e}"


body = json.dumps({"token": "probe"}, separators=(",", ":")).encode()
t_ms = int(time.time() * 1000)
t_s = int(time.time())
kb = KEY.encode()
bare = KEY.split("_", 2)[-1].encode() if "_" in KEY else kb   # key minus csk_live_

def hexs(k, m): return hmac.new(k, m, hashlib.sha256).hexdigest()
def b64s(k, m): return base64.b64encode(hmac.new(k, m, hashlib.sha256).digest()).decode()

variants = [
    ("current: v1=hex, t=ms, signed over f'{t}.{body}'", body, f"t={t_ms},v1={hexs(kb, f'{t_ms}.'.encode() + body)}"),
    ("t in SECONDS instead of ms",                        body, f"t={t_s},v1={hexs(kb, f'{t_s}.'.encode() + body)}"),
    ("signed over body ONLY (no t prefix)",               body, f"t={t_ms},v1={hexs(kb, body)}"),
    ("key with csk_live_ prefix STRIPPED",                body, f"t={t_ms},v1={hexs(bare, f'{t_ms}.'.encode() + body)}"),
    ("signature base64 instead of hex",                   body, f"t={t_ms},v1={b64s(kb, f'{t_ms}.'.encode() + body)}"),
    ("body with default json spacing",                    json.dumps({"token": "probe"}).encode(),
                                                          f"t={t_ms},v1={hexs(kb, f'{t_ms}.'.encode() + json.dumps({'token': 'probe'}).encode())}"),
    ("separator ';' instead of ','",                      body, f"t={t_ms};v1={hexs(kb, f'{t_ms}.'.encode() + body)}"),
]

print("=" * 72)
print("  SIGNATURE VARIANT PROBE")
print(f"  app  {APP}")
print(f"  key  {KEY[:9]}…{KEY[-4:]}  ({len(KEY)} chars)")
print(f"  url  {URL}")
print("=" * 72)

results = []
for label, raw, header in variants:
    st, txt = post(URL, raw, header)
    bad = (st == 401 and "bad_signature" in txt)
    results.append(bad)
    mark = "bad_signature" if bad else ">>> DIFFERENT <<<"
    print(f"\n  {label}")
    print(f"    -> {st}: {txt.strip()[:160]}")
    print(f"    {mark}")

# Control: a made-up app id. If a WRONG app also says bad_signature, the error
# is generic and proves less; if it says something else, bad_signature really
# is about the key for THIS app.
st, txt = post(f"{WEB}/api/v1/apps/cmZZZZZfake00000000000000/exchange/issue", body,
               f"t={t_ms},v1={hexs(kb, f'{t_ms}.'.encode() + body)}")
print(f"\n  CONTROL — same key against a NON-EXISTENT app id")
print(f"    -> {st}: {txt.strip()[:160]}")

print("\n" + "=" * 72)
if all(results):
    print("  VERDICT: every signing variant was refused with bad_signature.")
    print("  => Our HMAC construction is not the problem.")
    print()
    print("  BUT read the CONTROL line above before blaming the key: a")
    print("  NON-EXISTENT app id is refused with the SAME bad_signature, so this")
    print("  endpoint returns one generic error for 'unknown app' and 'wrong")
    print("  signature' alike. It therefore does NOT prove the key is wrong.")
    print("  Note also that exchange/issue is used only by HOSTED-PAGE mode;")
    print("  the embedded widget uses format=json and never calls it, so this")
    print("  401 alone cannot explain the widget's auth banner.")
else:
    print("  VERDICT: at least one variant was accepted -> OUR CODE builds the")
    print("  signature wrongly. Fix cana_token_router._issue_exchange_code to match.")
print("=" * 72)
