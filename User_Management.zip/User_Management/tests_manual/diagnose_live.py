"""
Live diagnosis of the "Authentication required" banner in the Cana widget.

Unlike run_cana_test.py (which proves our LOCAL token contract), this talks to
cana.build and to the origin the app is actually served from, to find which of
the three live-side causes is real:

  A. signing key mismatch  -> cana.build refuses our HMAC/JWT (bad_signature)
  B. origin_not_allowed    -> the App's embed origins don't include our origin
  C. issuer URL stale      -> Cana sends visitors to a dead tunnel to sign in

Run:  python tests_manual/diagnose_live.py
Prints findings only; never changes anything.
"""
import sys, os, json, time, hmac, hashlib, socket, urllib.request, urllib.error
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import config

UA = "Mozilla/5.0 (compatible; cana-diagnose/1.0)"


def http(url, method="GET", body=None, headers=None, timeout=12):
    hdrs = {"User-Agent": UA, "Accept": "application/json"}
    if headers:
        hdrs.update(headers)
    data = None
    if body is not None:
        data = json.dumps(body, separators=(",", ":")).encode()
        hdrs.setdefault("Content-Type", "application/json")
    req = urllib.request.Request(url, data=data, headers=hdrs, method=method)
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return r.status, r.read().decode("utf-8", "replace")
    except urllib.error.HTTPError as e:
        return e.code, e.read().decode("utf-8", "replace")
    except Exception as e:
        return None, f"{type(e).__name__}: {e}"


print("=" * 70)
print("  CANA LIVE DIAGNOSIS")
print("=" * 70)

app_id = config.CANA_APP_ID
key = config.CANA_APP_SIGNING_KEY
web = config.CANA_WEB_BASE

print(f"\n[.env as loaded]")
print(f"  CANA_APP_ID          = {app_id or '(empty)'}")
print(f"  CANA_APP_SIGNING_KEY = {'set, ' + str(len(key)) + ' chars, prefix ' + key[:9] + '…' + key[-4:] if key else '(empty)'}")
print(f"  CANA_WEB_BASE        = {web}")
print(f"  CANA_TOKEN_TTL_SEC   = {config.CANA_TOKEN_TTL_SEC}")

# ---------------------------------------------------------------- A. the key
print(f"\n[A] Does cana.build accept THIS signing key for THIS app?")
body = json.dumps({"token": "probe"}, separators=(",", ":"))
t = int(time.time() * 1000)
sig = hmac.new(key.encode(), f"{t}.{body}".encode(), hashlib.sha256).hexdigest()
st, txt = http(f"{web}/api/v1/apps/{app_id}/exchange/issue", "POST", {"token": "probe"},
               {"X-Cana-Signature": f"t={t},v1={sig}"})
print(f"  POST exchange/issue -> {st}: {txt.strip()[:200]}")
if st == 401 and "bad_signature" in txt:
    print("  >> VERDICT: the signing key does NOT match this App. Cana will reject")
    print("     the widget JWT the same way -> 'Authentication required'.")
elif st in (400, 200) or (st == 401 and "bad_signature" not in txt):
    print("  >> VERDICT: signature ACCEPTED (the error, if any, is about the probe")
    print("     token itself, not the key). Key is correct.")
else:
    print("  >> inconclusive (network/endpoint issue)")

# ------------------------------------------------------- B/C. serving origin
print(f"\n[B] What origin is this app actually served from right now?")
port = config.FLASK_PORT
up = False
try:
    with socket.create_connection(("127.0.0.1", port), timeout=1):
        up = True
except OSError:
    pass
print(f"  Flask on 127.0.0.1:{port} -> {'LISTENING' if up else 'not running'}")

tunnel_file = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), ".cana-tunnel.json")
if os.path.exists(tunnel_file):
    tj = json.loads(open(tunnel_file, encoding="utf-8").read())
    origin = tj.get("publicOrigin", "")
    print(f"  .cana-tunnel.json origin = {origin}  (startedAt {tj.get('startedAt')})")
    host = origin.split('://', 1)[-1]
    try:
        socket.getaddrinfo(host, 443)
        print(f"  DNS for {host}: RESOLVES")
        st, _ = http(origin + "/health", timeout=8)
        print(f"  GET {origin}/health -> {st}")
        if st is None:
            print("  >> that tunnel hostname is DEAD (recorded origin no longer serves)")
    except socket.gaierror:
        print(f"  DNS for {host}: DOES NOT RESOLVE  -> tunnel is DEAD")
        print("  >> VERDICT: the App's allowed embed origin points at a tunnel that")
        print("     no longer exists. A widget served from any other origin is")
        print("     refused with origin_not_allowed -> 'Authentication required'.")
else:
    print("  no .cana-tunnel.json")

print("\n" + "=" * 70)
