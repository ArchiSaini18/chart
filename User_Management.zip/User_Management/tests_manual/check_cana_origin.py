"""
Does cana.build's App configuration still match the LIVE tunnel?

Quick tunnels get a NEW random hostname on every restart. The Bellx AI App
pins two URLs to that hostname:

  Allowed embed origin  -> the browser origin the widget may be embedded on
  Issuer URL            -> where cana.build fetches the visitor JWT

If either still points at a previous tunnel, the widget refuses to
authenticate and the chat shows "Authentication required" — exactly the
symptom being debugged. This check compares both against the origin recorded
in .cana-tunnel.json by the currently running tunnel.py.

Reads the App config from the dashboard export written by the agent
(.cana-app-config.json) so the check is runnable offline and in CI.

Run:  python tests_manual/check_cana_origin.py
"""
import sys
import os
import json

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import config

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
TUNNEL_CFG = os.path.join(ROOT, ".cana-tunnel.json")
APP_CFG = os.path.join(ROOT, ".cana-app-config.json")

failures = []


def check(label, cond, extra=""):
    if cond:
        print(f"  OK   {label}")
    else:
        print(f"  FAIL {label} {extra}")
        failures.append(label)


for path, what in ((TUNNEL_CFG, "run `python tunnel.py`"),
                   (APP_CFG, "re-export the App config from cana.build")):
    if not os.path.exists(path):
        print(f"  FAIL {os.path.basename(path)} missing — {what}")
        sys.exit(1)

tun = json.load(open(TUNNEL_CFG))
app = json.load(open(APP_CFG))

origin = tun.get("publicOrigin", "").rstrip("/")
expected_issuer = f"{origin}/api/cana-token"

print("live tunnel")
print(f"  origin: {origin}")

print("cana.build App config")
print(f"  app id:        {app.get('appId')}")
print(f"  embed origins: {app.get('embedDomains')}")
print(f"  issuer:        {app.get('issuerUrl')}")

check("App id in the dashboard matches CANA_APP_ID in .env",
      app.get("appId") == config.CANA_APP_ID,
      f"dashboard={app.get('appId')!r} env={config.CANA_APP_ID!r}")

embed = [d.rstrip("/") for d in app.get("embedDomains") or []]
check("live tunnel origin is an allowed embed origin",
      origin in embed,
      f"{origin} not in {embed}")

check("no STALE tunnel origin left in the allow-list",
      all(d == origin or "trycloudflare.com" not in d for d in embed),
      f"stale trycloudflare entries: {[d for d in embed if 'trycloudflare.com' in d and d != origin]}")

check("issuer URL points at the live tunnel's /api/cana-token",
      (app.get("issuerUrl") or "").rstrip("/") == expected_issuer,
      f"dashboard={app.get('issuerUrl')!r} expected={expected_issuer!r}")

check("access mode is AUTHENTICATED (widget uses the JWT issuer)",
      app.get("accessMode") == "AUTHENTICATED", str(app.get("accessMode")))

check("App is LIVE, not DRAFT", app.get("status") == "LIVE", str(app.get("status")))

check("visitor-token lifetime is inside Cana's 300-3600s window",
      300 <= int(app.get("tokenMaxAgeSec") or 0) <= 3600,
      str(app.get("tokenMaxAgeSec")))

check("token lifetime agrees with CANA_TOKEN_TTL_SEC in .env",
      int(app.get("tokenMaxAgeSec") or 0) == int(config.CANA_TOKEN_TTL_SEC),
      f"dashboard={app.get('tokenMaxAgeSec')} env={config.CANA_TOKEN_TTL_SEC}")

print(f"\n{'FAILED' if failures else 'PASSED'} — {len(failures)} failure(s)")
sys.exit(1 if failures else 0)
