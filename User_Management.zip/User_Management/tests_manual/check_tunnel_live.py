"""
Is the Cloudflare tunnel in .cana-tunnel.json actually serving THIS app right now?

The widget's whole auth handshake happens through that public origin, so a stale
or dead quick-tunnel URL (cloudflared not running -> HTTP 530) makes the chat
show "Authentication required" no matter how correct the keys are.

Passes only when the recorded publicOrigin answers /api/cana-config with 200 and
the app id it reports matches CANA_APP_ID from .env.

Run:  python tests_manual/check_tunnel_live.py
"""
import sys
import os
import json
import urllib.request
import urllib.error

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import config

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CFG = os.path.join(ROOT, ".cana-tunnel.json")

failures = []


def check(label, cond, extra=""):
    if cond:
        print(f"  OK   {label}")
    else:
        print(f"  FAIL {label} {extra}")
        failures.append(label)


print("tunnel config")
if not os.path.exists(CFG):
    print(f"  FAIL .cana-tunnel.json missing — run `python tunnel.py` first")
    sys.exit(1)

tun = json.load(open(CFG))
origin = tun.get("publicOrigin", "").rstrip("/")
print(f"  origin: {origin}")
check("publicOrigin is an https URL", origin.startswith("https://"), origin)

url = f"{origin}/api/cana-config"
status, body = None, ""
try:
    req = urllib.request.Request(url, headers={"User-Agent": "cana-tunnel-check/1.0"})
    with urllib.request.urlopen(req, timeout=30) as r:
        status, body = r.status, r.read().decode("utf-8", "replace")
except urllib.error.HTTPError as e:
    status, body = e.code, e.read().decode("utf-8", "replace")
except Exception as e:
    status, body = None, f"{type(e).__name__}: {e}"

print("tunnel reachability")
check("GET /api/cana-config through the tunnel -> 200", status == 200,
      f"got {status}: {body[:120]}  (530 = cloudflared is not running)")

if status == 200:
    try:
        j = json.loads(body)
    except ValueError:
        j = {}
    check("tunnel serves THIS app (appId matches .env)",
          j.get("appId") == config.CANA_APP_ID,
          f"tunnel={j.get('appId')!r} env={config.CANA_APP_ID!r}")
    check("widget is enabled (app id + signing key both loaded)",
          j.get("enabled") is True, str(j)[:120])
    check("config never leaks the signing key",
          config.CANA_APP_SIGNING_KEY not in body)

print(f"\n{'FAILED' if failures else 'PASSED'} — {len(failures)} failure(s)")
sys.exit(1 if failures else 0)
