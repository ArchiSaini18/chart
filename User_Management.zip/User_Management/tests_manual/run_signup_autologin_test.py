"""
Manual test for: (1) sign-up logs the person in immediately, and
(2) the chatbot is fully gone. No real Postgres needed - uses the same
in-memory fake DB as run_smoke_test.py.

Run with:  python3 tests_manual/run_signup_autologin_test.py
"""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import fake_db  # noqa: E402
import database.db as real_db  # noqa: E402
for name in ["generic_get_by_id", "generic_list", "generic_insert", "generic_update",
             "generic_delete", "run_select", "run_write", "strip_fields"]:
    setattr(real_db, name, getattr(fake_db, name))

from werkzeug.security import generate_password_hash  # noqa: E402
import app as flask_app_module  # noqa: E402

app = flask_app_module.app
app.testing = True
passed = failed = 0


def check(label, cond):
    global passed, failed
    if cond: passed += 1; print(f"  OK   {label}")
    else:    failed += 1; print(f"  FAIL {label}")


fake_db.reset()
fake_db.generic_insert("users", "id", {
    "first_name": "Alice", "last_name": "Admin", "email": "alice@corp.test",
    "password": generate_password_hash("adminpass"), "status": "active", "role": "admin"})

SIGNUP = {"first_name": "Dev", "last_name": "New", "email": "dev@corp.test",
          "password": "secret123", "confirm_password": "secret123"}

print("Sign-up -> straight into the dashboard (no second login)")
c = app.test_client()
r = c.post("/api/auth/signup", json=SIGNUP)
body = r.get_json()
check("signup returns 201", r.status_code == 201)
check("response has the new user's id (front end needs it)", body["data"].get("id"))
check("response has role 'user' (lands on USER dashboard)", body["data"].get("role") == "user")
check("password hash is NOT in the response", "password" not in body["data"])
me = c.get("/api/auth/me")     # same cookie jar, NO login call in between
check("/api/auth/me works right after signup, without logging in", me.status_code == 200)
check("...and it is the account that just signed up", me.get_json()["data"]["email"] == "dev@corp.test")
check("new user can load their own tickets (session is real)", c.get("/api/tickets").status_code == 200)
check("new user is still blocked from the admin users table (403)", c.get("/api/users").status_code == 403)

print("Failed sign-ups must NOT log anyone in")
c2 = app.test_client()
bad = dict(SIGNUP, email="x@corp.test", confirm_password="different")
check("mismatched passwords -> 400", c2.post("/api/auth/signup", json=bad).status_code == 400)
check("...and no session was created", c2.get("/api/auth/me").status_code == 401)
dup = c2.post("/api/auth/signup", json=SIGNUP)
check("duplicate email -> 400", dup.status_code == 400)
check("...and no session was created", c2.get("/api/auth/me").status_code == 401)

print("Admin lands on the Users table")
a = app.test_client()
lg = a.post("/api/auth/login", json={"email": "alice@corp.test", "password": "adminpass"})
check("admin login returns role 'admin' (front end routes to Users table)", lg.get_json()["data"]["role"] == "admin")
check("admin can load the users table data", a.get("/api/users").status_code == 200)
check("users table contains the self-signed-up account",
      any(u["email"] == "dev@corp.test" for u in a.get("/api/users").get_json()))

print("Logout still works")
c.post("/api/auth/logout")
check("session gone after logout", c.get("/api/auth/me").status_code == 401)

print("Chatbot fully removed")
check("POST /api/chatbot no longer exists (404)", a.post("/api/chatbot", json={"message": "hi"}).status_code == 404)
html = open(os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "template", "index.html")).read().lower()
check("index.html has no chatbot/bellx/ai-agent code", not any(w in html for w in ["chatbot", "bellx", "ai-agent"]))

print(f"\n{passed} passed, {failed} failed")
sys.exit(1 if failed else 0)
