"""
routers/auth_router.py
========================
HTTP layer for the login / sign-up page. Thin: parses the request,
calls services/auth_service.py, formats the response. No SQL, no
password handling here.
"""

from flask import Blueprint, jsonify, request, session

import services.auth_service as auth_service
from services.auth_service import AuthError
import models.user_model as user_model

auth_bp = Blueprint("auth", __name__, url_prefix="/api/auth")


@auth_bp.get("/me")
def me():
    """GET /api/auth/me
    Lets the front end ask "am I already logged in?" on page load/refresh
    (e.g. when someone opens /users directly) instead of always showing
    the login screen. Reads the session cookie set at /login.
    """
    user_id = session.get("user_id")
    if not user_id:
        return jsonify({"success": False, "error": "Not authenticated"}), 401
    user = user_model.get_by_id(user_id)
    if not user:
        session.clear()
        return jsonify({"success": False, "error": "Not authenticated"}), 401
    # user_model.get_by_id() strips "id" (it's meant for responses where
    # the id is already known from the URL) — but the front end needs
    # its own id here (e.g. to call PUT /api/users/<id> on itself), so
    # re-attach it from the session, which is the source of truth for it.
    user = dict(user)
    user["id"] = user_id
    return jsonify({"success": True, "data": user})


@auth_bp.post("/signup")
def signup():
    """POST /api/auth/signup
    Body: {first_name, last_name, email, password, confirm_password,
           phone_number?, address?}
    """
    data = request.get_json(silent=True) or {}
    try:
        user = auth_service.signup_user(data)
        # AUTO-LOGIN: start the session right here, exactly the way
        # login() does, so the person lands on their dashboard instead
        # of being sent back to the login form.
        session.permanent = True  # real expiry (PERMANENT_SESSION_LIFETIME), not "until browser closes"
        session["user_id"] = user["id"]
        session["role"] = user.get("role")
        return jsonify({"success": True, "message": "Account created successfully", "data": user}), 201
    except AuthError as e:
        return jsonify({"success": False, "error": str(e)}), 400
    except RuntimeError as e:
        return jsonify({"success": False, "error": str(e)}), 500


@auth_bp.post("/login")
def login():
    """POST /api/auth/login
    Body: {email, password}   (the "Email / Username" field is matched against email)
    """
    data = request.get_json(silent=True) or {}
    try:
        user = auth_service.login_user(data.get("email"), data.get("password"))
        session.permanent = True  # real expiry (PERMANENT_SESSION_LIFETIME), not "until browser closes"
        session["user_id"] = user["id"]
        session["role"] = user.get("role")
        return jsonify({"success": True, "message": "Login successful", "data": user})
    except AuthError as e:
        return jsonify({"success": False, "error": str(e)}), 401
    except RuntimeError as e:
        return jsonify({"success": False, "error": str(e)}), 500


@auth_bp.post("/logout")
def logout():
    session.clear()
    return jsonify({"success": True, "message": "Logged out"})
