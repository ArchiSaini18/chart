"""
routers/mcp_router.py
=====================
HTTP wrapper for the MCP server.

Auth model (mirrors the working cana-apps-demo reference):
  - Cana.build's connector calls this endpoint the SAME way it calls any
    MCP server it's connected to: plain JSON-RPC POSTs with, at most, a
    *static credential header* — it does NOT attach a per-visitor JWT to
    these calls. Register that header under "Static credential" in the
    cana.build connector dialog.
  - When MCP_AUTH_KEY is unset, the endpoint is open (fine for local/dev
    tunnels), matching the reference demo's behaviour.
  - The Cana-signed visitor JWT (from /api/cana-token, see
    cana_token_router.py) is a *separate* mechanism for the embedded chat
    *widget* to identify a logged-in visitor. It is optional here: if a
    request DOES carry "Authorization: Bearer <jwt>", we validate it and
    run tools as that user (admin/user RBAC below). If it doesn't — which
    is the normal case for the cana.build connector itself — we run tools
    as an admin-level connector identity (user_id=None, role="admin"),
    same spirit as the reference demo's unscoped tools.

Endpoints:
  POST /api/mcp — JSON-RPC request(s), returns JSON-RPC response(s)
  GET /api/mcp — Tool descriptor list (for browser visits)
  OPTIONS /api/mcp — CORS preflight
"""

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import asyncio
from uuid import uuid4
from flask import Blueprint, request, jsonify, g, Response

from lib.mcp_server import handleRpc, TOOLS
from lib.jwt_utils import decode_jwt
from config import CANA_APP_SIGNING_KEY, MCP_AUTH_KEY


mcp_bp = Blueprint("mcp", __name__)

# Header name to register under "Static credential" in the cana.build
# connector modal. Must match what tunnel.py / tunnel_simple.py print.
MCP_KEY_HEADER = "x-mcp-key"

# One id per process — echoed back as the mcp-session-id response header,
# same as the reference demo (this app keeps no real per-session state).
SESSION_ID = str(uuid4())

CORS_HEADERS = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "content-type, mcp-session-id, x-mcp-key, authorization",
    "Access-Control-Allow-Methods": "POST, GET, OPTIONS",
}


# ============================================================
# Auth — Layer 0: static connector credential (primary, matches
# cana.build's actual connector behaviour)
# ============================================================

def _static_key_unauthorized() -> bool:
    """True if MCP_AUTH_KEY is set but the request's x-mcp-key header
    doesn't match it. False (allowed) when MCP_AUTH_KEY is unset."""
    expected = (MCP_AUTH_KEY or "").strip()
    if not expected:
        return False
    supplied = (request.headers.get(MCP_KEY_HEADER) or "").strip()
    return supplied != expected


# ============================================================
# Auth — Layer 1 (optional): per-visitor JWT, only used if the
# caller actually sends one. Never required just to connect.
# ============================================================

def _identity_from_jwt(auth_header: str) -> tuple[int | None, str]:
    """
    Extract (user_id, user_role) from a Bearer JWT.
    Raises ValueError if a token was supplied but is invalid/expired.
    """
    token_string = auth_header[7:]  # strip "Bearer "

    try:
        payload = decode_jwt(token_string, CANA_APP_SIGNING_KEY)
    except ValueError as e:
        raise ValueError(f"Invalid token: {str(e)}")

    user_id = payload.get("sub")
    # role lives in metadata (Cana-spec claim); accept a top-level one too
    meta = payload.get("metadata") if isinstance(payload.get("metadata"), dict) else {}
    user_role = payload.get("role") or meta.get("role") or "user"

    if not user_id:
        raise ValueError("Token missing 'sub' (user_id)")

    try:
        user_id = int(user_id)
    except (TypeError, ValueError):
        raise ValueError("Token 'sub' must be an integer")

    if user_role not in ("admin", "user"):
        raise ValueError(f"Invalid role: {user_role}")

    return user_id, user_role


def _resolve_identity() -> tuple[int | None, str]:
    """
    Decide which identity tool calls run as for this request.

    - No Authorization header -> connector identity: (None, "admin").
      This is the normal path when cana.build calls this endpoint.
    - Authorization: Bearer <jwt> present -> validated and used as-is.
      Lets an embedded, logged-in-visitor flow (like /api/cana-token)
      keep working with real per-user RBAC, without making it mandatory.
    """
    auth_header = request.headers.get("Authorization", "")
    if not auth_header:
        return None, "admin"

    if not auth_header.startswith("Bearer "):
        raise ValueError("Authorization header must be 'Bearer <token>'")

    return _identity_from_jwt(auth_header)


def _jsonrpc_response(body: dict, status: int = 200) -> Response:
    resp = jsonify(body)
    resp.status_code = status
    for k, v in CORS_HEADERS.items():
        resp.headers[k] = v
    resp.headers["mcp-session-id"] = SESSION_ID
    return resp


# ============================================================
# /api/mcp — single rule handling GET / POST / OPTIONS.
# (Registered as one Werkzeug rule so OPTIONS always hits our own
# handler instead of Flask's aggregate default-options response,
# which otherwise wins when GET/POST/OPTIONS are registered as
# separate rules on the same path.)
# ============================================================

@mcp_bp.route("/api/mcp", methods=["GET", "POST", "OPTIONS"], provide_automatic_options=False)
def mcp_endpoint():
    if request.method == "OPTIONS":
        return mcp_options()
    if request.method == "GET":
        return mcp_get()
    return mcp_post()


def mcp_post():
    # LAYER 0: static connector credential (this is what actually
    # protects the endpoint when cana.build calls it)
    if _static_key_unauthorized():
        return _jsonrpc_response({
            "jsonrpc": "2.0",
            "id": None,
            "error": {
                "code": -32001,
                "message": (
                    f"Unauthorized: send the static credential header "
                    f"'{MCP_KEY_HEADER}' with the value of MCP_AUTH_KEY."
                ),
            },
        }, 401)

    # LAYER 1: optional per-visitor JWT
    try:
        user_id, user_role = _resolve_identity()
        g.current_user_id = user_id
        g.current_user_role = user_role
    except ValueError as e:
        return _jsonrpc_response({
            "jsonrpc": "2.0",
            "id": None,
            "error": {"code": -32001, "message": str(e)},
        }, 401)

    # Parse request body
    try:
        data = request.get_json(silent=True)
        if not data:
            return _jsonrpc_response({
                "jsonrpc": "2.0",
                "id": None,
                "error": {"code": -32700, "message": "Parse error"},
            }, 400)
    except Exception as e:
        return _jsonrpc_response({
            "jsonrpc": "2.0",
            "id": None,
            "error": {"code": -32700, "message": f"Parse error: {str(e)}"},
        }, 400)

    # Dispatch message(s)
    messages = data if isinstance(data, list) else [data]

    responses = []
    for msg in messages:
        try:
            response = asyncio.run(handleRpc(msg, user_id, user_role))
        except Exception as e:
            response = {
                "jsonrpc": "2.0",
                "id": msg.get("id") if isinstance(msg, dict) else None,
                "error": {"code": -32603, "message": f"Internal error: {str(e)}"},
            }
        # handleRpc returns None for notifications (e.g. notifications/initialized)
        if response is not None:
            responses.append(response)

    # Return response(s) — JSON-RPC notifications (no "id") get no envelope
    if not responses:
        resp = Response(status=202)
        for k, v in CORS_HEADERS.items():
            resp.headers[k] = v
        resp.headers["mcp-session-id"] = SESSION_ID
        return resp

    if len(responses) == 1:
        return _jsonrpc_response(responses[0])
    return _jsonrpc_response(responses)


# ============================================================
# GET /api/mcp — Tool Descriptor Endpoint
# ============================================================

def mcp_get():
    """Descriptor page so pasting the URL into a browser (or curling it
    through the tunnel) shows something useful instead of a bare 405."""
    resp = _jsonrpc_response({
        "server": "User Management MCP",
        "protocolVersion": "2024-11-05",
        "transport": "streamable-http",
        "authRequired": bool((MCP_AUTH_KEY or "").strip()),
        "authHeader": MCP_KEY_HEADER if (MCP_AUTH_KEY or "").strip() else None,
        "tools": [tool.to_descriptor() for tool in TOOLS],
        "hint": "POST JSON-RPC 2.0 here. Register this exact URL as the MCP server URL in cana.build.",
    })
    return resp


# ============================================================
# OPTIONS /api/mcp — CORS preflight
# ============================================================

def mcp_options():
    resp = Response(status=204)
    for k, v in CORS_HEADERS.items():
        resp.headers[k] = v
    return resp


# ============================================================
# Error Handlers
# ============================================================

@mcp_bp.errorhandler(400)
def bad_request(e):
    return jsonify({
        "jsonrpc": "2.0",
        "error": {"code": -32600, "message": "Invalid Request"},
    }), 400


@mcp_bp.errorhandler(404)
def not_found(e):
    return jsonify({"error": "Endpoint not found"}), 404


@mcp_bp.errorhandler(500)
def internal_error(e):
    return jsonify({
        "jsonrpc": "2.0",
        "error": {"code": -32603, "message": "Internal server error"},
    }), 500
