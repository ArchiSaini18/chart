from flask import Blueprint, jsonify, request

import services.ticket_service as ticket_service
from services.ticket_service import ValidationError
from services.authz import login_required, is_admin, current_user_id

ticket_bp = Blueprint("tickets", __name__, url_prefix="/api/tickets")


def _int_arg_or_none(name: str):
    value = request.args.get(name)
    if value is None:
        return None
    try:
        return int(value)
    except ValueError:
        return None


@ticket_bp.get("")
@login_required
def list_tickets():
    """GET /api/tickets?status=&priority=&category=&user_id=&limit=
    Admins see every ticket (optionally filtered by user_id). A plain
    user always gets ONLY their own tickets — any user_id they pass in
    the query string is ignored, not trusted.
    """
    user_id = _int_arg_or_none("user_id")
    if not is_admin():
        user_id = current_user_id()
    try:
        return jsonify(ticket_service.list_tickets(
            limit=_int_arg_or_none("limit"),
            status=request.args.get("status"),
            priority=request.args.get("priority"),
            category=request.args.get("category"),
            user_id=user_id,
            include_ids=request.args.get("include_ids") == "true",
        ))
    except RuntimeError as e:
        return jsonify({"error": str(e)}), 500


@ticket_bp.get("/<int:ticket_id>")
@login_required
def get_ticket(ticket_id: int):
    try:
        ticket = ticket_service.get_ticket(ticket_id, raw=not is_admin())
    except RuntimeError as e:
        return jsonify({"error": str(e)}), 500
    if not ticket:
        return jsonify({"success": False, "message": "Ticket not found"}), 404
    if not is_admin() and ticket.get("user_id") != current_user_id():
        return jsonify({"success": False, "message": "Ticket not found"}), 404
    if not is_admin():
        ticket.pop("user_id", None)
    return jsonify({"success": True, "ticket": ticket})


@ticket_bp.post("")
@login_required
def create_ticket():
    """POST /api/tickets — Body: {user_id, ticket_subject, ticket_description?, ticket_category?, ticket_priority?, ticket_status?}
    A plain user can only ever open a ticket for themself — user_id in
    the body is overridden with their own id rather than trusted.
    """
    data = request.get_json(silent=True) or {}
    if not is_admin():
        data["user_id"] = current_user_id()
    try:
        result = ticket_service.create_ticket(data)
        # Return the full saved row (id, user_id, ..., created_at)
        # instead of just the id.
        record = ticket_service.get_ticket(result["id"])
        return jsonify({"created": True, "data": record}), 201
    except ValidationError as e:
        return jsonify({"error": str(e)}), 400
    except RuntimeError as e:
        return jsonify({"error": str(e)}), 500


@ticket_bp.put("/<int:ticket_id>")
@login_required
def update_ticket(ticket_id: int):
    """PUT /api/tickets/<id> — e.g. {"ticket_status": "Resolved"}
    A plain user may only update a ticket that belongs to them, and may
    not reassign it to another user_id.
    """
    existing = ticket_service.get_ticket(ticket_id, raw=True)
    if existing and not is_admin() and existing.get("user_id") != current_user_id():
        return jsonify({"error": f"No ticket with id={ticket_id}"}), 404

    data = request.get_json(silent=True) or {}
    if not is_admin():
        data.pop("user_id", None)
    try:
        result = ticket_service.update_ticket(ticket_id, data)
        record = ticket_service.get_ticket(ticket_id)
        return jsonify({"updated": result["rowcount"] > 0, "data": record})
    except ValidationError as e:
        return jsonify({"error": str(e)}), 404
    except RuntimeError as e:
        return jsonify({"error": str(e)}), 500


@ticket_bp.delete("/<int:ticket_id>")
@login_required
def delete_ticket(ticket_id: int):
    existing = ticket_service.get_ticket(ticket_id, raw=True)
    if existing and not is_admin() and existing.get("user_id") != current_user_id():
        return jsonify({"error": f"No ticket with id={ticket_id}"}), 404
    try:
        result = ticket_service.delete_ticket(ticket_id)
        return jsonify({"deleted": result["rowcount"] > 0})
    except ValidationError as e:
        return jsonify({"error": str(e)}), 404
    except RuntimeError as e:
        return jsonify({"error": str(e)}), 500
