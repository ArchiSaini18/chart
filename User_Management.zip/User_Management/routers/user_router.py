from flask import Blueprint, jsonify, request

import services.user_service as user_service
from services.user_service import ValidationError
from services.authz import login_required, admin_required, is_admin, current_user_id

user_bp = Blueprint("users", __name__, url_prefix="/api/users")

# A plain "user" is allowed to edit these fields on their OWN record only.
# role/status/created_by/updated_by are admin-controlled and are silently
# dropped from a self-service update instead of trusting the client.
SELF_EDITABLE_FIELDS = {"first_name", "last_name", "phone_number", "address", "email", "password"}


def _int_arg_or_none(name: str):
    value = request.args.get(name)
    if value is None:
        return None
    try:
        return int(value)
    except ValueError:
        return None


@user_bp.get("")
@admin_required
def list_users():
    """GET /api/users?status=&role=&limit=
    Admin only — the full customer/user list. A plain user should use
    GET /api/auth/me for their own profile instead.
    """
    try:
        return jsonify(user_service.list_users(
            limit=_int_arg_or_none("limit"),
            status=request.args.get("status"),
            role=request.args.get("role"),
            include_ids=request.args.get("include_ids") == "true",
        ))
    except RuntimeError as e:
        return jsonify({"error": str(e)}), 500


@user_bp.get("/<int:user_id>")
@login_required
def get_user(user_id: int):
    """Admins can look up anyone. A plain user can only look up themself."""
    if not is_admin() and user_id != current_user_id():
        return jsonify({"success": False, "message": "Forbidden"}), 403
    try:
        user = user_service.get_user(user_id)
    except RuntimeError as e:
        return jsonify({"error": str(e)}), 500
    if not user:
        return jsonify({"success": False, "message": "User not found"}), 404
    # NOTE: previously this returned a hardcoded message with no data.
    # Fixed to actually return the (sanitized, password-free) user.
    return jsonify(user)


@user_bp.post("")
@admin_required
def create_user():
    """POST /api/users — Admin only. Self sign-up goes through /api/auth/signup.
    Body: {first_name, last_name, email, phone_number?, address?, status?, role?, created_by?}
    """
    data = request.get_json(silent=True) or {}
    try:
        result = user_service.create_user(data)
        # Fetch the row we just wrote so the response shows every column
        # (id, created_by, updated_by, created_at, updated_at, ...)
        # instead of just the id — no field is hardcoded, it's whatever
        # SELECT * returns.
        record = user_service.get_user(result["id"])
        return jsonify({"created": True, "data": record}), 201
    except ValidationError as e:
        return jsonify({"error": str(e)}), 400
    except RuntimeError as e:
        return jsonify({"error": str(e)}), 500


@user_bp.put("/<int:user_id>")
@login_required
def update_user(user_id: int):
    """Admins can edit anyone, including role/status. A plain user can
    edit only their own profile, and only non-privileged fields — any
    role/status/created_by/updated_by in the body is ignored rather
    than trusted from the client.
    """
    if not is_admin() and user_id != current_user_id():
        return jsonify({"success": False, "message": "Forbidden"}), 403

    data = request.get_json(silent=True) or {}
    if not is_admin():
        data = {k: v for k, v in data.items() if k in SELF_EDITABLE_FIELDS}

    try:
        result = user_service.update_user(user_id, data)
        record = user_service.get_user(user_id)
        return jsonify({"updated": result["rowcount"] > 0, "data": record})
    except ValidationError as e:
        return jsonify({"error": str(e)}), 404
    except RuntimeError as e:
        return jsonify({"error": str(e)}), 500


@user_bp.delete("/<int:user_id>")
@admin_required
def delete_user(user_id: int):
    """Admin only — deleting an account is not something a customer can
    self-service from this console."""
    try:
        result = user_service.delete_user(user_id)
        return jsonify({"deleted": result["rowcount"] > 0})
    except ValidationError as e:
        return jsonify({"error": str(e)}), 404
    except RuntimeError as e:
        return jsonify({"error": str(e)}), 500
