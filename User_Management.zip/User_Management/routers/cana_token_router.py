"""
routers/cana_token_router.py
============================
Everything the embedded Cana chat widget needs from this server.

  GET /api/cana-config  -> public widget settings (app id, bundle URLs, mode)
  GET /api/cana-token   -> the token issuer referenced by
                           data-cana-token-url="/api/cana-token"

Mirrors the working cana-apps-demo (src/app/api/cana-token/route.ts):

  Widget / refresh mode      GET /api/cana-token?format=json
      logged in   -> 200 {"token": "<jwt>"}
      logged out  -> 401 {"loginUrl": "<origin>/login"}   (widget shows "Sign in")
      not set up  -> 501 {"error": "not_configured", "message": "..."}

  Hosted-page mode           GET /api/cana-token?return_to=<cana hosted page>
      logged in   -> 302 to return_to with ?exchange=<one-time code>
                     (falls back to ?token=<jwt> if the exchange call is refused)
      logged out  -> 302 to /login

The JWT is HS256, JOSE header kid = App id, claims sub / exp / jti (+ email,
name, metadata). See lib/jwt_utils.py.
"""

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import hashlib
import hmac
import json
import time
import urllib.error
import urllib.request
from urllib.parse import urlparse, urlencode, urlunparse, parse_qsl

from flask import Blueprint, jsonify, session, request, redirect

from lib.jwt_utils import create_cana_token
from config import (
    CANA_APP_ID,
    CANA_APP_SIGNING_KEY,
    CANA_WEB_BASE,
    CANA_CDN_URL,
    CANA_MODE,
    CANA_TOKEN_TTL_SEC,
)
import models.user_model as user_model


cana_token_bp = Blueprint("cana_token", __name__)

NO_STORE = {"Cache-Control": "no-store"}


# ------------------------------------------------------------------
# GET /api/cana-config
# ------------------------------------------------------------------
@cana_token_bp.get("/api/cana-config")
def cana_config():
    """Public, non-secret widget settings. The signing key is NEVER here.

    `sources` is tried in order by the page: the CDN URL from the dashboard
    snippet first, then the copy served by cana.build itself (same bundle,
    different host) in case the CDN is unreachable from the visitor's network.
    """
    served = f"{CANA_WEB_BASE}/embed/app.js"
    sources = [CANA_CDN_URL] if CANA_CDN_URL else []
    if served not in sources:
        sources.append(served)

    return jsonify({
        "enabled": bool(CANA_APP_ID and CANA_APP_SIGNING_KEY),
        "appId": CANA_APP_ID,
        "webBase": CANA_WEB_BASE,
        "sources": sources,
        "mode": CANA_MODE,
        "tokenUrl": "/api/cana-token",
    }), 200, NO_STORE


# ------------------------------------------------------------------
# Helpers
# ------------------------------------------------------------------
def _return_to_allowed(return_to: str) -> bool:
    """`return_to` receives a token/exchange code, so it must be Cana's own
    hosted page — otherwise this endpoint is an open redirect that hands a
    valid visitor token to any site a link points at."""
    try:
        target = urlparse(return_to)
        base = urlparse(CANA_WEB_BASE)
    except ValueError:
        return False
    if target.scheme not in ("https", "http") or not target.hostname or not base.hostname:
        return False
    host, base_host = target.hostname.lower(), base.hostname.lower()
    return host == base_host or host.endswith("." + base_host)


def _issue_exchange_code(token: str) -> str:
    """Trade the JWT for a one-time code via
    POST <webBase>/api/v1/apps/<id>/exchange/issue, HMAC-signed with the App
    signing key (header  X-Cana-Signature: t=<ms>,v1=<hex>).

    The HMAC covers the EXACT bytes sent, so the body is serialised once."""
    body = json.dumps({"token": token}, separators=(",", ":"))
    t = int(time.time() * 1000)
    sig = hmac.new(
        CANA_APP_SIGNING_KEY.encode(), f"{t}.{body}".encode(), hashlib.sha256
    ).hexdigest()

    req = urllib.request.Request(
        f"{CANA_WEB_BASE}/api/v1/apps/{CANA_APP_ID}/exchange/issue",
        data=body.encode(),
        method="POST",
        headers={
            "Content-Type": "application/json",
            "X-Cana-Signature": f"t={t},v1={sig}",
        },
    )
    try:
        with urllib.request.urlopen(req, timeout=8) as res:
            return json.loads(res.read().decode())["code"]
    except urllib.error.HTTPError as e:
        detail = e.read().decode(errors="replace")[:200]
        raise RuntimeError(f"exchange/issue returned {e.code}: {detail}")


# ------------------------------------------------------------------
# GET /api/cana-token
# ------------------------------------------------------------------
@cana_token_bp.get("/api/cana-token")
def get_cana_token():
    return_to = request.args.get("return_to")
    fmt = (request.args.get("format") or "").lower()
    wants_json = fmt == "json" or not return_to
    login_url = request.host_url.rstrip("/") + "/login"

    # Not configured -> say exactly what is missing (better than minting a
    # token cana.build will silently reject).
    if not CANA_APP_ID or not CANA_APP_SIGNING_KEY:
        missing = " and ".join(
            n for n, v in (("CANA_APP_ID", CANA_APP_ID),
                           ("CANA_APP_SIGNING_KEY", CANA_APP_SIGNING_KEY)) if not v
        )
        return jsonify({
            "error": "not_configured",
            "message": f"Set {missing} in .env, then restart the server. Both are on "
                       f"cana.build -> your App -> Embed tab.",
        }), 501

    # Who is signed in? (Flask session cookie set by /api/auth/login)
    user_id = session.get("user_id")
    user = user_model.get_by_id(user_id) if user_id else None
    if not user:
        if user_id:
            session.clear()
        if not wants_json:
            return redirect("/login", 302)
        return jsonify({"loginUrl": login_url}), 401, NO_STORE

    token = create_cana_token(
        user_id=user_id,
        email=user.get("email", ""),
        first_name=user.get("first_name", ""),
        last_name=user.get("last_name", ""),
        role=user.get("role", "user"),
        signing_key=CANA_APP_SIGNING_KEY,
        app_id=CANA_APP_ID,
        expires_in_minutes=CANA_TOKEN_TTL_SEC / 60,
        # The widget may pass a thread key (default param name "contract");
        # stamp it into metadata so an MCP tool could scope by it later.
        metadata=({"contractId": request.args["contract"]}
                  if request.args.get("contract") else None),
    )

    if wants_json:
        # Widget / refresh mode: the JWT goes back to the parent page over
        # fetch(), never into a URL.
        return jsonify({"token": token}), 200, NO_STORE

    # Hosted-page mode
    if not _return_to_allowed(return_to):
        return jsonify({
            "error": "invalid_return_to",
            "message": f"return_to must be on {CANA_WEB_BASE}",
        }), 400

    parts = urlparse(return_to)
    query = dict(parse_qsl(parts.query, keep_blank_values=True))
    try:
        query["exchange"] = _issue_exchange_code(token)
    except Exception as e:  # network error / bad_signature / timeout
        print(f"[cana] exchange/issue failed ({e}); falling back to legacy ?token= redirect")
        query["token"] = token

    target = urlunparse(parts._replace(query=urlencode(query)))
    resp = redirect(target, 302)
    resp.headers["Cache-Control"] = "no-store"
    return resp
