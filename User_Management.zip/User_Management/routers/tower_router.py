from flask import Blueprint, jsonify, request

import services.tower_service as tower_service
from services.tower_service import ValidationError
from services.authz import admin_required

tower_bp = Blueprint("towers", __name__, url_prefix="/api/towers")


def _int_arg_or_none(name: str):
    value = request.args.get(name)
    if value is None:
        return None
    try:
        return int(value)
    except ValueError:
        return None


@tower_bp.get("")
@admin_required
def list_towers():
    """GET /api/towers?city=&technology=&status=&user_id=&limit="""
    try:
        return jsonify(tower_service.list_towers(
            limit=_int_arg_or_none("limit"),
            city=request.args.get("city"),
            technology=request.args.get("technology"),
            status=request.args.get("status"),
            user_id=_int_arg_or_none("user_id"),
            include_ids=request.args.get("include_ids") == "true",
        ))
    except RuntimeError as e:
        return jsonify({"error": str(e)}), 500


@tower_bp.get("/<int:tower_id>")
@admin_required
def get_tower(tower_id: int):
    try:
        tower = tower_service.get_tower(tower_id)
    except RuntimeError as e:
        return jsonify({"error": str(e)}), 500
    if not tower:
        return jsonify({"success": False, "message": "Tower not found"}), 404
    return jsonify({"success": True, "tower": tower})


@tower_bp.post("")
@admin_required
def create_tower():
    """POST /api/towers — Body: {tower_code, tower_city, tower_area?, technology?, tower_status?, user_id?}"""
    data = request.get_json(silent=True) or {}
    try:
        result = tower_service.create_tower(data)
        # Return the full saved row (id, tower_code, ..., user_id,
        # created_at) instead of just the id.
        record = tower_service.get_tower(result["id"])
        return jsonify({"success": True, "data": record}), 201
    except ValidationError as e:
        return jsonify({"success": False, "message": str(e)}), 400
    except RuntimeError as e:
        return jsonify({"error": str(e)}), 500


@tower_bp.put("/<int:tower_id>")
@admin_required
def update_tower(tower_id: int):
    data = request.get_json(silent=True) or {}
    try:
        result = tower_service.update_tower(tower_id, data)
        record = tower_service.get_tower(tower_id)
        return jsonify({"updated": result["rowcount"] > 0, "data": record})
    except ValidationError as e:
        return jsonify({"error": str(e)}), 404
    except RuntimeError as e:
        return jsonify({"error": str(e)}), 500


@tower_bp.delete("/<int:tower_id>")
@admin_required
def delete_tower(tower_id: int):
    try:
        result = tower_service.delete_tower(tower_id)
        return jsonify({"deleted": result["rowcount"] > 0})
    except ValidationError as e:
        return jsonify({"error": str(e)}), 404
    except RuntimeError as e:
        return jsonify({"error": str(e)}), 500
