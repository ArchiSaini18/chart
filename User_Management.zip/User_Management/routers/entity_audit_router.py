"""
routers/entity_audit_router.py
================================
HTTP layer for the entity audit log — full CRUD.
"""

from flask import Blueprint, jsonify, request

import services.entity_audit_service as audit_service
from services.entity_audit_service import ValidationError
from services.authz import admin_required

audit_bp = Blueprint("entity_audit_log", __name__, url_prefix="/api/entity-audit-log")


def _int_arg_or_none(name: str):
    value = request.args.get(name)
    if value is None:
        return None
    try:
        return int(value)
    except ValueError:
        return None


@audit_bp.get("")
@admin_required
def list_logs():
    """GET /api/entity-audit-log?entity_type=&user_id=&limit="""
    try:
        return jsonify(audit_service.list_logs(
            limit=_int_arg_or_none("limit"),
            entity_type=request.args.get("entity_type"),
            user_id=_int_arg_or_none("user_id"),
            include_ids=request.args.get("include_ids") == "true",
        ))
    except RuntimeError as e:
        return jsonify({"error": str(e)}), 500


@audit_bp.get("/<int:log_id>")
@admin_required
def get_log(log_id: int):
    try:
        log = audit_service.get_log(log_id)
    except RuntimeError as e:
        return jsonify({"error": str(e)}), 500
    if not log:
        return jsonify({"success": False, "message": "Log entry not found"}), 404
    return jsonify({"success": True, "entry": log})


@audit_bp.post("")
@admin_required
def create_log():
    """POST /api/entity-audit-log — Body: {audit_action, entity_type, entity_id?, audit_description?, user_id?}"""
    data = request.get_json(silent=True) or {}
    try:
        result = audit_service.create_log(data)
        # Return the full saved row (id, user_id, entity_id, created_at, ...)
        # instead of just the id.
        record = audit_service.get_log(result["id"])
        return jsonify({"created": True, "data": record}), 201
    except ValidationError as e:
        return jsonify({"error": str(e)}), 400
    except RuntimeError as e:
        return jsonify({"error": str(e)}), 500


@audit_bp.put("/<int:log_id>")
@admin_required
def update_log(log_id: int):
    data = request.get_json(silent=True) or {}
    try:
        result = audit_service.update_log(log_id, data)
        record = audit_service.get_log(log_id)
        return jsonify({"updated": result["rowcount"] > 0, "data": record})
    except ValidationError as e:
        return jsonify({"error": str(e)}), 404
    except RuntimeError as e:
        return jsonify({"error": str(e)}), 500


@audit_bp.delete("/<int:log_id>")
@admin_required
def delete_log(log_id: int):
    try:
        result = audit_service.delete_log(log_id)
        return jsonify({"deleted": result["rowcount"] > 0})
    except ValidationError as e:
        return jsonify({"error": str(e)}), 404
    except RuntimeError as e:
        return jsonify({"error": str(e)}), 500
